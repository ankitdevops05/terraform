# ec2-idd-shared-stack-01 - This is for shared EC2 instances for IDD that are normally running in AWS Shared Service account

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
