# S3 Storage Gateways for AMP DB Backups

This particular terraform code must be run from a local host.  The terraform binary must do a curl to a private EC2 instance IP and thus Terraform Cloud will not be able to reach this IP.  You must set the provider information for the environment that you're working in and an AD username and password that can join the storage gateway to the sandata.local domain.

# Setup
S3 Storage Gateways include the following components
1. EC2 Instance which runs an AWS Appliance for Storage Gateway
2. EBS Volume on the EC2 Instance which serves as a cache drive
3. Storage Gateway itself
4. S3 Bucket
5. Storage Gateway File Shares<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_s3_buckets"></a> [s3\_buckets](#module\_s3\_buckets) | git@github.com:sandatech/terraform-aws-s3-bucket.git | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_iam_policy_document.bucket_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_iam_role"></a> [iam\_role](#input\_iam\_role) | n/a | `map` | <pre>{<br>  "prod2-ue1": "arn:aws:iam::656560712260:role/sam_db_datatransition_sg_role",<br>  "qa-ue1": "arn:aws:iam::137598536613:role/sam_db_datatransition_sg_role",<br>  "rd-ue1": "arn:aws:iam::137598536613:role/sam_db_datatransition_sg_role",<br>  "uat-ue1": "arn:aws:iam::137598536613:role/sam_db_datatransition_sg_role"<br>}</pre> | no |
| <a name="input_lifecycle_rule"></a> [lifecycle\_rule](#input\_lifecycle\_rule) | n/a | `map` | <pre>{<br>  "prod2-ue1": [],<br>  "qa-ue1": [],<br>  "rd-ue1": [],<br>  "uat-ue1": []<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_s3_bucket_name"></a> [s3\_bucket\_name](#input\_s3\_bucket\_name) | n/a | `map` | <pre>{<br>  "prod2-ue1": "com-sandata-prod2-sam-database",<br>  "qa-ue1": "com-sandata-qa-sam-database",<br>  "rd-ue1": "com-sandata-rd-sam-database",<br>  "uat-ue1": "com-sandata-uat-sam-database"<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
