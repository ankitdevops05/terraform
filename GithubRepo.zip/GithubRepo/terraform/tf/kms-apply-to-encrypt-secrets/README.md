# kms-apply-to-encrypt-secrets: using kms keys to encrypt sensitive data
- The current version is only doing encryption for each key separately.  When we re-run to apply the terraform code, the encryption text only gets re-generated when the original value is changed.
- Open for enhancements
  + If there is a request to encrypt more sensitive data, should enhance the service to handle an input of a list of values and do encryption
  + Yes, the secret should be defined in Vault.<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_local"></a> [local](#provider\_local) | n/a |
| <a name="provider_null"></a> [null](#provider\_null) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [null_resource.encrypt_vault_token](https://registry.terraform.io/providers/hashicorp/null/latest/docs/resources/resource) | resource |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_kms_key.kms_secret_encryption](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/kms_key) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [local_file.encrypted_vault_token](https://registry.terraform.io/providers/hashicorp/local/latest/docs/data-sources/file) | data source |
| [terraform_remote_state.kms_app_secret_encryption](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |
| [terraform_remote_state.kms_apply_to_encrypt_secrets](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_raw_dwh_domo_dms_source_credential"></a> [raw\_dwh\_domo\_dms\_source\_credential](#input\_raw\_dwh\_domo\_dms\_source\_credential) | As this is a very sensitive data, will be enter as sensitive value in TF Cloud only | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "RbrWG98MVl1GYQ",<br>  "stg-ue1": "",<br>  "uat-ue1": ""<br>}</pre> | no |
| <a name="input_raw_dwh_domo_dms_target_credential"></a> [raw\_dwh\_domo\_dms\_target\_credential](#input\_raw\_dwh\_domo\_dms\_target\_credential) | As this is a very sensitive data, will be enter as sensitive value in TF Cloud only | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "G0q9HFFwXJrd",<br>  "stg-ue1": "",<br>  "uat-ue1": ""<br>}</pre> | no |
| <a name="input_raw_vault_token"></a> [raw\_vault\_token](#input\_raw\_vault\_token) | As this is a very sensitive data, will be enter as sensitive value in TF Cloud only | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "s.48npwifOo7dqkJ1aPGDACgZU",<br>  "stg-ue1": "",<br>  "uat-ue1": ""<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_encrypted_vault_token"></a> [encrypted\_vault\_token](#output\_encrypted\_vault\_token) | encrypted vault token will be referenced by Lambda function |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
