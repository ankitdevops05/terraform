# infosec-tools

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ec2_instance"></a> [ec2\_instance](#module\_ec2\_instance) | git@github.com:sandatech/terraform-aws-ec2-instance.git | n/a |
| <a name="module_sg01"></a> [sg01](#module\_sg01) | git@github.com:sandatech/terraform-aws-module-security-groups-01.git | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_ami_id"></a> [ami\_id](#input\_ami\_id) | n/a | `string` | `"ami-0212d39aa1d70f26b"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_instance_name"></a> [instance\_name](#input\_instance\_name) | n/a | `string` | `"sd-ss-us-east-1-infosec-tools"` | no |
| <a name="input_instance_size"></a> [instance\_size](#input\_instance\_size) | n/a | `string` | `"t3.xlarge"` | no |
| <a name="input_key_name"></a> [key\_name](#input\_key\_name) | n/a | `string` | `"sd-ss-us-east-1-jgeib-keypair01"` | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_security_group_egress"></a> [security\_group\_egress](#input\_security\_group\_egress) | n/a | `map` | <pre>{<br>  "ss-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "0.0.0.0/0"<br>      ],<br>      "from_port": [<br>        "0"<br>      ],<br>      "ipv6_cidr_blocks": [<br>        "::/0"<br>      ],<br>      "protocols": [<br>        "-1"<br>      ],<br>      "to_port": [<br>        "0"<br>      ]<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_security_group_ingress"></a> [security\_group\_ingress](#input\_security\_group\_ingress) | n/a | `map` | <pre>{<br>  "ss-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata internal IPs SSH",<br>      "from_port": [<br>        "22"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "22"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "10.15.0.0/20",<br>        "172.18.24.0/22"<br>      ],<br>      "description": "Sandata internal IPs HTTPS",<br>      "from_port": [<br>        "443"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "443"<br>      ]<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_sg_name"></a> [sg\_name](#input\_sg\_name) | n/a | `string` | `"ec2-infosec"` | no |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | n/a | `string` | `"subnet-05dc9d8061ccca6e1"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | n/a | `map` | `{}` | no |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | n/a | `string` | `"vpc-0961ebb78fad4baeb"` | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
