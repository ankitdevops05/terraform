# rds-mysql-smc-01-global-db

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_module-db-sg"></a> [module-db-sg](#module\_module-db-sg) | git@github.com:sandatech/terraform-aws-module-security-groups-01.git | v0.0.6 |

## Resources

| Name | Type |
|------|------|
| [aws_db_parameter_group.aurora_db_57_parameter_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/db_parameter_group) | resource |
| [aws_rds_cluster_parameter_group.aurora_57_cluster_parameter_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/rds_cluster_parameter_group) | resource |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_db_sg_ports_egress"></a> [db\_sg\_ports\_egress](#input\_db\_sg\_ports\_egress) | List of VPC security groups to associate | `list` | <pre>[<br>  {<br>    "cidr_blocks": [<br>      "0.0.0.0/0"<br>    ],<br>    "description": "Default Egress Rule",<br>    "from_port": [<br>      "0"<br>    ],<br>    "protocols": [<br>      "-1"<br>    ],<br>    "security_groups": [],<br>    "self": true,<br>    "to_port": [<br>      "0"<br>    ]<br>  }<br>]</pre> | no |
| <a name="input_db_sg_ports_ingress"></a> [db\_sg\_ports\_ingress](#input\_db\_sg\_ports\_ingress) | List of VPC security groups to associate | `map` | <pre>{<br>  "prod2-ue2": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "172.17.32.0/19",<br>        "10.15.0.0/20",<br>        "10.14.8.19/32",<br>        "172.16.32.0/19"<br>      ],<br>      "description": "Allow access to 3306",<br>      "from_port": [<br>        "3306"<br>      ],<br>      "protocols": [<br>        "TCP"<br>      ],<br>      "security_groups": [],<br>      "self": false,<br>      "to_port": [<br>        "3306"<br>      ]<br>    }<br>  ],<br>  "qa-ue2": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "172.17.64.0/19",<br>        "10.15.0.0/20",<br>        "10.14.8.19/32",<br>        "172.16.71.172/32",<br>        "172.16.64.0/19",<br>        "172.16.197.126/32"<br>      ],<br>      "description": "Allow access to 3306",<br>      "from_port": [<br>        "3306"<br>      ],<br>      "protocols": [<br>        "TCP"<br>      ],<br>      "security_groups": [],<br>      "self": false,<br>      "to_port": [<br>        "3306"<br>      ]<br>    }<br>  ],<br>  "rd-ue2": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "172.17.128.0/19",<br>        "10.15.0.0/20",<br>        "10.14.8.19/32",<br>        "172.16.128.0/19",<br>        "172.16.197.126/32"<br>      ],<br>      "description": "Allow access to 3306",<br>      "from_port": [<br>        "3306"<br>      ],<br>      "protocols": [<br>        "TCP"<br>      ],<br>      "security_groups": [],<br>      "self": false,<br>      "to_port": [<br>        "3306"<br>      ]<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
