This folder contains the table mappings and task settings for the DMS tasks. The table that are getting replicated are grouped into different tasks as below.
All the mapping configs contain the 3 audit columns except where mentioned

- `dms_ora_last_updated`
- `dms_operation`
- `dms_rec_updated_at`


1. `table_mappings_for_stx.visits` contains mappings for VISITS table

| Table Name                |
|---------------------------|
| STX.VISITS                |

2. `table_mappings_for_stx.visits_log` contains mappings for VISITS_LOG table

| Table Name                |
|---------------------------|
| STX.VISITS_LOG            |

3. `table_mappings_for_stx.schedule` contains mappings for SCHEDULE table

| Table Name                |
|---------------------------|
| STX.SCHEDULE              |

4. `table_mappings_for_stx.calls` contains mappings for CALLS table

| Table Name                |
|---------------------------|
| STX.CALLS                 |

5. `table_mappings_for_tables_wo_dms_op_colum` contains mappings for a small set of tables where the `dms_operation` audit column is not included. There are 11 such tables in total.

| Table Name                |
|---------------------------|
| STX.AUTH_TYPES            |
| STX.MESSAGES              |
| STX.ACCOUNTS_GROUPS       |
| STX.DNIS                  |
| STX.ACCOUNTS_GROUPS_SETUP |
| STX.ACCOUNTS_NOSHOW       |
| STX.ACCOUNTS_TRANSFER     |
| STX.TASKS_PROMPTS         |
| STX.ACCOUNTS_MVV_SETUP    |
| STX.ACCOUNTS_WEB          |
| STX.TASKS_INFONAME        |

6. `table_mappings_for_midsize_tables_set1` contains mappings for a set of midsize tables. There are 12 tables.

| Table Name                |
|---------------------------|
| IODATA.INTF_RSP_TXN_CLAIM_STACK|
| IODATA.INTF_REQ_TXN_CLAIM_STACK|
| IODATA.INTF_REQ_TXN       |
| IODATA.INTF_RSP_TXN       |
| IODATA.INTF_REQ           |
| STX.CLIENTS_SUPP          |
| STX.ANI                   |
| STX.WORKERS_SUPP          |
| STX.CLIENTS               |
| STX.WORKERS               |
| STX.AUTH_LIMITS           |
| INBOX.LOGINS              |

7. `table_mappings_for_smaller_tables_set1` contains mappings for a set of small tables. There are 237 tables.

| Table Name                |
|---------------------------|
| IODATA.INTF_RSP_EXCP_LKUP|
| STX.ACCOUNTS|
| STX.ACCOUNTS_ACCESS_MNT_QUEUE|
| STX.ACCOUNTS_AUTO_PROVISION|
| STX.ACCOUNTS_BILL_UNIT|
| STX.ACCOUNTS_BILL_UNIT_DETL|
| STX.ACCOUNTS_BILLING|
| STX.ACCOUNTS_CATEGORIES|
| STX.ACCOUNTS_CLI_PRI_SETUP|
| STX.ACCOUNTS_CONTRACTS|
| STX.ACCOUNTS_COORD_SPV|
| STX.ACCOUNTS_CRT_TASKS|
| STX.ACCOUNTS_DISCIPLINES|
| STX.ACCOUNTS_EXCP_SETUP|
| STX.ACCOUNTS_INFO|
| STX.ACCOUNTS_INTERFACES|
| STX.ACCOUNTS_LANGUAGES|
| STX.ACCOUNTS_PROC|
| STX.ACCOUNTS_PROGRAMS|
| STX.ACCOUNTS_PROVIDERS|
| STX.ACCOUNTS_REASON_CODE_SETUP|
| STX.ACCOUNTS_REFRESH_CONFIG|
| STX.ACCOUNTS_SERVICES|
| STX.ACCOUNTS_SETUP|
| STX.ACCOUNTS_TTH_OPTIONS|
| STX.ACCOUNTS_VENDOR_CONFIG|
| STX.ACCOUNTS_VISIT_STATUS|
| STX.ADDR_TYPE_LKUP|
| STX.APP_ACCESS_CHANGE_LOG_DETL|
| STX.APP_DATA_SCOPES|
| STX.APP_DATA_SCOPES_PRPT|
| STX.APP_DATA_SCOPES_SETUP|
| STX.APP_DATA_SCOPES_SETUP_CLI|
| STX.APP_DATA_SCOPES_SETUP_CNT|
| STX.APP_DATA_SCOPES_SETUP_PRG|
| STX.APP_DATA_SCOPES_SETUP_SPV|
| STX.APP_DATA_SCOPES_SETUP_SRV|
| STX.APP_DATA_SCOPES_SETUP_WRK|
| STX.APP_DS_LOG|
| STX.APP_DS_PRPT_LOG|
| STX.APP_DS_SETUP_CLI_LOG|
| STX.APP_DS_SETUP_CNT_LOG|
| STX.APP_DS_SETUP_LOG|
| STX.APP_DS_SETUP_PRG_LOG|
| STX.APP_DS_SETUP_SPV_LOG|
| STX.APP_DS_SETUP_SRV_LOG|
| STX.APP_DS_SETUP_WRK_LOG|
| STX.APP_EXPORTS_SETUP|
| STX.APP_HOLIDAYS|
| STX.APP_IP_RANGES|
| STX.APP_MESSAGE|
| STX.APP_MESSAGE_LOG|
| STX.APP_MESSAGE_RCPT|
| STX.APP_MESSAGE_RCPT_LOG|
| STX.APP_NOTIFICATIONS_QUEUE|
| STX.APP_NOTIFY_GROUPS|
| STX.APP_PRIVS|
| STX.APP_REPORTS_SETUP|
| STX.APP_ROLE_EXT_PRIVS|
| STX.APP_ROLE_EXT_PRIVS_LOG|
| STX.APP_ROLES|
| STX.APP_ROLES_DATA_SCOPES|
| STX.APP_ROLES_DS_LOG|
| STX.APP_ROLES_LOG|
| STX.APP_USER_IDM_GROUP_XREF|
| STX.APP_USER_ROLES_LOG|
| STX.APP_USER_SPVS|
| STX.APP_USER_SPVS_LOG|
| STX.APP_USER_TYPES|
| STX.APP_USERS|
| STX.APP_USERS_ADDR_INFO|
| STX.APP_USERS_ADDR_INFO_LOG|
| STX.APP_USERS_ADDR_TYPES|
| STX.APP_USERS_CLI|
| STX.APP_USERS_CLI_LOG|
| STX.APP_USERS_CRED_CHNG_LKUP|
| STX.APP_USERS_CRED_CHNG_QUEUE|
| STX.APP_USERS_DATA_SCOPES|
| STX.APP_USERS_DS_LOG|
| STX.APP_USERS_GRANTOR_TYPES|
| STX.APP_USERS_LOG|
| STX.APP_USERS_WRK|
| STX.APP_USERS_WRK_LOG|
| STX.APP_WRKSCHEDULES|
| STX.APP_WRKSCHEDULES|
| STX.AREA_CODES|
| STX.AREA_CODES_LOOKUP|
| STX.AREA_OFFSETS|
| STX.AUTH_LIMIT_TYPES|
| STX.AUTH_SNAPSHOT_LOG|
| STX.AUTH_STATUS|
| STX.AUTH_UPDATE_QUEUE|
| STX.AUTHORIZATIONS|
| STX.BE|
| STX.BE_CLIENT_SERVICE_PRI|
| STX.BE_CONTGY_PLAN_SETUP|
| STX.BE_SETUP|
| STX.BREADCRUMBS_GPS|
| STX.BROADMSG_EXP|
| STX.CALL_EVENT_TYPE_LKUP|
| STX.CALLS_EVENTS|
| STX.CALLS_INFO_DIGITS|
| STX.CALLS_LOCATION_LKUP|
| STX.CALLS_MANUAL|
| STX.CALLS_MOVE_LOG|
| STX.CALLS_OUTBOUND|
| STX.CALLS_SRVRS|
| STX.CALLS_SRVRS_CKTS|
| STX.CALLS_VOICEMSG_IDS|
| STX.CARRIERS|
| STX.CLIENTS_ADDRESS|
| STX.CLIENTS_BIOMETRIC|
| STX.CLIENTS_CONTACT|
| STX.CLIENTS_CONTACT_REL_LKUP|
| STX.CLIENTS_DEMOGRAPHICS|
| STX.CLIENTS_DV_LOG|
| STX.CLIENTS_ELIGIBILITY|
| STX.CONTACT_TYPE_LKUP|
| STX.COORD_SOURCE_LKUP|
| STX.CORP_GROUPS|
| STX.CORP_GROUPS_SETUP|
| STX.DNIS_LANGUAGE|
| STX.DST|
| STX.DV_LOG|
| STX.ENTER_LL_METHODS|
| STX.EXCEPTIONS|
| STX.EXCEPTIONS_SETUP|
| STX.EXPLAINS|
| STX.EXPORT_ARCH_SUPP|
| STX.EXPORT_COLUMNS|
| STX.EXPORT_COLUMNS_FORMAT|
| STX.EXPORT_COLUMNS_SETUP|
| STX.EXPORT_FILTERS|
| STX.EXPORT_OPERATORS|
| STX.EXPORT_SORTORDERS|
| STX.EXPORT_SORTORDERS_SETUP|
| STX.EXPORTS|
| STX.EXPORTS_SETUP|
| STX.EXPORTS_SETUP_CORP|
| STX.EYECOLOR|
| STX.FOB_CYCLES_QUEUE|
| STX.FOB_DEVICES|
| STX.FOB_ORDER|
| STX.FOB_ORDER_ADDR|
| STX.FOB_ORDER_ADDR_TYPES|
| STX.FOB_ORDER_FILL|
| STX.FOB_PRE_REGISTRATIONS|
| STX.FOB_REASON_CODE|
| STX.FOB_REGISTRATIONS|
| STX.FOB_REGS_EXP|
| STX.FOB_TABLES|
| STX.FOB_TABLES_DECODE|
| STX.FOB_TERM_CODE|
| STX.FOB_VERSIONS|
| STX.H44_BANKS|
| STX.H44_INFO|
| STX.HAIRCOLOR|
| STX.LANGUAGE_LKUP|
| STX.LANGUAGE_XWALK|
| STX.LANGUAGES|
| STX.LEGEND|
| STX.LOC_CARE_FREQ_TYPES|
| STX.LOC_CARE_LIMIT_TYPES|
| STX.LOC_CARE_PLAN|
| STX.LOC_CARE_TYPES|
| STX.LOC_TRANS_FAILED|
| STX.MEDIA_FORMAT_LKUP|
| STX.MEDIA_TYPE_LKUP|
| STX.MSG_PRIV_XREF|
| STX.MVV_REG_TYPE_LKUP|
| STX.MVV_USERS_REG|
| STX.MVV_USERS_REG_EXP|
| STX.MVV_USERS_REG_LOG|
| STX.MYSQL_CHANGES|
| STX.N800LIST|
| STX.NOSHOW_ALERT_TYPES|
| STX.NOTE_TYPE_LKUP|
| STX.OPTCODESETS_NAME|
| STX.OPTION_CODES|
| STX.ORDERS|
| STX.PAYOR|
| STX.PAYOR_ACCOUNT_SETUP|
| STX.PAYOR_DATA_VALIDATION|
| STX.PAYOR_EXCEPTIONS_SETUP|
| STX.PAYOR_MVV_SETUP|
| STX.PAYOR_PROC|
| STX.PAYOR_PROGRAMS|
| STX.PAYOR_SERVICES|
| STX.PAYOR_SERVICES_XREF|
| STX.PAYOR_SETUP|
| STX.PHONE_NUMBERS|
| STX.PRODUCTS|
| STX.PROFILES|
| STX.PROVIDERS_XWALK|
| STX.RATES|
| STX.REASON_CODES|
| STX.REPORT_TYPES|
| STX.REPORTS|
| STX.SALESPERSONS|
| STX.SCHEDULE_DV_LOG|
| STX.SCHEDULE_LOG|
| STX.SCRIPTS|
| STX.SELECTION_TYPES|
| STX.SORT_ORDERS|
| STX.SORT_ORDERS|
| STX.SORT_ORDERS|
| STX.SV_QUESTIONS_SETUP|
| STX.SV_STATUS_LKUP|
| STX.TASK_LIMIT_TYPES|
| STX.TASKS_INFO_DECODE|
| STX.TASKS_INFO_DECODE|
| STX.TASKS_INFO_DECODE|
| STX.TASKS_OPERATIONS|
| STX.TASKS_PROFILES|
| STX.TASKS_PRPT|
| STX.TASKS_RULES|
| STX.TASKS_RULES|
| STX.TASKS_RULES_VFP|
| STX.TASKS_SETUP|
| STX.TASKS_TYPES|
| STX.TIMEZONE_NAMES_STX|
| STX.TIMEZONES|
| STX.TRANSFER_MSG_SETUP|
| STX.TZADJRULES|
| STX.USER_SV_TYPES|
| STX.USERS_SV|
| STX.VENDOR_LKUP|
| STX.VENDOR_PRODUCT|
| STX.VERSION_PRPT|
| STX.VISIT_EVENT_TYPE_LKUP|
| STX.VISITS_CLI_HLTH_ASST|
| STX.VISITS_EVENTS|
| STX.VISITS_OBS_QN|
| STX.VS_COLUMNS|
| STX.WORKERS_ADDR_INFO|
| STX.WORKERS_CLIENTS|
| STX.WORKERS_DV_LOG|
| STX.WORKERS_ID_DECODE|
| STX.WORKERS_ID_DECODE|
| STX.WORKERS_ID_XWALK|
| STX.WORKERS_SPVS|
| STX.WORKERS_SV|
| STX.XREF_REASON_CODES|
| STX.XREF_SERVICES|

8. `table_mappings_for_midsize_tables_set2` contains mappings for a set of midsize tables. These table are not currently used in any transformations. There are 16 tables.

| Table Name                |
|---------------------------|
| STX.APP_LOG|
| STX.APP_ACCESS_LOG_DETL|
| STX.CALLS_PROC_QUEUE|
| STX.TABLE_ALERT_NOSHOW|
| STX.APP_ACCESS_LOG|
| STX.TRANSFER_MSG_FILES|
| STX.CALLS_VOICEMSG|
| STX.APP_RUNSCHEDULES|
| STX.APP_ROLE_OBJ_PRIVS_LOG|
| STX.CALLS_NOTES|
| STX.LOC_CARE_PLAN_INFO|
| STX.APP_NOTIFICATIONS_SENT|
| STX.APP_USER_OBJ_PRIVS_LOG|
| STX.LOC_TRANS|
| STX.CALLS_FOB|
| STX.CALLS_SV|<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_dms_replication_task.dms-task-evvrepl-dwh-domo-tbl-calls-fc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dms_replication_task) | resource |
| [aws_dms_replication_task.dms-task-evvrepl-dwh-domo-tbl-midsize-tables-set1-fc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dms_replication_task) | resource |
| [aws_dms_replication_task.dms-task-evvrepl-dwh-domo-tbl-midsize-tables-set2-fc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dms_replication_task) | resource |
| [aws_dms_replication_task.dms-task-evvrepl-dwh-domo-tbl-schedule-fc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dms_replication_task) | resource |
| [aws_dms_replication_task.dms-task-evvrepl-dwh-domo-tbl-smaller-tables-set1-fc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dms_replication_task) | resource |
| [aws_dms_replication_task.dms-task-evvrepl-dwh-domo-tbl-visits-fc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dms_replication_task) | resource |
| [aws_dms_replication_task.dms-task-evvrepl-dwh-domo-tbl-visits-log-fc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dms_replication_task) | resource |
| [aws_dms_replication_task.dms-task-evvrepl-dwh-domo-tbl-wo-dms-op-colum-fc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dms_replication_task) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_environment"></a> [environment](#input\_environment) | n/a | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | n/a | `string` | n/a | yes |
| <a name="input_ri_arn"></a> [ri\_arn](#input\_ri\_arn) | n/a | `string` | n/a | yes |
| <a name="input_source_ep_arn"></a> [source\_ep\_arn](#input\_source\_ep\_arn) | n/a | `string` | n/a | yes |
| <a name="input_tag_application"></a> [tag\_application](#input\_tag\_application) | n/a | `string` | `"domo-dwh"` | no |
| <a name="input_tag_environment"></a> [tag\_environment](#input\_tag\_environment) | n/a | `string` | n/a | yes |
| <a name="input_tag_owner"></a> [tag\_owner](#input\_tag\_owner) | n/a | `string` | `"Infrastructure"` | no |
| <a name="input_tag_service"></a> [tag\_service](#input\_tag\_service) | n/a | `string` | `"domo-dwh"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | n/a | `map` | `{}` | no |
| <a name="input_target_ep_arn"></a> [target\_ep\_arn](#input\_target\_ep\_arn) | n/a | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_aws_dms_all_tables_part1_id"></a> [aws\_dms\_all\_tables\_part1\_id](#output\_aws\_dms\_all\_tables\_part1\_id) | DMS task id for domo evv dwh |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
