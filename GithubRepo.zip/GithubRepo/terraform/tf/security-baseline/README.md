# security-baseline

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.25.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_secure_baseline"></a> [secure\_baseline](#module\_secure\_baseline) | git@github.com:sandatech/terraform-module-aws-security-baseline.git | v0.0.4 |

## Resources

| Name | Type |
|------|------|
| [aws_iam_user.admin](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_user) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_organizations_organization.org](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/organizations_organization) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_account_type"></a> [account\_type](#input\_account\_type) | n/a | `map(string)` | <pre>{<br>  "admin-ue1": "master",<br>  "prod-ue1": "member",<br>  "prod2-ue1": "member",<br>  "qa-ue1": "member",<br>  "qa2-ue1": "member",<br>  "rd-ue1": "member",<br>  "sb-ue1": "member",<br>  "ss-ue1": "member",<br>  "stg-ue1": "member",<br>  "uat-ue1": "member"<br>}</pre> | no |
| <a name="input_audit_log_bucket_force_destroy"></a> [audit\_log\_bucket\_force\_destroy](#input\_audit\_log\_bucket\_force\_destroy) | n/a | `bool` | `true` | no |
| <a name="input_audit_s3_bucket_name"></a> [audit\_s3\_bucket\_name](#input\_audit\_s3\_bucket\_name) | The name of the S3 bucket to store various audit logs. | `string` | `"sandata-organization-audit-logs"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_master_account_id"></a> [master\_account\_id](#input\_master\_account\_id) | The ID of the master AWS account. | `string` | `"988716822681"` | no |
| <a name="input_member_accounts"></a> [member\_accounts](#input\_member\_accounts) | A list of IDs and emails of AWS accounts which associated as member accounts. | <pre>map(list(object({<br>    account_id = string<br>    email      = string<br>  })))</pre> | <pre>{<br>  "admin-ue1": [<br>    {<br>      "account_id": "546645935380",<br>      "email": "sandataadminstg@sandata.com"<br>    },<br>    {<br>      "account_id": "817297989338",<br>      "email": "awsadmin@sandata.com"<br>    },<br>    {<br>      "account_id": "046839536952",<br>      "email": "awsadminqa@sandata.com"<br>    },<br>    {<br>      "account_id": "797088103046",<br>      "email": "awsadminqa2@sandata.com"<br>    },<br>    {<br>      "account_id": "915867530647",<br>      "email": "awsadminsandbox@sandata.com"<br>    },<br>    {<br>      "account_id": "137598536613",<br>      "email": "awsadminsharedsvc@sandata.com"<br>    },<br>    {<br>      "account_id": "244940236506",<br>      "email": "awsadminuat@sandata.com"<br>    },<br>    {<br>      "account_id": "632674842498",<br>      "email": "awsadminprod@sandata.com"<br>    },<br>    {<br>      "account_id": "656560712260",<br>      "email": "awsadminprod2@sandata.com"<br>    }<br>  ],<br>  "prod-ue1": [],<br>  "prod2-ue1": [],<br>  "qa-ue1": [],<br>  "qa2-ue1": [],<br>  "rd-ue1": [],<br>  "sb-ue1": [],<br>  "ss-ue1": [],<br>  "stg-ue1": [],<br>  "uat-ue1": []<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_target_regions"></a> [target\_regions](#input\_target\_regions) | n/a | `list` | <pre>[<br>  "us-east-1",<br>  "us-east-2"<br>]</pre> | no |
| <a name="input_use_external_audit_log_bucket"></a> [use\_external\_audit\_log\_bucket](#input\_use\_external\_audit\_log\_bucket) | n/a | `map(bool)` | <pre>{<br>  "admin-ue1": false,<br>  "prod-ue1": true,<br>  "prod2-ue1": true,<br>  "qa-ue1": true,<br>  "qa2-ue1": true,<br>  "rd-ue1": true,<br>  "sb-ue1": true,<br>  "ss-ue1": true,<br>  "stg-ue1": true,<br>  "uat-ue1": true<br>}</pre> | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
