# sqs-migrator

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_sqs-migrator-01"></a> [sqs-migrator-01](#module\_sqs-migrator-01) | ./module-sqs-migrator-01 | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_filters"></a> [filters](#input\_filters) | Filters for the Cloudwatch event rules. The number drives the minute in which to kick off the cron schedule. | `map` | <pre>{<br>  "prod2-ue1": [<br>    {<br>      "dest": "INTEROP_ALT_EVV_SCHEDULE_QUEUE",<br>      "src": "INTEROP_ALT_EVV_SCHEDULE_BACKUP_QUEUE"<br>    },<br>    {<br>      "dest": "INTEROP_ALT_EVV_EMPLOYEE_QUEUE",<br>      "src": "INTEROP_ALT_EVV_EMPLOYEE_BACKUP_QUEUE"<br>    },<br>    {<br>      "dest": "INTEROP_ALT_EVV_VISIT_QUEUE",<br>      "src": "INTEROP_ALT_EVV_VISIT_BACKUP_QUEUE"<br>    }<br>  ],<br>  "rd-ue1": [<br>    {<br>      "dest": "INTEROP_ALT_EVV_SCHEDULE_BACKUP_QUEUE",<br>      "src": "INTEROP_ALT_EVV_SCHEDULE_QUEUE"<br>    },<br>    {<br>      "dest": "INTEROP_ALT_EVV_EMPLOYEE_BACKUP_QUEUE",<br>      "src": "INTEROP_ALT_EVV_EMPLOYEE_QUEUE"<br>    },<br>    {<br>      "dest": "INTEROP_ALT_EVV_VISIT_BACKUP_QUEUE",<br>      "src": "INTEROP_ALT_EVV_VISIT_QUEUE"<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_map_migrated"></a> [map\_migrated](#input\_map\_migrated) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "mig34085",<br>  "prod2-ue2": "mig34085",<br>  "qa-ue1": "mig34085",<br>  "qa-ue2": "mig34085",<br>  "rd-ue1": "mig34085",<br>  "rd-ue2": "mig34085",<br>  "sb-ue1": "mig34085",<br>  "ss-ue1": "mig34085",<br>  "uat-ue1": "mig34085",<br>  "uat-ue2": "mig34085"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_retention_in_days"></a> [retention\_in\_days](#input\_retention\_in\_days) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "7",<br>  "rd-ue1": "1"<br>}</pre> | no |
| <a name="input_schedule_expression"></a> [schedule\_expression](#input\_schedule\_expression) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "rate(30 minutes)",<br>  "rd-ue1": "rate(30 minutes)"<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
