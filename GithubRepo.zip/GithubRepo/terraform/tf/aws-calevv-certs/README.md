# aws-calevv-certs

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_acm_certificate.cert](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/acm_certificate) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_alternative_names"></a> [alternative\_names](#input\_alternative\_names) | n/a | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "*.prod2.us-east-1.sandata.com",<br>    "*.sandata.com",<br>    "*.calevv.com"<br>  ],<br>  "qa-ue1": [<br>    "*.qa.us-east-1.sandata.com",<br>    "*.sandata.com",<br>    "*.calevv.com"<br>  ],<br>  "rd-ue1": [<br>    "*.rd.us-east-1.sandata.com",<br>    "*.sandata.com",<br>    "*.calevv.com"<br>  ],<br>  "uat-ue1": [<br>    "*.uat.us-east-1.sandata.com",<br>    "*.sandata.com",<br>    "*.calevv.com"<br>  ]<br>}</pre> | no |
| <a name="input_domain_name"></a> [domain\_name](#input\_domain\_name) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "*.calevv.com",<br>  "qa-ue1": "*.calevv.com",<br>  "rd-ue1": "*.calevv.com",<br>  "uat-ue1": "*.calevv.com"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | AWS calevv.com certificate with automatic DNS renewal | `map(string)` | <pre>{<br>  "Application": "Certificate",<br>  "Backup": "",<br>  "OS": "",<br>  "Owner": "Infrastructure",<br>  "Patch_Cycle": "",<br>  "Provisioned_by": "Terraform",<br>  "Purpose": "AWS calevv.com certificate",<br>  "Security": "",<br>  "Service": "AWS Certificate Manager",<br>  "Version": "0.0.1"<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cert_arn"></a> [cert\_arn](#output\_cert\_arn) | n/a |
| <a name="output_cert_status"></a> [cert\_status](#output\_cert\_status) | n/a |
| <a name="output_domain_validation_options"></a> [domain\_validation\_options](#output\_domain\_validation\_options) | n/a |
| <a name="output_support_dns_names"></a> [support\_dns\_names](#output\_support\_dns\_names) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
