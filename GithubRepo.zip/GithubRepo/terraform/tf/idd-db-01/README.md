# amp-db-01

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ec2-db01"></a> [ec2-db01](#module\_ec2-db01) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.7 |
| <a name="module_ec2-db02"></a> [ec2-db02](#module\_ec2-db02) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.7 |
| <a name="module_ec2-fs"></a> [ec2-fs](#module\_ec2-fs) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.5 |
| <a name="module_module-db-sg"></a> [module-db-sg](#module\_module-db-sg) | git@github.com:sandatech/terraform-aws-module-security-groups-01.git | v0.0.6 |
| <a name="module_module-fs-sg"></a> [module-fs-sg](#module\_module-fs-sg) | git@github.com:sandatech/terraform-aws-module-security-groups-01.git | v0.0.6 |
| <a name="module_module-fsx-sg"></a> [module-fsx-sg](#module\_module-fsx-sg) | git@github.com:sandatech/terraform-aws-module-security-groups-01.git | v0.0.6 |

## Resources

| Name | Type |
|------|------|
| [aws_fsx_windows_file_system.idd](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/fsx_windows_file_system) | resource |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_active_directory_id"></a> [active\_directory\_id](#input\_active\_directory\_id) | n/a | `map` | <pre>{<br>  "rd-ue1": "d-9067094359"<br>}</pre> | no |
| <a name="input_ami_id_db01"></a> [ami\_id\_db01](#input\_ami\_id\_db01) | n/a | `map(string)` | <pre>{<br>  "rd-ue1": "ami-0efd0e356e33d31de"<br>}</pre> | no |
| <a name="input_ami_id_db02"></a> [ami\_id\_db02](#input\_ami\_id\_db02) | n/a | `map(string)` | <pre>{<br>  "rd-ue1": "ami-0efd0e356e33d31de"<br>}</pre> | no |
| <a name="input_create_db02"></a> [create\_db02](#input\_create\_db02) | n/a | `map(bool)` | <pre>{<br>  "rd-ue1": true<br>}</pre> | no |
| <a name="input_create_fs01"></a> [create\_fs01](#input\_create\_fs01) | n/a | `map(bool)` | <pre>{<br>  "rd-ue1": true<br>}</pre> | no |
| <a name="input_db01_associate_public_ip"></a> [db01\_associate\_public\_ip](#input\_db01\_associate\_public\_ip) | db01 associate public ip | `map(bool)` | <pre>{<br>  "rd-ue1": false<br>}</pre> | no |
| <a name="input_db01_instance_count"></a> [db01\_instance\_count](#input\_db01\_instance\_count) | db01 instance count | `map(number)` | <pre>{<br>  "rd-ue1": 1<br>}</pre> | no |
| <a name="input_db01_instance_type"></a> [db01\_instance\_type](#input\_db01\_instance\_type) | db01 instance type | `map(string)` | <pre>{<br>  "rd-ue1": "m5d.xlarge"<br>}</pre> | no |
| <a name="input_db02_associate_public_ip"></a> [db02\_associate\_public\_ip](#input\_db02\_associate\_public\_ip) | db02 associate public ip | `map(bool)` | <pre>{<br>  "rd-ue1": false<br>}</pre> | no |
| <a name="input_db02_instance_count"></a> [db02\_instance\_count](#input\_db02\_instance\_count) | db02 instance count | `map(number)` | <pre>{<br>  "rd-ue1": 1<br>}</pre> | no |
| <a name="input_db02_instance_type"></a> [db02\_instance\_type](#input\_db02\_instance\_type) | db02 instance type | `map(string)` | <pre>{<br>  "rd-ue1": "m5d.xlarge"<br>}</pre> | no |
| <a name="input_ebs_optimized_db01"></a> [ebs\_optimized\_db01](#input\_ebs\_optimized\_db01) | n/a | `map(bool)` | <pre>{<br>  "rd-ue1": false<br>}</pre> | no |
| <a name="input_ebs_optimized_db02"></a> [ebs\_optimized\_db02](#input\_ebs\_optimized\_db02) | n/a | `map(bool)` | <pre>{<br>  "rd-ue1": true<br>}</pre> | no |
| <a name="input_ebs_volumes_db01"></a> [ebs\_volumes\_db01](#input\_ebs\_volumes\_db01) | n/a | `map` | <pre>{<br>  "rd-ue1": [<br>    {<br>      "device_name": "xvdb",<br>      "encrypted": true,<br>      "volume_size": 150,<br>      "volume_type": "gp3"<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_ebs_volumes_db02"></a> [ebs\_volumes\_db02](#input\_ebs\_volumes\_db02) | n/a | `map` | <pre>{<br>  "rd-ue1": [<br>    {<br>      "device_name": "xvdb",<br>      "encrypted": true,<br>      "volume_size": 150,<br>      "volume_type": "gp3"<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_ec2_fs_ami"></a> [ec2\_fs\_ami](#input\_ec2\_fs\_ami) | ec2 fs ami | `map(string)` | <pre>{<br>  "rd-ue1": "ami-0efd0e356e33d31de"<br>}</pre> | no |
| <a name="input_ec2_fs_associate_public_ip_address"></a> [ec2\_fs\_associate\_public\_ip\_address](#input\_ec2\_fs\_associate\_public\_ip\_address) | ec2 fs associate public ip | `map(bool)` | <pre>{<br>  "rd-ue1": false<br>}</pre> | no |
| <a name="input_ec2_fs_chard"></a> [ec2\_fs\_chard](#input\_ec2\_fs\_chard) | ec2-fs fs shard | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "uat-ue1": ""<br>}</pre> | no |
| <a name="input_ec2_fs_instance_count"></a> [ec2\_fs\_instance\_count](#input\_ec2\_fs\_instance\_count) | ec2-fs instance count | `map(number)` | <pre>{<br>  "rd-ue1": 1<br>}</pre> | no |
| <a name="input_ec2_fs_instance_type"></a> [ec2\_fs\_instance\_type](#input\_ec2\_fs\_instance\_type) | ec2-fs instance type | `map(string)` | <pre>{<br>  "rd-ue1": "t3.medium"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_fsx_size"></a> [fsx\_size](#input\_fsx\_size) | n/a | `map` | <pre>{<br>  "rd-ue1": 500<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_root_block_device"></a> [root\_block\_device](#input\_root\_block\_device) | n/a | `map` | <pre>{<br>  "rd-ue1": [<br>    {<br>      "encrypted": true,<br>      "volume_size": 200,<br>      "volume_type": "gp3"<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_throughput_capacity"></a> [throughput\_capacity](#input\_throughput\_capacity) | n/a | `map` | <pre>{<br>  "rd-ue1": 1024<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_db_security_group"></a> [db\_security\_group](#output\_db\_security\_group) | The security group ec2 instance |
| <a name="output_fs_security_group"></a> [fs\_security\_group](#output\_fs\_security\_group) | The security group ec2 instance |
| <a name="output_instances_private_ips_db01"></a> [instances\_private\_ips\_db01](#output\_instances\_private\_ips\_db01) | Private IPs assigned to the EC2 instance |
| <a name="output_instances_private_ips_db02"></a> [instances\_private\_ips\_db02](#output\_instances\_private\_ips\_db02) | Private IPs assigned to the EC2 instance |
| <a name="output_instances_private_ips_fs"></a> [instances\_private\_ips\_fs](#output\_instances\_private\_ips\_fs) | Private IPs assigned to the EC2 instance |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
