# tfc-configuration

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_tfe"></a> [tfe](#provider\_tfe) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [tfe_workspace.s3_interfaces_replication](https://registry.terraform.io/providers/hashicorp/tfe/latest/docs/data-sources/workspace) | data source |
| [tfe_workspace.vpc_peering_ss_ue1](https://registry.terraform.io/providers/hashicorp/tfe/latest/docs/data-sources/workspace) | data source |
| [tfe_workspace.vpc_peering_ss_ue2](https://registry.terraform.io/providers/hashicorp/tfe/latest/docs/data-sources/workspace) | data source |
| [tfe_workspace.vpc_peering_ue1](https://registry.terraform.io/providers/hashicorp/tfe/latest/docs/data-sources/workspace) | data source |
| [tfe_workspace.vpc_peering_ue2](https://registry.terraform.io/providers/hashicorp/tfe/latest/docs/data-sources/workspace) | data source |
| [tfe_workspace_ids.all](https://registry.terraform.io/providers/hashicorp/tfe/latest/docs/data-sources/workspace_ids) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_admin_access_key"></a> [admin\_access\_key](#input\_admin\_access\_key) | IAM access key for the Admin account. | `string` | `""` | no |
| <a name="input_admin_secret_key"></a> [admin\_secret\_key](#input\_admin\_secret\_key) | IAM secret key for the Admin account. | `string` | `""` | no |
| <a name="input_newrelic_account_id"></a> [newrelic\_account\_id](#input\_newrelic\_account\_id) | NewRelic Account ID. | `string` | `""` | no |
| <a name="input_newrelic_api_key"></a> [newrelic\_api\_key](#input\_newrelic\_api\_key) | NewRelic API Key. | `string` | `""` | no |
| <a name="input_newrelic_region"></a> [newrelic\_region](#input\_newrelic\_region) | NewRelic Region. | `string` | `"US"` | no |
| <a name="input_organization_token"></a> [organization\_token](#input\_organization\_token) | Token for the Terraform Cloud Sandata organization. | `string` | `""` | no |
| <a name="input_prod2_access_key"></a> [prod2\_access\_key](#input\_prod2\_access\_key) | IAM access key for the Prod2 account. | `string` | `""` | no |
| <a name="input_prod2_secret_key"></a> [prod2\_secret\_key](#input\_prod2\_secret\_key) | IAM secret key for the Prod2 account. | `string` | `""` | no |
| <a name="input_prod_access_key"></a> [prod\_access\_key](#input\_prod\_access\_key) | IAM access key for the Prod account. | `string` | `""` | no |
| <a name="input_prod_secret_key"></a> [prod\_secret\_key](#input\_prod\_secret\_key) | IAM secret key for the Prod account. | `string` | `""` | no |
| <a name="input_qa2_access_key"></a> [qa2\_access\_key](#input\_qa2\_access\_key) | IAM access key for the QA2 account. | `string` | `""` | no |
| <a name="input_qa2_secret_key"></a> [qa2\_secret\_key](#input\_qa2\_secret\_key) | IAM secret key for the QA2 account. | `string` | `""` | no |
| <a name="input_qa_access_key"></a> [qa\_access\_key](#input\_qa\_access\_key) | IAM access key for the QA account. | `string` | `""` | no |
| <a name="input_qa_secret_key"></a> [qa\_secret\_key](#input\_qa\_secret\_key) | IAM secret key for the QA account. | `string` | `""` | no |
| <a name="input_rd_access_key"></a> [rd\_access\_key](#input\_rd\_access\_key) | IAM access key for the RD account. | `string` | `""` | no |
| <a name="input_rd_secret_key"></a> [rd\_secret\_key](#input\_rd\_secret\_key) | IAM secret key for the RD account. | `string` | `""` | no |
| <a name="input_sandbox_access_key"></a> [sandbox\_access\_key](#input\_sandbox\_access\_key) | IAM access key for the Sandbox account. | `string` | `""` | no |
| <a name="input_sandbox_secret_key"></a> [sandbox\_secret\_key](#input\_sandbox\_secret\_key) | IAM secret key for the Sandbox account. | `string` | `""` | no |
| <a name="input_ss_access_key"></a> [ss\_access\_key](#input\_ss\_access\_key) | IAM access key for the Shared Services account. | `string` | `""` | no |
| <a name="input_ss_secret_key"></a> [ss\_secret\_key](#input\_ss\_secret\_key) | IAM secret key for the Shared Services account. | `string` | `""` | no |
| <a name="input_stg_access_key"></a> [stg\_access\_key](#input\_stg\_access\_key) | IAM access key for the Stage account. | `string` | `""` | no |
| <a name="input_stg_secret_key"></a> [stg\_secret\_key](#input\_stg\_secret\_key) | IAM secret key for the Stage account. | `string` | `""` | no |
| <a name="input_uat_access_key"></a> [uat\_access\_key](#input\_uat\_access\_key) | IAM access key for the UAT account. | `string` | `""` | no |
| <a name="input_uat_secret_key"></a> [uat\_secret\_key](#input\_uat\_secret\_key) | IAM secret key for the UAT account. | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_all_workspaces"></a> [all\_workspaces](#output\_all\_workspaces) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
