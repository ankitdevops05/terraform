As a part of SMC DR Failover process, need to move the data from EC2-managed RabbitMQ in VA to AWS-managed RabbitMQ and vice versa

More details in: https://knowledge.sandata.com/display/AWS/RabbitMQ+Shovel+Queues