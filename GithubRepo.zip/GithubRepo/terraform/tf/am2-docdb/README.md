# am2-docdb

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_docdb"></a> [docdb](#module\_docdb) | git@github.com:sandatech/terraform-aws-module-documentdb-01.git | v0.0.4 |

## Resources

| Name | Type |
|------|------|
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_allowed_cidrs"></a> [allowed\_cidrs](#input\_allowed\_cidrs) | List of VPC security groups to associate | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "10.14.8.0/22",<br>    "10.15.0.0/20",<br>    "172.19.0.0/19"<br>  ],<br>  "qa-ue1": [<br>    "10.14.8.0/22",<br>    "172.19.0.0/19",<br>    "10.15.0.0/20"<br>  ],<br>  "rd-ue1": [<br>    "10.14.8.0/22",<br>    "10.15.0.0/20",<br>    "172.19.0.0/19"<br>  ],<br>  "rd-ue2": [<br>    "10.14.8.0/22",<br>    "10.15.0.0/20",<br>    "172.19.0.0/19"<br>  ],<br>  "uat-ue1": [<br>    "10.14.8.0/22",<br>    "10.15.0.0/20",<br>    "172.19.0.0/19"<br>  ]<br>}</pre> | no |
| <a name="input_aws_docdb_cluster_instance_count"></a> [aws\_docdb\_cluster\_instance\_count](#input\_aws\_docdb\_cluster\_instance\_count) | docdb cluster instance count | `map(number)` | <pre>{<br>  "prod2-ue1": 1,<br>  "qa-ue1": 1,<br>  "rd-ue1": 1,<br>  "rd-ue2": 1,<br>  "uat-ue1": 1<br>}</pre> | no |
| <a name="input_aws_docdb_cluster_instance_db_type"></a> [aws\_docdb\_cluster\_instance\_db\_type](#input\_aws\_docdb\_cluster\_instance\_db\_type) | docdb cluster instance db type | `map(string)` | <pre>{<br>  "prod2-ue1": "db.r5.large",<br>  "qa-ue1": "db.r5.large",<br>  "rd-ue1": "db.r5.large",<br>  "rd-ue2": "db.r5.large",<br>  "uat-ue1": "db.r5.large"<br>}</pre> | no |
| <a name="input_aws_docdb_clustername"></a> [aws\_docdb\_clustername](#input\_aws\_docdb\_clustername) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "sd-prod2-us-east-1-docdb-am2-cluster",<br>  "qa-ue1": "sd-qa-us-east-1-docbd-am2-cluster",<br>  "rd-ue1": "sd-rd-us-east-1-docbd-am2-cluster",<br>  "rd-ue2": "sd-rd-us-east-2-docbd-am2-cluster",<br>  "uat-ue1": "sd-uat-us-east-1-docdb-am2-cluster"<br>}</pre> | no |
| <a name="input_aws_docdb_parameter_group_family"></a> [aws\_docdb\_parameter\_group\_family](#input\_aws\_docdb\_parameter\_group\_family) | Description: aws\_docdb\_username | `map(string)` | <pre>{<br>  "prod2-ue1": "docdb3.6",<br>  "qa-ue1": "docdb3.6",<br>  "rd-ue1": "docdb3.6",<br>  "rd-ue2": "docdb4.0",<br>  "uat-ue1": "docdb3.6"<br>}</pre> | no |
| <a name="input_aws_docdb_password"></a> [aws\_docdb\_password](#input\_aws\_docdb\_password) | Description: aws\_docdb\_password | `string` | `""` | no |
| <a name="input_docdb_ca_cert_identifier"></a> [docdb\_ca\_cert\_identifier](#input\_docdb\_ca\_cert\_identifier) | docdb ca cert identifier | `map(string)` | <pre>{<br>  "prod2-ue1": "rds-ca-2019",<br>  "qa-ue1": "rds-ca-2019",<br>  "rd-ue1": "rds-ca-2019",<br>  "rd-ue2": "rds-ca-2019",<br>  "uat-ue1": "rds-ca-2019"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_name"></a> [name](#input\_name) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "sd-prod2-us-east-1-docdb-am2",<br>  "qa-ue1": "sd-qa-us-east-1-docbd-am2",<br>  "rd-ue1": "sd-rd-us-east-1-docbd-am2",<br>  "rd-ue2": "sd-rd-us-east-1-docbd-am2",<br>  "uat-ue1": "sd-uat-us-east-1-docdb-am2"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_username"></a> [username](#input\_username) | Description: aws\_docdb\_username | `map(string)` | <pre>{<br>  "prod2-ue1": "am2user",<br>  "qa-ue1": "am2user",<br>  "rd-ue1": "am2user",<br>  "rd-ue2": "am2user",<br>  "uat-ue1": "am2user"<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_aws_docdb_cluster_endpoint"></a> [aws\_docdb\_cluster\_endpoint](#output\_aws\_docdb\_cluster\_endpoint) | aws\_docdb\_cluster\_endpoint |
| <a name="output_aws_docdb_cluster_identifier"></a> [aws\_docdb\_cluster\_identifier](#output\_aws\_docdb\_cluster\_identifier) | aws docdb cluster identifier |
| <a name="output_aws_docdb_cluster_port"></a> [aws\_docdb\_cluster\_port](#output\_aws\_docdb\_cluster\_port) | aws\_docdb\_cluster\_port |
| <a name="output_final_snapshot_identifier"></a> [final\_snapshot\_identifier](#output\_final\_snapshot\_identifier) | Final Snapshot |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
