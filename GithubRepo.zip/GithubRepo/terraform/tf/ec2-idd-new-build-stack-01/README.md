# ec2-idd-new-build-stack-01:  Complete new EC2 instances built for IDD

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
