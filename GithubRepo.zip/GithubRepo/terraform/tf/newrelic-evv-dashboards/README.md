# newrelic-evv-dashboards

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.0 |
| <a name="requirement_newrelic"></a> [newrelic](#requirement\_newrelic) | >=2.43.4 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_newrelic"></a> [newrelic](#provider\_newrelic) | >=2.43.4 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [newrelic_one_dashboard.apm_dashboards](https://registry.terraform.io/providers/newrelic/newrelic/latest/docs/resources/one_dashboard) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_newrelic_account_id"></a> [newrelic\_account\_id](#input\_newrelic\_account\_id) | n/a | `any` | n/a | yes |
| <a name="input_newrelic_api_key"></a> [newrelic\_api\_key](#input\_newrelic\_api\_key) | n/a | `any` | n/a | yes |
| <a name="input_newrelic_region"></a> [newrelic\_region](#input\_newrelic\_region) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_dashboard_url"></a> [dashboard\_url](#output\_dashboard\_url) | A permalink to apm\_dashboards |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
