# s3-security-exports

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_s3_visit_capture"></a> [s3\_visit\_capture](#module\_s3\_visit\_capture) | git@github.com:sandatech/terraform-aws-module-s3-com-sandata-and-access-user.git | v0.0.9 |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_s3_bucket_actions"></a> [s3\_bucket\_actions](#input\_s3\_bucket\_actions) | n/a | `map` | <pre>{<br>  "prod2-ue1": [<br>    "s3:GetObject*",<br>    "s3:ListBucket*",<br>    "s3:PutObject*"<br>  ],<br>  "qa-ue1": [<br>    "s3:GetObject*",<br>    "s3:ListBucket*",<br>    "s3:PutObject*"<br>  ],<br>  "rd-ue1": [<br>    "s3:GetObject*",<br>    "s3:ListBucket*",<br>    "s3:PutObject*"<br>  ],<br>  "ss-ue1": [<br>    "s3:GetObject*",<br>    "s3:ListBucket*",<br>    "s3:PutObject*"<br>  ],<br>  "uat-ue1": [<br>    "s3:GetObject*",<br>    "s3:ListBucket*",<br>    "s3:PutObject*"<br>  ]<br>}</pre> | no |
| <a name="input_s3_version_enabled"></a> [s3\_version\_enabled](#input\_s3\_version\_enabled) | n/a | `map` | <pre>{<br>  "prod2-ue1": true,<br>  "qa-ue1": false,<br>  "rd-ue1": false,<br>  "ss-ue1": false,<br>  "uat-ue1": false<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_s3_access_user_arn"></a> [s3\_access\_user\_arn](#output\_s3\_access\_user\_arn) | n/a |
| <a name="output_s3_access_user_key"></a> [s3\_access\_user\_key](#output\_s3\_access\_user\_key) | n/a |
| <a name="output_s3_access_user_secret"></a> [s3\_access\_user\_secret](#output\_s3\_access\_user\_secret) | n/a |
| <a name="output_s3_bucket_arn"></a> [s3\_bucket\_arn](#output\_s3\_bucket\_arn) | n/a |
| <a name="output_s3_bucket_policy_arn"></a> [s3\_bucket\_policy\_arn](#output\_s3\_bucket\_policy\_arn) | n/a |
| <a name="output_s3_bucket_region"></a> [s3\_bucket\_region](#output\_s3\_bucket\_region) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
