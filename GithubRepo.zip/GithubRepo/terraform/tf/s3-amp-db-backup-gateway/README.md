# S3 Storage Gateways for AMP DB Backups

This particular terraform code must be run from a local host.  The terraform binary must do a curl to a private EC2 instance IP and thus Terraform Cloud will not be able to reach this IP.  You must set the provider information for the environment that you're working in and an AD username and password that can join the storage gateway to the sandata.local domain.

# Setup
S3 Storage Gateways include the following components
1. EC2 Instance which runs an AWS Appliance for Storage Gateway
2. EBS Volume on the EC2 Instance which serves as a cache drive
3. Storage Gateway itself
4. S3 Bucket
5. Storage Gateway File Shares<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ec2"></a> [ec2](#module\_ec2) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.6 |
| <a name="module_records"></a> [records](#module\_records) | git@github.com:sandatech/terraform-aws-route53-1.git//modules/records | n/a |
| <a name="module_s3_buckets"></a> [s3\_buckets](#module\_s3\_buckets) | git@github.com:sandatech/terraform-aws-s3-bucket.git | n/a |
| <a name="module_storage_gateway_endpoint_sg"></a> [storage\_gateway\_endpoint\_sg](#module\_storage\_gateway\_endpoint\_sg) | git@github.com:sandatech/terraform-aws-module-security-groups-01.git | n/a |
| <a name="module_storage_gateway_sg"></a> [storage\_gateway\_sg](#module\_storage\_gateway\_sg) | git@github.com:sandatech/terraform-aws-module-security-groups-01.git | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_iam_role.sg_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_storagegateway_cache.sgcache](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/storagegateway_cache) | resource |
| [aws_storagegateway_gateway.ampbackup](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/storagegateway_gateway) | resource |
| [aws_storagegateway_smb_file_share.fileshares](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/storagegateway_smb_file_share) | resource |
| [aws_vpc_endpoint.storagegw](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/vpc_endpoint) | resource |
| [aws_storagegateway_local_disk.cachedata](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/storagegateway_local_disk) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_ami"></a> [ami](#input\_ami) | n/a | `string` | `"ami-044238dc0ff5b8208"` | no |
| <a name="input_cache_disk_name"></a> [cache\_disk\_name](#input\_cache\_disk\_name) | n/a | `string` | `"/dev/xvdb"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_iam_profile"></a> [iam\_profile](#input\_iam\_profile) | n/a | `string` | `"EC2-Domain-Join"` | no |
| <a name="input_iam_resource"></a> [iam\_resource](#input\_iam\_resource) | n/a | `map` | <pre>{<br>  "prod2-ue1": [<br>    "arn:aws:s3:::com-sandata-amp-prod2-db-backup",<br>    "arn:aws:s3:::com-sandata-amp-prod2-db-backup/*"<br>  ],<br>  "ss-ue1": [<br>    "arn:aws:s3:::com-sandata-ss-amp-rd-db-backup",<br>    "arn:aws:s3:::com-sandata-ss-amp-qa-db-backup",<br>    "arn:aws:s3:::com-sandata-ss-amp-uat-db-backup",<br>    "arn:aws:s3:::com-sandata-ss-amp-rd-db-backup/*",<br>    "arn:aws:s3:::com-sandata-ss-amp-qa-db-backup/*",<br>    "arn:aws:s3:::com-sandata-ss-amp-uat-db-backup/*"<br>  ]<br>}</pre> | no |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | n/a | `string` | `"m5.xlarge"` | no |
| <a name="input_instances_number"></a> [instances\_number](#input\_instances\_number) | n/a | `number` | `1` | no |
| <a name="input_keypair"></a> [keypair](#input\_keypair) | n/a | `map` | <pre>{<br>  "prod2-ue1": "sd-prod2-us-east-1-keypair01",<br>  "ss-ue1": "sd-ss-us-east-1-keypair01"<br>}</pre> | no |
| <a name="input_lifecycle_rule"></a> [lifecycle\_rule](#input\_lifecycle\_rule) | n/a | `map` | <pre>{<br>  "prod2-ue1": [<br>    {<br>      "enabled": true,<br>      "expiration": {<br>        "days": 8<br>      },<br>      "id": "daily",<br>      "prefix": "daily/"<br>    },<br>    {<br>      "enabled": true,<br>      "expiration": {<br>        "days": 31<br>      },<br>      "id": "weekly",<br>      "prefix": "weekly/",<br>      "transition": [<br>        {<br>          "days": 7,<br>          "storage_class": "GLACIER"<br>        }<br>      ]<br>    },<br>    {<br>      "enabled": true,<br>      "expiration": {<br>        "months": 12<br>      },<br>      "id": "monthly",<br>      "prefix": "monthly/",<br>      "transition": [<br>        {<br>          "days": 31,<br>          "storage_class": "DEEP_ARCHIVE"<br>        }<br>      ]<br>    },<br>    {<br>      "enabled": true,<br>      "expiration": {<br>        "years": 7<br>      },<br>      "id": "yearly",<br>      "prefix": "yearly/",<br>      "transition": [<br>        {<br>          "days": 1,<br>          "storage_class": "DEEP_ARCHIVE"<br>        }<br>      ]<br>    }<br>  ],<br>  "ss-ue1": [<br>    {<br>      "enabled": true,<br>      "expiration": {<br>        "days": 31<br>      },<br>      "id": "expirebackups",<br>      "prefix": "/"<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_password"></a> [password](#input\_password) | n/a | `string` | `""` | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_route53_zone"></a> [route53\_zone](#input\_route53\_zone) | n/a | `map` | <pre>{<br>  "prod2-ue1": "Z08705443VKPJM2VC28CK",<br>  "ss-ue1": "Z10086452LTNQEPZONTTM"<br>}</pre> | no |
| <a name="input_s3_buckets"></a> [s3\_buckets](#input\_s3\_buckets) | n/a | `map` | <pre>{<br>  "prod2-ue1": [<br>    "com-sandata-amp-prod2-db-backup"<br>  ],<br>  "ss-ue1": [<br>    "com-sandata-ss-amp-rd-db-backup",<br>    "com-sandata-ss-amp-qa-db-backup",<br>    "com-sandata-ss-amp-uat-db-backup"<br>  ]<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_security_group_egress"></a> [security\_group\_egress](#input\_security\_group\_egress) | n/a | `map` | <pre>{<br>  "prod2-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "0.0.0.0/0"<br>      ],<br>      "description": "Allow All",<br>      "from_port": [<br>        "0"<br>      ],<br>      "protocols": [<br>        "tcp",<br>        "udp"<br>      ],<br>      "to_port": [<br>        "65535"<br>      ]<br>    }<br>  ],<br>  "ss-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "0.0.0.0/0"<br>      ],<br>      "description": "Allow All",<br>      "from_port": [<br>        "0"<br>      ],<br>      "protocols": [<br>        "tcp",<br>        "udp"<br>      ],<br>      "to_port": [<br>        "65535"<br>      ]<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_sg_endpoint_security_group_ingress"></a> [sg\_endpoint\_security\_group\_ingress](#input\_sg\_endpoint\_security\_group\_ingress) | n/a | `map` | <pre>{<br>  "prod2-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "10.15.0.0/20",<br>        "172.16.32.0/19"<br>      ],<br>      "description": "VPN and AWS IPs",<br>      "from_port": [<br>        "443",<br>        "1026",<br>        "1027",<br>        "1028",<br>        "1031"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "443",<br>        "1026",<br>        "1027",<br>        "1028",<br>        "1031"<br>      ]<br>    }<br>  ],<br>  "ss-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "10.15.0.0/20",<br>        "172.16.128.0/19",<br>        "172.16.64.0/19",<br>        "172.16.224.0/19",<br>        "172.16.192.0/19",<br>        "172.16.206.61/32"<br>      ],<br>      "description": "VPN and AWS IPs",<br>      "from_port": [<br>        "443",<br>        "1026",<br>        "1027",<br>        "1028",<br>        "1031"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "443",<br>        "1026",<br>        "1027",<br>        "1028",<br>        "1031"<br>      ]<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_sg_security_group_ingress"></a> [sg\_security\_group\_ingress](#input\_sg\_security\_group\_ingress) | n/a | `map` | <pre>{<br>  "prod2-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "10.15.0.0/20",<br>        "172.16.32.0/19",<br>        "10.8.128.32/27"<br>      ],<br>      "description": "VPN and AWS IPs",<br>      "from_port": [<br>        "445",<br>        "80"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "445",<br>        "80"<br>      ]<br>    }<br>  ],<br>  "ss-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "10.15.0.0/20",<br>        "172.16.128.0/19",<br>        "172.16.64.0/19",<br>        "172.16.224.0/19",<br>        "172.16.192.0/19",<br>        "172.17.128.0/19",<br>        "10.10.160.0/20",<br>        "10.10.128.0/20",<br>        "10.12.192.0/20"<br>      ],<br>      "description": "VPN and AWS IPs",<br>      "from_port": [<br>        "445",<br>        "80"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "445",<br>        "80"<br>      ]<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_sqlserviceuser"></a> [sqlserviceuser](#input\_sqlserviceuser) | n/a | `map` | <pre>{<br>  "prod2-ue1": [<br>    "prod2sqlservices"<br>  ],<br>  "ss-ue1": [<br>    "rdsqlservices",<br>    "qasqlservices",<br>    "uatsqlservices"<br>  ]<br>}</pre> | no |
| <a name="input_username"></a> [username](#input\_username) | n/a | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_aws_storagegateway_gateway_arn"></a> [aws\_storagegateway\_gateway\_arn](#output\_aws\_storagegateway\_gateway\_arn) | n/a |
| <a name="output_instances_private_ips"></a> [instances\_private\_ips](#output\_instances\_private\_ips) | Private IPs assigned to the EC2 instance |
| <a name="output_storage_gw_dns"></a> [storage\_gw\_dns](#output\_storage\_gw\_dns) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
