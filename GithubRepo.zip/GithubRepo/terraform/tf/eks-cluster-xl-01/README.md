# eks-cluster-xl-01

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 4.67.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 4.67.0 |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_eks"></a> [eks](#module\_eks) | git@github.com:sandatech/terraform-aws-module-eks-01.git | v0.0.26 |

## Resources

| Name | Type |
|------|------|
| [aws_autoscaling_schedule.eks_cluster_down](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/autoscaling_schedule) | resource |
| [aws_autoscaling_schedule.eks_cluster_up](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/autoscaling_schedule) | resource |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_autoscaling_group_name"></a> [autoscaling\_group\_name](#input\_autoscaling\_group\_name) | n/a | `map(string)` | <pre>{<br>  "qa-ue1": "",<br>  "rd-ue1": "aws-eks-asg-rd-xl-012021010721122395210000000b",<br>  "uat-ue1": "aws-eks-asg-uat-xl-012021042814444919270000000b"<br>}</pre> | no |
| <a name="input_aws_eks_addon_version_most_recent"></a> [aws\_eks\_addon\_version\_most\_recent](#input\_aws\_eks\_addon\_version\_most\_recent) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": true,<br>  "qa-ue1": true,<br>  "rd-ue1": true,<br>  "rd-ue2": false,<br>  "sb-ue1": false,<br>  "ss-ue1": false,<br>  "uat-ue1": true<br>}</pre> | no |
| <a name="input_aws_eks_addons_enable"></a> [aws\_eks\_addons\_enable](#input\_aws\_eks\_addons\_enable) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": true,<br>  "qa-ue1": true,<br>  "rd-ue1": true,<br>  "rd-ue2": false,<br>  "sb-ue1": false,<br>  "ss-ue1": true,<br>  "uat-ue1": true<br>}</pre> | no |
| <a name="input_desired_capacity"></a> [desired\_capacity](#input\_desired\_capacity) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "4",<br>  "qa-ue1": "0",<br>  "rd-ue1": "0",<br>  "uat-ue1": "5"<br>}</pre> | no |
| <a name="input_eks_ami"></a> [eks\_ami](#input\_eks\_ami) | AMI to use for cluster. | `map(string)` | <pre>{<br>  "prod2-ue1": "ami-0f1b832b8b8057046",<br>  "qa-ue1": "ami-0f1b832b8b8057046",<br>  "rd-ue1": "ami-0f1b832b8b8057046",<br>  "uat-ue1": "ami-0f1b832b8b8057046"<br>}</pre> | no |
| <a name="input_eks_version"></a> [eks\_version](#input\_eks\_version) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "1.25",<br>  "qa-ue1": "1.25",<br>  "rd-ue1": "1.25",<br>  "uat-ue1": "1.25"<br>}</pre> | no |
| <a name="input_enable_schedule_scaling"></a> [enable\_schedule\_scaling](#input\_enable\_schedule\_scaling) | n/a | `map(bool)` | <pre>{<br>  "prod2-ue1": false,<br>  "qa-ue1": false,<br>  "rd-ue1": false,<br>  "rd-ue2": false,<br>  "sb-ue1": false,<br>  "ss-ue1": false,<br>  "uat-ue1": true<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_external_ip"></a> [external\_ip](#input\_external\_ip) | n/a | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "207.140.140.193/32",<br>    "172.19.0.0/19",<br>    "10.15.0.0/20",<br>    "192.168.138.0/24",<br>    "172.16.197.243/32",<br>    "172.16.198.25/32",<br>    "172.16.206.61/32"<br>  ],<br>  "qa-ue1": [<br>    "207.140.140.193/32",<br>    "172.19.0.0/19",<br>    "10.15.0.0/20",<br>    "192.168.138.0/24",<br>    "172.16.197.243/32",<br>    "172.16.198.25/32",<br>    "172.16.206.61/32"<br>  ],<br>  "rd-ue1": [<br>    "207.140.140.193/32",<br>    "172.19.0.0/19",<br>    "10.15.0.0/20",<br>    "192.168.138.0/24",<br>    "172.16.197.243/32",<br>    "172.16.198.25/32",<br>    "172.16.206.61/32"<br>  ],<br>  "uat-ue1": [<br>    "207.140.140.193/32",<br>    "172.19.0.0/19",<br>    "10.15.0.0/20",<br>    "192.168.138.0/24",<br>    "172.16.197.243/32",<br>    "172.16.198.25/32",<br>    "172.16.206.61/32"<br>  ]<br>}</pre> | no |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "m5.4xlarge",<br>  "qa-ue1": "t3.medium",<br>  "rd-ue1": "m5.2xlarge",<br>  "uat-ue1": "m5.2xlarge"<br>}</pre> | no |
| <a name="input_kubelet_extra_args"></a> [kubelet\_extra\_args](#input\_kubelet\_extra\_args) | Space-delimited list of extra arguments to pass to kubelet | `map(string)` | <pre>{<br>  "prod2-ue1": "--max-pods=54",<br>  "qa-ue1": "--max-pods=54",<br>  "rd-ue1": "--max-pods=54",<br>  "uat-ue1": "--max-pods=54"<br>}</pre> | no |
| <a name="input_launch_configuration_enabled"></a> [launch\_configuration\_enabled](#input\_launch\_configuration\_enabled) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": true,<br>  "prod2-ue2": true,<br>  "qa-ue1": true,<br>  "qa-ue2": true,<br>  "rd-ue1": true,<br>  "rd-ue2": true,<br>  "sb-ue1": true,<br>  "ss-ue1": true,<br>  "uat-ue1": true,<br>  "uat-ue2": true<br>}</pre> | no |
| <a name="input_launch_template_enabled"></a> [launch\_template\_enabled](#input\_launch\_template\_enabled) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": true,<br>  "qa-ue1": true,<br>  "rd-ue1": true,<br>  "rd-ue2": false,<br>  "sb-ue1": false,<br>  "ss-ue1": false,<br>  "uat-ue1": true<br>}</pre> | no |
| <a name="input_map_migrated"></a> [map\_migrated](#input\_map\_migrated) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "mig34085",<br>  "prod2-ue2": "mig34085",<br>  "qa-ue1": "mig34085",<br>  "qa-ue2": "mig34085",<br>  "rd-ue1": "mig34085",<br>  "rd-ue2": "mig34085",<br>  "sb-ue1": "mig34085",<br>  "ss-ue1": "mig34085",<br>  "uat-ue1": "mig34085",<br>  "uat-ue2": "mig34085"<br>}</pre> | no |
| <a name="input_max_size"></a> [max\_size](#input\_max\_size) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "4",<br>  "qa-ue1": "6",<br>  "rd-ue1": "6",<br>  "uat-ue1": "7"<br>}</pre> | no |
| <a name="input_min_size"></a> [min\_size](#input\_min\_size) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "4",<br>  "qa-ue1": "1",<br>  "rd-ue1": "0",<br>  "uat-ue1": "2"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_retention_in_days"></a> [retention\_in\_days](#input\_retention\_in\_days) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "60",<br>  "qa-ue1": "30",<br>  "rd-ue1": "30",<br>  "uat-ue1": "60"<br>}</pre> | no |
| <a name="input_scaling_schedule_start_down"></a> [scaling\_schedule\_start\_down](#input\_scaling\_schedule\_start\_down) | n/a | `map(string)` | <pre>{<br>  "rd-ue1": "2022-08-24T22:00:00Z",<br>  "uat-ue1": "2022-08-27T12:00:00Z"<br>}</pre> | no |
| <a name="input_scaling_schedule_start_up"></a> [scaling\_schedule\_start\_up](#input\_scaling\_schedule\_start\_up) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "2022-08-24T10:00:00Z",<br>  "rd-ue2": "",<br>  "sb-ue1": "",<br>  "ss-ue1": "",<br>  "uat-ue1": "2022-08-27T03:00:00Z"<br>}</pre> | no |
| <a name="input_schedule_desired_capacity_down"></a> [schedule\_desired\_capacity\_down](#input\_schedule\_desired\_capacity\_down) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "2",<br>  "rd-ue2": "",<br>  "sb-ue1": "0",<br>  "ss-ue1": "",<br>  "uat-ue1": "1"<br>}</pre> | no |
| <a name="input_schedule_desired_capacity_up"></a> [schedule\_desired\_capacity\_up](#input\_schedule\_desired\_capacity\_up) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "5",<br>  "rd-ue2": "",<br>  "sb-ue1": "",<br>  "ss-ue1": "",<br>  "uat-ue1": "5"<br>}</pre> | no |
| <a name="input_schedule_max_size_down"></a> [schedule\_max\_size\_down](#input\_schedule\_max\_size\_down) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "2",<br>  "rd-ue2": "",<br>  "sb-ue1": "0",<br>  "ss-ue1": "",<br>  "uat-ue1": "2"<br>}</pre> | no |
| <a name="input_schedule_max_size_up"></a> [schedule\_max\_size\_up](#input\_schedule\_max\_size\_up) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "6",<br>  "rd-ue2": "",<br>  "sb-ue1": "",<br>  "ss-ue1": "",<br>  "uat-ue1": "6"<br>}</pre> | no |
| <a name="input_schedule_min_size_down"></a> [schedule\_min\_size\_down](#input\_schedule\_min\_size\_down) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "2",<br>  "rd-ue2": "",<br>  "sb-ue1": "",<br>  "ss-ue1": "",<br>  "uat-ue1": "1"<br>}</pre> | no |
| <a name="input_schedule_min_size_up"></a> [schedule\_min\_size\_up](#input\_schedule\_min\_size\_up) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "5",<br>  "rd-ue2": "",<br>  "sb-ue1": "",<br>  "ss-ue1": "",<br>  "uat-ue1": "4"<br>}</pre> | no |
| <a name="input_schedule_recurrence_down"></a> [schedule\_recurrence\_down](#input\_schedule\_recurrence\_down) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "00 22 * * *",<br>  "rd-ue2": "",<br>  "sb-ue1": "00 12 * * *",<br>  "ss-ue1": "",<br>  "uat-ue1": "00 12 * * *"<br>}</pre> | no |
| <a name="input_schedule_recurrence_up"></a> [schedule\_recurrence\_up](#input\_schedule\_recurrence\_up) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "00 10 * * *",<br>  "rd-ue2": "",<br>  "sb-ue1": "02 00 * * *",<br>  "ss-ue1": "",<br>  "uat-ue1": "00 03 * * *"<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_volume_type"></a> [volume\_type](#input\_volume\_type) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": "gp3",<br>  "qa-ue1": "gp3",<br>  "rd-ue1": "gp3",<br>  "rd-ue2": "gp3",<br>  "sb-ue1": "gp3",<br>  "ss-ue1": "gp3",<br>  "uat-ue1": "gp3"<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_EKSNodeSecGroup"></a> [EKSNodeSecGroup](#output\_EKSNodeSecGroup) | n/a |
| <a name="output_alb-ingress-controller-role-arn"></a> [alb-ingress-controller-role-arn](#output\_alb-ingress-controller-role-arn) | alb-ingress-controller-role-arn |
| <a name="output_config-map-aws-auth"></a> [config-map-aws-auth](#output\_config-map-aws-auth) | n/a |
| <a name="output_default_config_map_aws_auth"></a> [default\_config\_map\_aws\_auth](#output\_default\_config\_map\_aws\_auth) | n/a |
| <a name="output_ec2nodes"></a> [ec2nodes](#output\_ec2nodes) | n/a |
| <a name="output_ec2nodesandfargate"></a> [ec2nodesandfargate](#output\_ec2nodesandfargate) | n/a |
| <a name="output_eks_cluster_identity_oidc_issuer"></a> [eks\_cluster\_identity\_oidc\_issuer](#output\_eks\_cluster\_identity\_oidc\_issuer) | The OIDC Identity issuer for the cluster |
| <a name="output_eks_fargate_profile_arn"></a> [eks\_fargate\_profile\_arn](#output\_eks\_fargate\_profile\_arn) | ARN of the EKS Fargate Profile |
| <a name="output_eks_fargate_profile_id"></a> [eks\_fargate\_profile\_id](#output\_eks\_fargate\_profile\_id) | EKS Cluster name and EKS Fargate Profile name separated by a colon |
| <a name="output_eks_fargate_profile_role_arn"></a> [eks\_fargate\_profile\_role\_arn](#output\_eks\_fargate\_profile\_role\_arn) | ARN of the EKS Fargate Profile IAM role |
| <a name="output_eks_fargate_profile_role_name"></a> [eks\_fargate\_profile\_role\_name](#output\_eks\_fargate\_profile\_role\_name) | Name of the EKS Fargate Profile IAM role |
| <a name="output_eks_fargate_profile_status"></a> [eks\_fargate\_profile\_status](#output\_eks\_fargate\_profile\_status) | Status of the EKS Fargate Profile |
| <a name="output_kubeconfig"></a> [kubeconfig](#output\_kubeconfig) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
