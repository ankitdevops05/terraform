# S3 Storage Gateways for AMP DB Backups

This particular terraform code must be run from a local host.  The terraform binary must do a curl to a private EC2 instance IP and thus Terraform Cloud will not be able to reach this IP.  You must set the provider information for the environment that you're working in and an AD username and password that can join the storage gateway to the sandata.local domain.

# Setup
S3 Storage Gateways include the following components
1. EC2 Instance which runs an AWS Appliance for Storage Gateway
2. EBS Volume on the EC2 Instance which serves as a cache drive
3. Storage Gateway itself
4. S3 Bucket
5. Storage Gateway File Shares<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ec2"></a> [ec2](#module\_ec2) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.6 |
| <a name="module_qa_s3_bucket"></a> [qa\_s3\_bucket](#module\_qa\_s3\_bucket) | git@github.com:sandatech/terraform-aws-s3-bucket.git | n/a |
| <a name="module_rd_s3_bucket"></a> [rd\_s3\_bucket](#module\_rd\_s3\_bucket) | git@github.com:sandatech/terraform-aws-s3-bucket.git | n/a |
| <a name="module_uat_s3_bucket"></a> [uat\_s3\_bucket](#module\_uat\_s3\_bucket) | git@github.com:sandatech/terraform-aws-s3-bucket.git | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_ebs_volume.cachevol](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ebs_volume) | resource |
| [aws_ebs_volume.cachevol2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ebs_volume) | resource |
| [aws_iam_role.sg_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_security_group.storagegateway](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group.storagegatewayendpoint](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group_rule.storagegateway_http](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.storagegateway_smb](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.storagegatewayendpoint1026](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.storagegatewayendpoint1027](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.storagegatewayendpoint1028](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.storagegatewayendpoint1031](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.storagegatewayendpoint443](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_storagegateway_cache.sgcache](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/storagegateway_cache) | resource |
| [aws_storagegateway_cache.sgcache2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/storagegateway_cache) | resource |
| [aws_storagegateway_gateway.ampbackup](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/storagegateway_gateway) | resource |
| [aws_storagegateway_smb_file_share.qashare](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/storagegateway_smb_file_share) | resource |
| [aws_storagegateway_smb_file_share.rdshare](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/storagegateway_smb_file_share) | resource |
| [aws_storagegateway_smb_file_share.uatshare](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/storagegateway_smb_file_share) | resource |
| [aws_volume_attachment.cacheattach](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/volume_attachment) | resource |
| [aws_volume_attachment.cacheattach2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/volume_attachment) | resource |
| [aws_vpc_endpoint.storagegw](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/vpc_endpoint) | resource |
| [aws_storagegateway_local_disk.cachedata](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/storagegateway_local_disk) | data source |
| [aws_storagegateway_local_disk.cachedata2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/storagegateway_local_disk) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_allowed_cidrs"></a> [allowed\_cidrs](#input\_allowed\_cidrs) | List of VPC security groups to associate | `list(string)` | <pre>[<br>  "10.15.0.0/20",<br>  "172.16.128.0/19",<br>  "172.16.64.0/19",<br>  "172.16.224.0/19"<br>]</pre> | no |
| <a name="input_ami"></a> [ami](#input\_ami) | n/a | `string` | `"ami-044238dc0ff5b8208"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_iam_profile"></a> [iam\_profile](#input\_iam\_profile) | n/a | `string` | `"EC2-Domain-Join"` | no |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | n/a | `string` | `"m5.xlarge"` | no |
| <a name="input_instances_number"></a> [instances\_number](#input\_instances\_number) | n/a | `number` | `1` | no |
| <a name="input_keypair"></a> [keypair](#input\_keypair) | n/a | `string` | `"sd-ss-us-east-1-keypair01"` | no |
| <a name="input_password"></a> [password](#input\_password) | n/a | `string` | `""` | no |
| <a name="input_qa_s3_bucket_name"></a> [qa\_s3\_bucket\_name](#input\_qa\_s3\_bucket\_name) | n/a | `string` | `"com-sandata-ss-amp-qa-db-backup"` | no |
| <a name="input_qa_valid_user_list"></a> [qa\_valid\_user\_list](#input\_qa\_valid\_user\_list) | n/a | `list` | <pre>[<br>  "@sandata_nt\\amp_sqldba",<br>  "qasqlservices"<br>]</pre> | no |
| <a name="input_rd_s3_bucket_name"></a> [rd\_s3\_bucket\_name](#input\_rd\_s3\_bucket\_name) | n/a | `string` | `"com-sandata-ss-amp-rd-db-backup"` | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_sg_name"></a> [sg\_name](#input\_sg\_name) | n/a | `string` | `"sd-ss-us-esat-1-storage-gateway"` | no |
| <a name="input_subnet"></a> [subnet](#input\_subnet) | n/a | `string` | `"subnet-05dc9d8061ccca6e1"` | no |
| <a name="input_subnets"></a> [subnets](#input\_subnets) | n/a | `list` | <pre>[<br>  "subnet-05dc9d8061ccca6e1",<br>  "subnet-00779ff4630aed209",<br>  "subnet-0a59f2bf1e2bc33a6"<br>]</pre> | no |
| <a name="input_uat_s3_bucket_name"></a> [uat\_s3\_bucket\_name](#input\_uat\_s3\_bucket\_name) | n/a | `string` | `"com-sandata-ss-amp-uat-db-backup"` | no |
| <a name="input_uat_valid_user_list"></a> [uat\_valid\_user\_list](#input\_uat\_valid\_user\_list) | n/a | `list` | <pre>[<br>  "@sandata_nt\\amp_sqldba",<br>  "uatsqlservices"<br>]</pre> | no |
| <a name="input_username"></a> [username](#input\_username) | n/a | `string` | `""` | no |
| <a name="input_valid_user_list"></a> [valid\_user\_list](#input\_valid\_user\_list) | n/a | `list` | <pre>[<br>  "@sandata_nt\\amp_sqldba",<br>  "rdsqlservices"<br>]</pre> | no |
| <a name="input_vpc"></a> [vpc](#input\_vpc) | n/a | `string` | `"vpc-0961ebb78fad4baeb"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_instances_private_ips"></a> [instances\_private\_ips](#output\_instances\_private\_ips) | Private IPs assigned to the EC2 instance |
| <a name="output_storage_gw_dns"></a> [storage\_gw\_dns](#output\_storage\_gw\_dns) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
