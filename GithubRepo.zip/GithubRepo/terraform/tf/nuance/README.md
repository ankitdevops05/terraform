# nuance

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | = 4.67.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | = 4.67.0 |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_db"></a> [db](#module\_db) | git@github.com:sandatech/terraform-aws-module-rds-01.git | v0.0.3 |
| <a name="module_module-ec2-instance-01"></a> [module-ec2-instance-01](#module\_module-ec2-instance-01) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.6 |
| <a name="module_module-ec2-instance-02"></a> [module-ec2-instance-02](#module\_module-ec2-instance-02) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.6 |
| <a name="module_proddb"></a> [proddb](#module\_proddb) | git@github.com:sandatech/terraform-aws-module-rds-01.git | v0.0.3 |

## Resources

| Name | Type |
|------|------|
| [aws_route53_record.prodwww](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/route53_record) | resource |
| [aws_route53_record.www](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/route53_record) | resource |
| [aws_security_group.nuance-lb-sg-01](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group) | resource |
| [aws_security_group.nuance-rds-sg-01](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group) | resource |
| [aws_security_group.nuance-rds-sg-02](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group) | resource |
| [aws_security_group.nuance-servers-sg-01](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group) | resource |
| [aws_security_group.nuance-servers-sg-02](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group) | resource |
| [aws_security_group_rule.http-rule](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.http-rule-lb](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.http-rule-prod](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.https-rule](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.https-rule-prod](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.lb-http-rule](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.nuancepostgres1](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.nuancepostgres2](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.nuancepostgres3](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.nuancepostgres4](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.rdp-rule](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.rdp-rule-prod](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group_rule) | resource |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_allocated_storage"></a> [allocated\_storage](#input\_allocated\_storage) | n/a | `string` | `"50"` | no |
| <a name="input_allocated_storage_prod"></a> [allocated\_storage\_prod](#input\_allocated\_storage\_prod) | n/a | `string` | `"807"` | no |
| <a name="input_allowed_cidrs"></a> [allowed\_cidrs](#input\_allowed\_cidrs) | List of VPC security groups to associate | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "172.18.20.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20",<br>    "172.16.132.0/22",<br>    "172.16.140.0/22",<br>    "172.16.148.0/22",<br>    "172.16.64.0/19",<br>    "172.17.64.0/19"<br>  ],<br>  "ss-ue1": [<br>    "172.18.20.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20",<br>    "172.16.196.0/22",<br>    "172.16.204.0/22",<br>    "172.16.212.0/22",<br>    "172.16.132.0/22",<br>    "172.16.140.0/22",<br>    "172.16.148.0/22",<br>    "172.16.68.0/22",<br>    "172.16.76.0/22",<br>    "172.16.84.0/22",<br>    "172.17.68.0/22",<br>    "172.17.76.0/22",<br>    "172.17.84.0/22"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs-prod"></a> [allowed\_cidrs-prod](#input\_allowed\_cidrs-prod) | List of VPC security groups to associate | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "172.18.20.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20",<br>    "172.16.132.0/22",<br>    "172.16.140.0/22",<br>    "172.16.148.0/22",<br>    "172.16.64.0/19",<br>    "172.17.64.0/19"<br>  ],<br>  "ss-ue1": [<br>    "172.18.20.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20",<br>    "172.16.228.0/22",<br>    "172.16.236.0/22",<br>    "172.16.244.0/22",<br>    "172.16.36.0/22",<br>    "172.16.44.0/22",<br>    "172.16.52.0/22",<br>    "172.16.196.0/22",<br>    "172.16.204.0/22",<br>    "172.16.212.0/22"<br>  ]<br>}</pre> | no |
| <a name="input_ami"></a> [ami](#input\_ami) | n/a | `string` | `"ami-0f93c815788872c5d"` | no |
| <a name="input_backup_retention_period"></a> [backup\_retention\_period](#input\_backup\_retention\_period) | n/a | `string` | `"7"` | no |
| <a name="input_backup_window"></a> [backup\_window](#input\_backup\_window) | n/a | `string` | `"06:00-07:00"` | no |
| <a name="input_db_instance_class"></a> [db\_instance\_class](#input\_db\_instance\_class) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "db.t3.medium",<br>  "rd-ue1": "db.t3.medium",<br>  "ss-ue1": "db.t3.medium"<br>}</pre> | no |
| <a name="input_deletion_protection"></a> [deletion\_protection](#input\_deletion\_protection) | n/a | `bool` | `false` | no |
| <a name="input_dns_name"></a> [dns\_name](#input\_dns\_name) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "nuance.prod2.us-east-1.sandata.com",<br>  "rd-ue1": "nuance.rd.us-east-1.sandata.com",<br>  "ss-ue1": "nuance.ss.us-east-1.sandata.com"<br>}</pre> | no |
| <a name="input_engine_version"></a> [engine\_version](#input\_engine\_version) | n/a | `string` | `"14.7"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | n/a | `string` | `"m5.large"` | no |
| <a name="input_instance_type_01"></a> [instance\_type\_01](#input\_instance\_type\_01) | n/a | `string` | `"c5.large"` | no |
| <a name="input_instance_type_02"></a> [instance\_type\_02](#input\_instance\_type\_02) | n/a | `string` | `"c5.2xlarge"` | no |
| <a name="input_instances_number"></a> [instances\_number](#input\_instances\_number) | n/a | `number` | `1` | no |
| <a name="input_maintenance_window"></a> [maintenance\_window](#input\_maintenance\_window) | n/a | `string` | `"Sun:04:00-Sun:06:00"` | no |
| <a name="input_major_engine_version"></a> [major\_engine\_version](#input\_major\_engine\_version) | n/a | `string` | `"14.7"` | no |
| <a name="input_max_allocated_storage"></a> [max\_allocated\_storage](#input\_max\_allocated\_storage) | n/a | `string` | `"1024"` | no |
| <a name="input_password"></a> [password](#input\_password) | n/a | `string` | `""` | no |
| <a name="input_prod_db_pass"></a> [prod\_db\_pass](#input\_prod\_db\_pass) | n/a | `string` | n/a | yes |
| <a name="input_prod_dns_name"></a> [prod\_dns\_name](#input\_prod\_dns\_name) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "nuance.prod2.us-east-1.sandata.com",<br>  "rd-ue1": "nuance.rd.us-east-1.sandata.com",<br>  "ss-ue1": "prod-nuance.ss.us-east-1.sandata.com"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_timezone"></a> [timezone](#input\_timezone) | n/a | `string` | `"Eastern Standard Time"` | no |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | n/a | `map(string)` | <pre>{<br>  "rd-ue1": "vpc-093635542e1c3c78e"<br>}</pre> | no |
| <a name="input_zone_id"></a> [zone\_id](#input\_zone\_id) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "Z08705443VKPJM2VC28CK",<br>  "rd-ue1": "Z10112833A0S1SDUH1M7T",<br>  "ss-ue1": "Z10086452LTNQEPZONTTM"<br>}</pre> | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
