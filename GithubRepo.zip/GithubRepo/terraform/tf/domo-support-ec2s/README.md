# domo-support-ec2s

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.30.0 |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ec2-talend"></a> [ec2-talend](#module\_ec2-talend) | app.terraform.io/sandata-tech/module-ec2-instance-01/aws | 0.0.5 |
| <a name="module_ec2-workbench"></a> [ec2-workbench](#module\_ec2-workbench) | app.terraform.io/sandata-tech/module-ec2-instance-01/aws | 0.0.5 |
| <a name="module_module-talend-sg"></a> [module-talend-sg](#module\_module-talend-sg) | app.terraform.io/sandata-tech/module-security-groups-01/aws | 0.0.6 |
| <a name="module_module-workbench-sg"></a> [module-workbench-sg](#module\_module-workbench-sg) | app.terraform.io/sandata-tech/module-security-groups-01/aws | 0.0.6 |

## Resources

| Name | Type |
|------|------|
| [aws_ami.windows_2019_base](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ami) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_ec2_talend_ami"></a> [ec2\_talend\_ami](#input\_ec2\_talend\_ami) | ec2 fs ami | `map(string)` | <pre>{<br>  "prod2-ue1": "ami-00f28d6fc4e364df2",<br>  "qa-ue1": "ami-00f28d6fc4e364df2",<br>  "rd-ue1": "ami-038cafd8a32d3cb6e",<br>  "stg-ue1": "ami-00f28d6fc4e364df2"<br>}</pre> | no |
| <a name="input_ec2_talend_instance_type"></a> [ec2\_talend\_instance\_type](#input\_ec2\_talend\_instance\_type) | ec2-fs instance type | `map(string)` | <pre>{<br>  "prod2-ue1": "c5.xlarge",<br>  "qa-ue1": "t3.large",<br>  "rd-ue1": "t3.large",<br>  "stg-ue1": "c5.xlarge"<br>}</pre> | no |
| <a name="input_ec2_talend_key"></a> [ec2\_talend\_key](#input\_ec2\_talend\_key) | ec2-fs instance type | `map(string)` | <pre>{<br>  "prod2-ue1": "93975A3ED44A787DD534B9377AB1609D75952A68B5CBDBF5C69668E13627ADDE",<br>  "qa-ue1": "D84EF09582DDF8F8E82678102530EFE2BD6A8CEA4A30B3E063842831DEA8B4F9",<br>  "rd-ue1": "5CE91D22C06E801F8F3C5799FB7359763FCE7A549B709E521BAAA736F30DD1CD",<br>  "stg-ue1": "CD7AC5B0CDB83ED8F3D5F492EAAC6C54F318C5C34FC3B633F7179B6C1B33E90E"<br>}</pre> | no |
| <a name="input_ec2_workbench_instance_type"></a> [ec2\_workbench\_instance\_type](#input\_ec2\_workbench\_instance\_type) | domo workbench instance type | `map(string)` | <pre>{<br>  "prod2-ue1": "m5.8xlarge",<br>  "qa-ue1": "c5.xlarge",<br>  "rd-ue1": "c5.xlarge",<br>  "stg-ue1": "m5.xlarge"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_talend_ebs_optimized"></a> [talend\_ebs\_optimized](#input\_talend\_ebs\_optimized) | ec2-fs instance type | `map(bool)` | <pre>{<br>  "prod2-ue1": true,<br>  "qa-ue1": true,<br>  "rd-ue1": true,<br>  "stg-ue1": false<br>}</pre> | no |
| <a name="input_talend_sg_ports_ingress"></a> [talend\_sg\_ports\_ingress](#input\_talend\_sg\_ports\_ingress) | List of VPC security groups to associate | `map` | <pre>{<br>  "prod2-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata interal IPs",<br>      "from_port": [<br>        "22"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "self": false,<br>      "to_port": [<br>        "22"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata interal IPs",<br>      "from_port": [<br>        "-1"<br>      ],<br>      "protocols": [<br>        "icmp"<br>      ],<br>      "self": false,<br>      "to_port": [<br>        "-1"<br>      ]<br>    }<br>  ],<br>  "qa-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19",<br>        "172.16.199.223/32"<br>      ],<br>      "description": "Sandata interal IPs",<br>      "from_port": [<br>        "22"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "self": false,<br>      "to_port": [<br>        "22"<br>      ]<br>    }<br>  ],<br>  "rd-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19",<br>        "172.16.199.223/32"<br>      ],<br>      "description": "Sandata interal IPs",<br>      "from_port": [<br>        "22"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "self": false,<br>      "to_port": [<br>        "22"<br>      ]<br>    }<br>  ],<br>  "stg-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata interal IPs",<br>      "from_port": [<br>        "22"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "self": false,<br>      "to_port": [<br>        "22"<br>      ]<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_workbench_ami"></a> [workbench\_ami](#input\_workbench\_ami) | ec2-fs instance type | `map(string)` | <pre>{<br>  "prod2-ue1": "ami-0416f96ae3d1a3f29",<br>  "qa-ue1": "ami-0fa60543f60171fe3",<br>  "rd-ue1": "ami-0fa60543f60171fe3",<br>  "stg-ue1": "ami-0fa60543f60171fe3"<br>}</pre> | no |
| <a name="input_workbench_backup_daily"></a> [workbench\_backup\_daily](#input\_workbench\_backup\_daily) | ec2-fs instance type | `map(string)` | <pre>{<br>  "prod2-ue1": "yes",<br>  "qa-ue1": "no",<br>  "rd-ue1": "no",<br>  "stg-ue1": "yes"<br>}</pre> | no |
| <a name="input_workbench_sg_ports_ingress"></a> [workbench\_sg\_ports\_ingress](#input\_workbench\_sg\_ports\_ingress) | List of VPC security groups to associate | `map` | <pre>{<br>  "prod2-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata interal IPs",<br>      "from_port": [<br>        "3389"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "3389"<br>      ]<br>    }<br>  ],<br>  "qa-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata interal IPs",<br>      "from_port": [<br>        "3389"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "3389"<br>      ]<br>    }<br>  ],<br>  "rd-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata interal IPs",<br>      "from_port": [<br>        "3389"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "3389"<br>      ]<br>    }<br>  ],<br>  "stg-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata interal IPs",<br>      "from_port": [<br>        "3389"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "3389"<br>      ]<br>    }<br>  ]<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_ec2-talend-private-ips"></a> [ec2-talend-private-ips](#output\_ec2-talend-private-ips) | Private IPs assigned to the EC2 instance |
| <a name="output_ec2-workbench-private-ips"></a> [ec2-workbench-private-ips](#output\_ec2-workbench-private-ips) | Private IPs assigned to the EC2 instance |
| <a name="output_module-talend-sg"></a> [module-talend-sg](#output\_module-talend-sg) | The security group ec2 instance |
| <a name="output_module-workbench-sg"></a> [module-workbench-sg](#output\_module-workbench-sg) | The security group ec2 instance |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
