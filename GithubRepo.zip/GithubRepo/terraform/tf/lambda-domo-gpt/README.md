# lambda-fraud-waste-illinois:

1) Create a new Vault access policy for the lambda function

```bash
cat <<'EOF' | vault policy write lambda-fraud-waste-illinois -
path "app-kv/lambda/lambda-fraud-waste-illinois" {
  capabilities = ["read", "list"]
}
EOF
```

2) Binding the AWS IAM role of lambda function to Vault policy, so the lambda can access Vault through the AWS IAM role
```bash
AWS_ACCOUNT_ID=817297989338
AWS_IAM_ROLE_LAMBDA_NAME=lambda-fraud-waste-illinois-lambda-role
VAULT_POLICY=lambda-fraud-waste-illinois

vault write "auth/aws/role/${AWS_IAM_ROLE_LAMBDA_NAME}" \
    auth_type=iam \
    bound_iam_principal_arn="arn:aws:iam::${AWS_ACCOUNT_ID}:role/${AWS_IAM_ROLE_LAMBDA_NAME}" \
    policies="${VAULT_POLICY}" \
    ttl=5m
```

