# order-manager-lambdas-qa-ue1

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_om-autoProcess-lambda-ActivateOrders"></a> [om-autoProcess-lambda-ActivateOrders](#module\_om-autoProcess-lambda-ActivateOrders) | ./modules/schedular-lambda | n/a |
| <a name="module_om-autoProcess-lambda-CompletedOrders"></a> [om-autoProcess-lambda-CompletedOrders](#module\_om-autoProcess-lambda-CompletedOrders) | ./modules/schedular-lambda | n/a |
| <a name="module_om-autoProcess-lambda-MemberCensus"></a> [om-autoProcess-lambda-MemberCensus](#module\_om-autoProcess-lambda-MemberCensus) | ./modules/schedular-lambda | n/a |
| <a name="module_om-autoProcess-lambda-ValidatePayerOrder"></a> [om-autoProcess-lambda-ValidatePayerOrder](#module\_om-autoProcess-lambda-ValidatePayerOrder) | ./modules/schedular-lambda | n/a |
| <a name="module_om-fileprocess-lambda"></a> [om-fileprocess-lambda](#module\_om-fileprocess-lambda) | ./modules/s3-lambda | n/a |
| <a name="module_om_lambda_role"></a> [om\_lambda\_role](#module\_om\_lambda\_role) | ./modules/iam-lambda | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_security_group.om_lambda_sg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_ActivateOrders_env_vars"></a> [ActivateOrders\_env\_vars](#input\_ActivateOrders\_env\_vars) | n/a | `map` | <pre>{<br>  "APIName": "ActivateOrders",<br>  "APIUrl": "https://om-nlb.qa.us-east-1.sandata.com/om/api/",<br>  "TokenAPIName": "GenerateToken",<br>  "TokenPassword": "Admin@123456",<br>  "TokenUser": "AutoProcess@sandata.com"<br>}</pre> | no |
| <a name="input_CompletedOrders_env_vars"></a> [CompletedOrders\_env\_vars](#input\_CompletedOrders\_env\_vars) | n/a | `map` | <pre>{<br>  "APIName": "CompletedOrders",<br>  "APIUrl": "https://om-nlb.qa.us-east-1.sandata.com/om/api/",<br>  "TokenAPIName": "GenerateToken",<br>  "TokenPassword": "Admin@123456",<br>  "TokenUser": "AutoProcess@sandata.com"<br>}</pre> | no |
| <a name="input_FileProcess_env_vars"></a> [FileProcess\_env\_vars](#input\_FileProcess\_env\_vars) | n/a | `map` | <pre>{<br>  "FileProcessURL": "https://om-nlb.qa.us-east-1.sandata.com/om/"<br>}</pre> | no |
| <a name="input_MemberCensus_env_vars"></a> [MemberCensus\_env\_vars](#input\_MemberCensus\_env\_vars) | n/a | `map` | <pre>{<br>  "APIName": "MemberCensus",<br>  "APIUrl": "https://om-nlb.qa.us-east-1.sandata.com/om/api/",<br>  "TokenAPIName": "GenerateToken",<br>  "TokenPassword": "Admin@123456",<br>  "TokenUser": "AutoProcess@sandata.com"<br>}</pre> | no |
| <a name="input_RandomNumber"></a> [RandomNumber](#input\_RandomNumber) | main.tf file Modules Default variables | `string` | `"01"` | no |
| <a name="input_Service"></a> [Service](#input\_Service) | n/a | `string` | `"OM"` | no |
| <a name="input_ValidatePayerOrder_env_vars"></a> [ValidatePayerOrder\_env\_vars](#input\_ValidatePayerOrder\_env\_vars) | n/a | `map` | <pre>{<br>  "APIName": "InvalidOrders",<br>  "APIUrl": "https://om-nlb.qa.us-east-1.sandata.com/om/api/",<br>  "TokenAPIName": "GenerateToken",<br>  "TokenPassword": "Admin@123456",<br>  "TokenUser": "AutoProcess@sandata.com"<br>}</pre> | no |
| <a name="input_Version"></a> [Version](#input\_Version) | n/a | `string` | `"0.0.1"` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `string` | `""` | no |
| <a name="input_access_token"></a> [access\_token](#input\_access\_token) | description | `string` | `""` | no |
| <a name="input_application_name"></a> [application\_name](#input\_application\_name) | n/a | `string` | `"OM"` | no |
| <a name="input_aws_cloudwatch_event_rule_name_ActivateOrders"></a> [aws\_cloudwatch\_event\_rule\_name\_ActivateOrders](#input\_aws\_cloudwatch\_event\_rule\_name\_ActivateOrders) | n/a | `string` | `"ActivateOrders-2min"` | no |
| <a name="input_aws_cloudwatch_event_rule_name_CompletedOrders"></a> [aws\_cloudwatch\_event\_rule\_name\_CompletedOrders](#input\_aws\_cloudwatch\_event\_rule\_name\_CompletedOrders) | n/a | `string` | `"CompletedOrders-2min"` | no |
| <a name="input_aws_cloudwatch_event_rule_name_MemberCensus"></a> [aws\_cloudwatch\_event\_rule\_name\_MemberCensus](#input\_aws\_cloudwatch\_event\_rule\_name\_MemberCensus) | n/a | `string` | `"MemberCensus-2min"` | no |
| <a name="input_aws_cloudwatch_event_rule_name_ValidatePayerOrder"></a> [aws\_cloudwatch\_event\_rule\_name\_ValidatePayerOrder](#input\_aws\_cloudwatch\_event\_rule\_name\_ValidatePayerOrder) | n/a | `string` | `"ValidatePayerOrder-2min"` | no |
| <a name="input_cron_expression_ActivateOrders"></a> [cron\_expression\_ActivateOrders](#input\_cron\_expression\_ActivateOrders) | n/a | `string` | `"rate(2 minutes)"` | no |
| <a name="input_cron_expression_CompletedOrders"></a> [cron\_expression\_CompletedOrders](#input\_cron\_expression\_CompletedOrders) | n/a | `string` | `"rate(2 minutes)"` | no |
| <a name="input_cron_expression_Description_ActivateOrders"></a> [cron\_expression\_Description\_ActivateOrders](#input\_cron\_expression\_Description\_ActivateOrders) | n/a | `string` | `"This rule will execute lambda a every 2 min for AutoProcess lambda functionEvent"` | no |
| <a name="input_cron_expression_Description_CompletedOrders"></a> [cron\_expression\_Description\_CompletedOrders](#input\_cron\_expression\_Description\_CompletedOrders) | n/a | `string` | `"This rule will execute lambda a every 2 min for AutoProcess lambda functionEvent"` | no |
| <a name="input_cron_expression_Description_MemberCensus"></a> [cron\_expression\_Description\_MemberCensus](#input\_cron\_expression\_Description\_MemberCensus) | n/a | `string` | `"Runs everyday at 2:00 AM EST"` | no |
| <a name="input_cron_expression_Description_ValidatePayerOrder"></a> [cron\_expression\_Description\_ValidatePayerOrder](#input\_cron\_expression\_Description\_ValidatePayerOrder) | n/a | `string` | `"This rule will execute lambda a every 2 min for AutoProcess lambda functionEvent"` | no |
| <a name="input_cron_expression_MemberCensus"></a> [cron\_expression\_MemberCensus](#input\_cron\_expression\_MemberCensus) | n/a | `string` | `"cron(0 0/1 * * ? *)"` | no |
| <a name="input_cron_expression_ValidatePayerOrder"></a> [cron\_expression\_ValidatePayerOrder](#input\_cron\_expression\_ValidatePayerOrder) | n/a | `string` | `"rate(2 minutes)"` | no |
| <a name="input_environment_name"></a> [environment\_name](#input\_environment\_name) | n/a | `string` | `"rd"` | no |
| <a name="input_handler_ActivateOrders"></a> [handler\_ActivateOrders](#input\_handler\_ActivateOrders) | n/a | `string` | `"AutoProcess::AutoProcess.Function::Execute"` | no |
| <a name="input_handler_CompletedOrders"></a> [handler\_CompletedOrders](#input\_handler\_CompletedOrders) | n/a | `string` | `"AutoProcess::AutoProcess.Function::Execute"` | no |
| <a name="input_handler_FileProcess"></a> [handler\_FileProcess](#input\_handler\_FileProcess) | n/a | `string` | `"FileProcessLambda::FileProcessLambda.Function::Execute"` | no |
| <a name="input_handler_MemberCensus"></a> [handler\_MemberCensus](#input\_handler\_MemberCensus) | n/a | `string` | `"AutoProcess::AutoProcess.Function::Execute"` | no |
| <a name="input_handler_ValidatePayerOrder"></a> [handler\_ValidatePayerOrder](#input\_handler\_ValidatePayerOrder) | n/a | `string` | `"AutoProcess::AutoProcess.Function::Execute"` | no |
| <a name="input_lambda_function_code_ActivateOrders"></a> [lambda\_function\_code\_ActivateOrders](#input\_lambda\_function\_code\_ActivateOrders) | ActivateOrders | `string` | `"files/AutoProcess.zip"` | no |
| <a name="input_lambda_function_code_CompletedOrders"></a> [lambda\_function\_code\_CompletedOrders](#input\_lambda\_function\_code\_CompletedOrders) | CompletedOrders | `string` | `"files/AutoProcess.zip"` | no |
| <a name="input_lambda_function_code_FileProcess"></a> [lambda\_function\_code\_FileProcess](#input\_lambda\_function\_code\_FileProcess) | FileProcess | `string` | `"files/FileProcessLambda.zip"` | no |
| <a name="input_lambda_function_code_MemberCensus"></a> [lambda\_function\_code\_MemberCensus](#input\_lambda\_function\_code\_MemberCensus) | MemberCensus | `string` | `"files/AutoProcess.zip"` | no |
| <a name="input_lambda_function_code_ValidatePayerOrder"></a> [lambda\_function\_code\_ValidatePayerOrder](#input\_lambda\_function\_code\_ValidatePayerOrder) | ValidatePayerOrder | `string` | `"files/AutoProcess.zip"` | no |
| <a name="input_lambda_function_name_ActivateOrders"></a> [lambda\_function\_name\_ActivateOrders](#input\_lambda\_function\_name\_ActivateOrders) | n/a | `string` | `"OrderManagerActivateOrdersLambda"` | no |
| <a name="input_lambda_function_name_CompletedOrders"></a> [lambda\_function\_name\_CompletedOrders](#input\_lambda\_function\_name\_CompletedOrders) | n/a | `string` | `"OrderManagerCompletedOrdersLambda"` | no |
| <a name="input_lambda_function_name_FileProcess"></a> [lambda\_function\_name\_FileProcess](#input\_lambda\_function\_name\_FileProcess) | n/a | `string` | `"OrderManagerFileProcessLambda"` | no |
| <a name="input_lambda_function_name_MemberCensus"></a> [lambda\_function\_name\_MemberCensus](#input\_lambda\_function\_name\_MemberCensus) | n/a | `string` | `"OrderManagerMemberCensusLambda"` | no |
| <a name="input_lambda_function_name_ValidatePayerOrder"></a> [lambda\_function\_name\_ValidatePayerOrder](#input\_lambda\_function\_name\_ValidatePayerOrder) | n/a | `string` | `"OrderManagerValidatePayerOrderLambda"` | no |
| <a name="input_om_lambda_sg_name"></a> [om\_lambda\_sg\_name](#input\_om\_lambda\_sg\_name) | n/a | `string` | `"sd-qa-us-east-1-sg-om-lambda-01"` | no |
| <a name="input_region"></a> [region](#input\_region) | Provider.tf file variables | `string` | `"us-east-1"` | no |
| <a name="input_runtime"></a> [runtime](#input\_runtime) | n/a | `string` | `"dotnetcore3.1"` | no |
| <a name="input_runtime_ActivateOrders"></a> [runtime\_ActivateOrders](#input\_runtime\_ActivateOrders) | n/a | `string` | `"dotnetcore3.1"` | no |
| <a name="input_runtime_CompletedOrders"></a> [runtime\_CompletedOrders](#input\_runtime\_CompletedOrders) | n/a | `string` | `"dotnetcore3.1"` | no |
| <a name="input_runtime_FileProcess"></a> [runtime\_FileProcess](#input\_runtime\_FileProcess) | n/a | `string` | `"dotnetcore3.1"` | no |
| <a name="input_runtime_MemberCensus"></a> [runtime\_MemberCensus](#input\_runtime\_MemberCensus) | n/a | `string` | `"dotnetcore3.1"` | no |
| <a name="input_runtime_ValidatePayerOrder"></a> [runtime\_ValidatePayerOrder](#input\_runtime\_ValidatePayerOrder) | n/a | `string` | `"dotnetcore3.1"` | no |
| <a name="input_s3_bucket_sftp_01"></a> [s3\_bucket\_sftp\_01](#input\_s3\_bucket\_sftp\_01) | n/a | `string` | `"com-sandata-qa-mcop-sftp-01"` | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_ActivateOrders-arn"></a> [ActivateOrders-arn](#output\_ActivateOrders-arn) | n/a |
| <a name="output_CompletedOrders-arn"></a> [CompletedOrders-arn](#output\_CompletedOrders-arn) | n/a |
| <a name="output_MemberCensus-arn"></a> [MemberCensus-arn](#output\_MemberCensus-arn) | n/a |
| <a name="output_ValidatePayerOrder-arn"></a> [ValidatePayerOrder-arn](#output\_ValidatePayerOrder-arn) | n/a |
| <a name="output_fileprocess_arn"></a> [fileprocess\_arn](#output\_fileprocess\_arn) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
