# schedular-lambda

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_cloudwatch_event_rule.activity](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_rule) | resource |
| [aws_cloudwatch_event_target.triggerLambda](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_target) | resource |
| [aws_cloudwatch_log_group.log_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_log_group) | resource |
| [aws_lambda_function.FileProcessLamda](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_function) | resource |
| [aws_lambda_permission.allow_cloudwatch_to_call_check_Cloud_trigger](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aws_cloudwatch_event_rule_name"></a> [aws\_cloudwatch\_event\_rule\_name](#input\_aws\_cloudwatch\_event\_rule\_name) | n/a | `string` | n/a | yes |
| <a name="input_cron_expression"></a> [cron\_expression](#input\_cron\_expression) | n/a | `string` | n/a | yes |
| <a name="input_cron_expression_Description"></a> [cron\_expression\_Description](#input\_cron\_expression\_Description) | n/a | `string` | n/a | yes |
| <a name="input_env_vars"></a> [env\_vars](#input\_env\_vars) | A map of tags to add to all resources. | `map(string)` | `{}` | no |
| <a name="input_environment_name"></a> [environment\_name](#input\_environment\_name) | Environment Name | `string` | n/a | yes |
| <a name="input_handler"></a> [handler](#input\_handler) | n/a | `any` | n/a | yes |
| <a name="input_lambda_function_code"></a> [lambda\_function\_code](#input\_lambda\_function\_code) | n/a | `any` | n/a | yes |
| <a name="input_lambda_function_name"></a> [lambda\_function\_name](#input\_lambda\_function\_name) | n/a | `any` | n/a | yes |
| <a name="input_lambda_function_source_code_hash"></a> [lambda\_function\_source\_code\_hash](#input\_lambda\_function\_source\_code\_hash) | n/a | `string` | n/a | yes |
| <a name="input_lambda_timeout"></a> [lambda\_timeout](#input\_lambda\_timeout) | Lambda timeout in seconds | `number` | `120` | no |
| <a name="input_role_arn"></a> [role\_arn](#input\_role\_arn) | main.tf file other variables | `any` | n/a | yes |
| <a name="input_runtime"></a> [runtime](#input\_runtime) | Set Lambda runtime identifier dotnetcore2.1 | `string` | n/a | yes |
| <a name="input_security_group_ids"></a> [security\_group\_ids](#input\_security\_group\_ids) | n/a | `list(string)` | n/a | yes |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | n/a | `list(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_Lambda_arn"></a> [Lambda\_arn](#output\_Lambda\_arn) | n/a |
| <a name="output_Lambda_role_id"></a> [Lambda\_role\_id](#output\_Lambda\_role\_id) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
