# iam-lambda

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_iam_role.iam_lambda_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role_policy.iam_lambda_role_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [random_id.random](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/id) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_RandomNumber"></a> [RandomNumber](#input\_RandomNumber) | The random number to assign to each name | `string` | n/a | yes |
| <a name="input_Service"></a> [Service](#input\_Service) | The service name | `string` | n/a | yes |
| <a name="input_Version"></a> [Version](#input\_Version) | The version number | `string` | n/a | yes |
| <a name="input_application_name"></a> [application\_name](#input\_application\_name) | The Applicationname to use for naming convention | `string` | n/a | yes |
| <a name="input_environment_name"></a> [environment\_name](#input\_environment\_name) | Environment Long Name | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | The name to region to create instance | `string` | n/a | yes |
| <a name="input_s3_bucket_sftp_01"></a> [s3\_bucket\_sftp\_01](#input\_s3\_bucket\_sftp\_01) | S3 bucket for sftp | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_arn"></a> [arn](#output\_arn) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
