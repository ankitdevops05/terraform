# ec2-bamboo-agent

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_agent03"></a> [agent03](#module\_agent03) | git@github.com:sandatech/terraform-aws-ec2-instance.git | n/a |
| <a name="module_agent04"></a> [agent04](#module\_agent04) | git@github.com:sandatech/terraform-aws-ec2-instance.git | n/a |
| <a name="module_ec2"></a> [ec2](#module\_ec2) | git@github.com:sandatech/terraform-aws-ec2-instance.git | n/a |
| <a name="module_module-linux-bamboo-agent-sg"></a> [module-linux-bamboo-agent-sg](#module\_module-linux-bamboo-agent-sg) | git@github.com:sandatech/terraform-aws-module-security-groups-01.git | v0.0.6 |
| <a name="module_module-win-agent-sg"></a> [module-win-agent-sg](#module\_module-win-agent-sg) | git@github.com:sandatech/terraform-aws-module-security-groups-01.git | v0.0.6 |

## Resources

| Name | Type |
|------|------|
| [aws_ami.aws_linux](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ami) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_agent_02_ami"></a> [agent\_02\_ami](#input\_agent\_02\_ami) | n/a | `map` | <pre>{<br>  "ss-ue1": "ami-0ed9277fb7eb570c9"<br>}</pre> | no |
| <a name="input_agent_02_size"></a> [agent\_02\_size](#input\_agent\_02\_size) | n/a | `map` | <pre>{<br>  "ss-ue1": "c5.large"<br>}</pre> | no |
| <a name="input_agent_03_ami"></a> [agent\_03\_ami](#input\_agent\_03\_ami) | n/a | `map` | <pre>{<br>  "ss-ue1": "ami-0bde1eb2c18cb2abe"<br>}</pre> | no |
| <a name="input_agent_03_size"></a> [agent\_03\_size](#input\_agent\_03\_size) | n/a | `map` | <pre>{<br>  "ss-ue1": "m5.2xlarge"<br>}</pre> | no |
| <a name="input_agent_04_ami"></a> [agent\_04\_ami](#input\_agent\_04\_ami) | n/a | `map` | <pre>{<br>  "ss-ue1": "ami-0bde1eb2c18cb2abe"<br>}</pre> | no |
| <a name="input_agent_04_size"></a> [agent\_04\_size](#input\_agent\_04\_size) | n/a | `map` | <pre>{<br>  "ss-ue1": "m5.2xlarge"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_linux_agent_sg_ports_ingress"></a> [linux\_agent\_sg\_ports\_ingress](#input\_linux\_agent\_sg\_ports\_ingress) | n/a | `map` | <pre>{<br>  "ss-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "10.15.0.0/20"<br>      ],<br>      "description": "Sandata Internal IPs",<br>      "from_port": [<br>        "22"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "22"<br>      ]<br>    },<br>    {<br>      "description": "Bamboo Servers",<br>      "from_port": [<br>        "0"<br>      ],<br>      "protocols": [<br>        "-1"<br>      ],<br>      "security_groups": [<br>        "sg-0822d93cfae41fac1"<br>      ],<br>      "self": true,<br>      "to_port": [<br>        "0"<br>      ]<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_win_agent_sg_ports_ingress"></a> [win\_agent\_sg\_ports\_ingress](#input\_win\_agent\_sg\_ports\_ingress) | n/a | `map` | <pre>{<br>  "ss-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "10.15.0.0/20"<br>      ],<br>      "description": "Sandata Internal IPs",<br>      "from_port": [<br>        "3389"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "3389"<br>      ]<br>    },<br>    {<br>      "description": "Bamboo Servers",<br>      "from_port": [<br>        "0"<br>      ],<br>      "protocols": [<br>        "-1"<br>      ],<br>      "security_groups": [<br>        "sg-0822d93cfae41fac1"<br>      ],<br>      "self": true,<br>      "to_port": [<br>        "0"<br>      ]<br>    }<br>  ]<br>}</pre> | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
