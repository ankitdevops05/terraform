# s3-static-am
Setup S3 static site for AM2 UI project

- Setup S3 and cloudfront distribution
- Setup cloudfront function to apply security headers at response

```hcl
  //Apply security headers
  cf_viewer_response = {
    function_name = "am-viewer-response-apply-security-headers"
    function_name_description = "apply security headers for am.${var.environment[local.workspace]}.${var.region}.sandata.com"
    source_code_file = "${path.module}/code/viewer-response-with-security-headers.js"
  }

```<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_s3_static_site_am"></a> [s3\_static\_site\_am](#module\_s3\_static\_site\_am) | git::git@github.com:sandatech/terraform-aws-module-s3-staticbucket-and-cloudfront.git | v0.0.5 |

## Resources

| Name | Type |
|------|------|
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [terraform_remote_state.aws_certs](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_cf_aws_certificate_arn"></a> [cf\_aws\_certificate\_arn](#input\_cf\_aws\_certificate\_arn) | Use prod cert star.sandata.com which supports *.prod2.us-east-1.sandata.com  *.us-east-1.sandata.com, *.va.sandata.com, *.sandata.com | `map(string)` | <pre>{<br>  "prod2-ue1": "arn:aws:acm:us-east-1:656560712260:certificate/0cef30e4-53f3-4f25-9edc-01c1987154d9",<br>  "qa-ue1": "arn:aws:acm:us-east-1:046839536952:certificate/d4835813-c36b-4965-8ff8-0b85b77bcc00",<br>  "rd-ue1": "arn:aws:acm:us-east-1:817297989338:certificate/a3885492-f9f0-4544-9a60-5d80d540ae2b",<br>  "rd-ue2": "arn:aws:acm:us-east-1:817297989338:certificate/dec4654b-241d-4f37-a87f-1a792f427768",<br>  "uat-ue1": "arn:aws:acm:us-east-1:244940236506:certificate/73e02499-9ec6-4095-b5f0-06dfc148ce7c"<br>}</pre> | no |
| <a name="input_cf_public_domain_name"></a> [cf\_public\_domain\_name](#input\_cf\_public\_domain\_name) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": [<br>    "am.prod2.us-east-1.sandata.com"<br>  ],<br>  "qa-ue1": [<br>    "am.qa.us-east-1.sandata.com"<br>  ],<br>  "rd-ue1": [<br>    "am.rd.us-east-1.sandata.com"<br>  ],<br>  "rd-ue2": [<br>    "poc-am.rd.us-east-1.sandata.com"<br>  ],<br>  "uat-ue1": [<br>    "am.uat.us-east-1.sandata.com"<br>  ]<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_function_name"></a> [function\_name](#input\_function\_name) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "am-viewer-response-apply-security-headers",<br>  "qa-ue1": "am-viewer-response-apply-security-headers",<br>  "rd-ue1": "am-viewer-response-apply-security-headers",<br>  "rd-ue2": "oh-am-viewer-response-apply-security-headers",<br>  "uat-ue1": "am-viewer-response-apply-security-headers"<br>}</pre> | no |
| <a name="input_header_referer"></a> [header\_referer](#input\_header\_referer) | n/a | `map` | <pre>{<br>  "prod2-ue1": "amuiprod35947",<br>  "qa-ue1": "amuiqa74590",<br>  "rd-ue1": "amuird",<br>  "rd-ue2": "amuiqa74590",<br>  "uat-ue1": "amuiuat57380"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_s3_internal_domain_name"></a> [s3\_internal\_domain\_name](#input\_s3\_internal\_domain\_name) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "am.prod2.us-east-1.sandata.com",<br>  "qa-ue1": "am.qa.us-east-1.sandata.com",<br>  "rd-ue1": "am.rd.us-east-1.sandata.com",<br>  "rd-ue2": "poc-am.rd.us-east-1.sandata.com",<br>  "uat-ue1": "am.uat.us-east-1.sandata.com"<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cloudfront_arn"></a> [cloudfront\_arn](#output\_cloudfront\_arn) | Cloudfront ARN including cloudfront distribution id |
| <a name="output_cloudfront_domain_name"></a> [cloudfront\_domain\_name](#output\_cloudfront\_domain\_name) | This is public cloudfront URL, so we can use to verify security headers for lower environments |
| <a name="output_s3_static_site_internal_url"></a> [s3\_static\_site\_internal\_url](#output\_s3\_static\_site\_internal\_url) | This is an internal URL, so we can verify the deployment to S3 |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
