# ec2-rabbit

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_alb"></a> [alb](#module\_alb) | git@github.com:sandatech/terraform-aws-module-rabbitmq-alb-01.git | v0.0.7 |
| <a name="module_rabbit"></a> [rabbit](#module\_rabbit) | git::git@github.com:sandatech/terraform-aws-module-rabbitmq-ec2-01.git | v0.0.18 |

## Resources

| Name | Type |
|------|------|
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_autoscaling_max_size"></a> [autoscaling\_max\_size](#input\_autoscaling\_max\_size) | Autoscaling Group Max Size | `map(number)` | <pre>{<br>  "prod2-ue1": 5,<br>  "qa-ue1": 3,<br>  "rd-ue1": 3,<br>  "uat-ue1": 3<br>}</pre> | no |
| <a name="input_autoscaling_min_size"></a> [autoscaling\_min\_size](#input\_autoscaling\_min\_size) | Autoscaling Group Min Size | `map(number)` | <pre>{<br>  "prod2-ue1": 3,<br>  "qa-ue1": 3,<br>  "rd-ue1": 3,<br>  "uat-ue1": 2<br>}</pre> | no |
| <a name="input_certificate_arn"></a> [certificate\_arn](#input\_certificate\_arn) | ARN of certificate to use with HTTPS Listener | `map(string)` | <pre>{<br>  "prod2-ue1": "arn:aws:acm:us-east-1:656560712260:certificate/0cef30e4-53f3-4f25-9edc-01c1987154d9",<br>  "qa-ue1": "arn:aws:acm:us-east-1:046839536952:certificate/d4835813-c36b-4965-8ff8-0b85b77bcc00",<br>  "rd-ue1": "arn:aws:acm:us-east-1:817297989338:certificate/dec4654b-241d-4f37-a87f-1a792f427768",<br>  "uat-ue1": "arn:aws:acm:us-east-1:244940236506:certificate/73e02499-9ec6-4095-b5f0-06dfc148ce7c"<br>}</pre> | no |
| <a name="input_cluster_dns_name"></a> [cluster\_dns\_name](#input\_cluster\_dns\_name) | A subdomain to create in public/private Route53 Zones | `map(string)` | <pre>{<br>  "prod2-ue1": "rabbit",<br>  "qa-ue1": "rabbit",<br>  "rd-ue1": "rd-rabbit",<br>  "uat-ue1": "rabbit"<br>}</pre> | no |
| <a name="input_desired_capacity"></a> [desired\_capacity](#input\_desired\_capacity) | Default size of your Rabbit ASG (1, 3, 5) | `map(number)` | <pre>{<br>  "prod2-ue1": 3,<br>  "qa-ue1": 3,<br>  "rd-ue1": 3,<br>  "uat-ue1": 2<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_image_id"></a> [image\_id](#input\_image\_id) | Aws ami to be used by ec2 instances | `map(string)` | <pre>{<br>  "prod2-ue1": "ami-054c7567cb88c4820",<br>  "qa-ue1": "ami-0d20546e760beee27",<br>  "rd-ue1": "ami-0d20546e760beee27",<br>  "uat-ue1": "ami-0d20546e760beee27"<br>}</pre> | no |
| <a name="input_ingress_private_cidr_blocks"></a> [ingress\_private\_cidr\_blocks](#input\_ingress\_private\_cidr\_blocks) | n/a | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "208.64.40.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20",<br>    "172.18.20.0/22",<br>    "172.19.0.0/19",<br>    "172.16.32.0/19",<br>    "192.168.42.0/24",<br>    "172.26.0.0/16"<br>  ],<br>  "qa-ue1": [<br>    "208.64.40.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20",<br>    "172.18.20.0/22",<br>    "172.19.0.0/19",<br>    "172.16.64.0/19",<br>    "192.168.42.0/24",<br>    "172.31.0.0/16"<br>  ],<br>  "rd-ue1": [<br>    "172.16.0.0/12",<br>    "10.0.0.0/8",<br>    "192.168.0.0/16",<br>    "172.19.0.0/19",<br>    "172.16.199.223/32"<br>  ],<br>  "uat-ue1": [<br>    "208.64.40.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20",<br>    "172.18.20.0/22",<br>    "172.19.0.0/19",<br>    "172.16.224.0/19",<br>    "192.168.42.0/24"<br>  ]<br>}</pre> | no |
| <a name="input_ingress_public_cidr_blocks"></a> [ingress\_public\_cidr\_blocks](#input\_ingress\_public\_cidr\_blocks) | A set of CIDR blocks that can access the cluster from oustide your VPC. | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "208.64.40.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20",<br>    "172.18.20.0/22",<br>    "172.19.0.0/19",<br>    "172.16.32.0/19",<br>    "192.168.42.0/24",<br>    "172.26.0.0/16"<br>  ],<br>  "qa-ue1": [<br>    "208.64.40.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20",<br>    "172.18.20.0/22",<br>    "172.19.0.0/19",<br>    "172.16.64.0/19",<br>    "192.168.42.0/24",<br>    "172.31.0.0/16"<br>  ],<br>  "rd-ue1": [<br>    "207.140.140.193/32",<br>    "207.140.140.194/32",<br>    "172.16.0.0/16",<br>    "10.0.0.0/8",<br>    "172.18.0.0/16",<br>    "172.19.0.0/19",<br>    "172.17.128.0/19",<br>    "172.27.32.0/23",<br>    "172.27.34.0/23",<br>    "172.27.36.0/23",<br>    "172.27.13.0/26",<br>    "172.27.42.0/23",<br>    "68.132.36.249/32"<br>  ],<br>  "uat-ue1": [<br>    "208.64.40.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20",<br>    "172.18.20.0/22",<br>    "172.19.0.0/19",<br>    "172.16.224.0/19",<br>    "192.168.42.0/24"<br>  ]<br>}</pre> | no |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | Instance type of ASG instances | `map(string)` | <pre>{<br>  "prod2-ue1": "m5.xlarge",<br>  "qa-ue1": "t3.medium",<br>  "rd-ue1": "t3.medium",<br>  "uat-ue1": "t3.medium"<br>}</pre> | no |
| <a name="input_public_domain_name"></a> [public\_domain\_name](#input\_public\_domain\_name) | n/a | `string` | `""` | no |
| <a name="input_rabbit_monitoring_pass"></a> [rabbit\_monitoring\_pass](#input\_rabbit\_monitoring\_pass) | Password of the rabbit monitoring user. | `string` | `""` | no |
| <a name="input_rabbit_user_pass"></a> [rabbit\_user\_pass](#input\_rabbit\_user\_pass) | Rabbit user password | `string` | `""` | no |
| <a name="input_rabbit_volume_size"></a> [rabbit\_volume\_size](#input\_rabbit\_volume\_size) | n/a | `map` | <pre>{<br>  "prod2-ue1": 100,<br>  "qa-ue1": 50,<br>  "rd-ue1": 50,<br>  "uat-ue1": 50<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
