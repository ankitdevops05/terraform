# open-billing-efs

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_open-billing-efs"></a> [open-billing-efs](#module\_open-billing-efs) | git@github.com:sandatech/terraform-aws-efs.git | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_cidr_blocks"></a> [cidr\_blocks](#input\_cidr\_blocks) | cidr blocks to allow | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "172.16.36.0/22",<br>    "172.16.44.0/22",<br>    "172.16.52.0/22"<br>  ],<br>  "qa-ue1": [<br>    "172.16.68.0/22",<br>    "172.16.76.0/22",<br>    "172.16.84.0/22"<br>  ],<br>  "rd-ue1": [<br>    "172.16.132.0/22",<br>    "172.16.140.0/22",<br>    "172.16.148.0/22"<br>  ],<br>  "uat-ue1": [<br>    "172.16.228.0/22",<br>    "172.16.236.0/22",<br>    "172.16.244.0/22"<br>  ]<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_subnets"></a> [subnets](#input\_subnets) | subnet ids | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "subnet-08e157c7ba2ab56f3",<br>    "subnet-00c173bccdcff4360",<br>    "subnet-0ee67b488f264ef77"<br>  ],<br>  "qa-ue1": [<br>    "subnet-001da349006f1f3f2",<br>    "subnet-0a1be420dfdece6aa",<br>    "subnet-0e9a6986af3863233"<br>  ],<br>  "rd-ue1": [<br>    "subnet-0a5dcbb302f5e60bb",<br>    "subnet-07f687619a5c10008",<br>    "subnet-0cc79b9e76a788c2a"<br>  ],<br>  "uat-ue1": [<br>    "subnet-0ee4946eb39ec7530",<br>    "subnet-0e1cf9278f054d7f6",<br>    "subnet-0e58709f69fbc5c6e"<br>  ]<br>}</pre> | no |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | vpc id | `map(string)` | <pre>{<br>  "prod2-ue1": "vpc-00b9c80d27b97b65b",<br>  "qa-ue1": "vpc-0c0fa2a42c9db1744",<br>  "rd-ue1": "vpc-093635542e1c3c78e",<br>  "uat-ue1": "vpc-05eaf056fac1f8765"<br>}</pre> | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
