# lambda-app-auth-etl-nc-converter: a new lambda function
- Need to reach out to Vault to get the sensitive data
    + enable VPC integration
    + need to encrypt the Vault token from environment variables
- The function is scheduled to run by a period of time
    + setup eventbridge (or cloudwatch events)
    + setup a cron from eventbridge to run by a schedule
<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_lambda-app-auth-etl-nc-converter"></a> [lambda-app-auth-etl-nc-converter](#module\_lambda-app-auth-etl-nc-converter) | git::git@github.com:sandatech/terraform-aws-module-lambda-generic.git | v0.0.1 |

## Resources

| Name | Type |
|------|------|
| [aws_iam_role_policy.lambda_kms_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_iam_policy_document.kms_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [terraform_remote_state.kms_apply_to_encrypt_secrets](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_eventbridge_run_schedule"></a> [eventbridge\_run\_schedule](#input\_eventbridge\_run\_schedule) | This schedule to run may be different per environment | `map(string)` | <pre>{<br>  "prod2-ue1": "cron(20 0/1 ? * * *)",<br>  "qa-ue1": "cron(10 0/1 ? * * *)",<br>  "rd-ue1": "cron(5 0/1 ? * * *)",<br>  "uat-ue1": "cron(15 0/1 ? * * *)"<br>}</pre> | no |
| <a name="input_lambda_function_name"></a> [lambda\_function\_name](#input\_lambda\_function\_name) | n/a | `string` | `"lambda-auth-etl-nc-converter"` | no |
| <a name="input_lambda_source_code_hash"></a> [lambda\_source\_code\_hash](#input\_lambda\_source\_code\_hash) | If the hash is the the same there is no update to source code package when Terraform code is applied | `map(string)` | <pre>{<br>  "prod2-ue1": "bvERV9vwSsfYuUbwaEfdi2OFp6mj9FBA42cF0RBF/xg=",<br>  "qa-ue1": "",<br>  "rd-ue1": "GGHCLhv9ZtGLVYpjolicD6/51YoNGC0A6Skl+slRDZw=",<br>  "uat-ue1": ""<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
