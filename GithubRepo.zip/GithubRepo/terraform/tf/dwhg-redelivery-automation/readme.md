# How to generate KMS secret key https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/kms_secrets

kms_secret_encryption_arn=arn:aws:kms:us-east-1:988716822681:key/2d16b3af-958a-4281-a6ec-db62c0d04d7a
STRING_TO_ENCRYPT=abc
aws kms encrypt --key-id $kms_secret_encryption_arn --plaintext $STRING_TO_ENCRYPT --output json --query CiphertextBlob --profile tf_rd --region us-east-1 | jq<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_archive"></a> [archive](#provider\_archive) | n/a |
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_lambda-app"></a> [lambda-app](#module\_lambda-app) | git::git@github.com:sandatech/terraform-aws-module-lambda-generic.git | v0.0.1 |

## Resources

| Name | Type |
|------|------|
| [aws_cloudwatch_event_rule.dwhg_alert](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_rule) | resource |
| [aws_cloudwatch_event_target.send_to_sqs](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_target) | resource |
| [aws_iam_role_policy.lambda_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_lambda_event_source_mapping.sqs_to_lambda](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_event_source_mapping) | resource |
| [aws_sqs_queue.sqs_queue](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sqs_queue) | resource |
| [aws_sqs_queue_policy.sqs_queue](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sqs_queue_policy) | resource |
| [archive_file.lambda_dwhg_trigger_zip](https://registry.terraform.io/providers/hashicorp/archive/latest/docs/data-sources/file) | data source |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_cloudwatch_event_source.newrelic_alert](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/cloudwatch_event_source) | data source |
| [aws_iam_policy_document.lambda_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.sqs_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_kms_key.kms_secret_encryption](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/kms_key) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [terraform_remote_state.kms_app_secret_encryption](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_aws_kms_secrets_dwhg_token"></a> [aws\_kms\_secrets\_dwhg\_token](#input\_aws\_kms\_secrets\_dwhg\_token) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "AQICAHjMR4CU4PX36l8MT/nZOQc20z7f0BDix9xdr29rGeRjNAGtdcf4ZdHo+AGO+KnatBXEAAAAfjB8BgkqhkiG9w0BBwagbzBtAgEAMGgGCSqGSIb3DQEHATAeBglghkgBZQMEAS4wEQQM95cpjbx9kARm0E9BAgEQgDtXWn72CkUNJSOpR89AkZtwyO3YmEijsf6Nb/8Ylz2nx+0+RnrY/7R+hWo26SRdAglFyWsA6Bt02E3T9w==",<br>  "rd-ue1": "AQICAHgp5UoiPH/LhfcebZv7loYYjdT9QSaGrBsBfrDwSsugzAFAErr/x90zxUS+1wOmep8/AAAAfjB8BgkqhkiG9w0BBwagbzBtAgEAMGgGCSqGSIb3DQEHATAeBglghkgBZQMEAS4wEQQMX0f+SZiouugH3LLaAgEQgDtRkhW1bHHxeXVHZS71tQxCDdOM4y7qwkRke2D/Wv+72++2a3YvKkrItL7eIL9dez8KKgu4RhJbzO4E8w=="<br>}</pre> | no |
| <a name="input_dwhg_api_hostname"></a> [dwhg\_api\_hostname](#input\_dwhg\_api\_hostname) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "internal-xl.prod2.us-east-1.sandata.com",<br>  "rd-ue1": "internal-xl.rd.us-east-1.sandata.com"<br>}</pre> | no |
| <a name="input_eb_event_bus"></a> [eb\_event\_bus](#input\_eb\_event\_bus) | ## EventBridge | `map(any)` | <pre>{<br>  "prod2-ue1": "aws.partner/newrelic.com/2552026/dwhg_prod2_sftp_redelivery",<br>  "rd-ue1": "aws.partner/newrelic.com/2552026/dwhg_sftp_redelivery"<br>}</pre> | no |
| <a name="input_email_recipient_csv_list"></a> [email\_recipient\_csv\_list](#input\_email\_recipient\_csv\_list) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "vu.to@sandata.com,DevOps_Team@sandata.com,BHenriksen@sandata.com",<br>  "rd-ue1": "vu.to@sandata.com"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_lambda_function_name"></a> [lambda\_function\_name](#input\_lambda\_function\_name) | n/a | `string` | `"lambda-app-dwhg-redelivery-trigger"` | no |
| <a name="input_lambda_source_code_hash"></a> [lambda\_source\_code\_hash](#input\_lambda\_source\_code\_hash) | If the hash is the the same there is no update to source code package when Terraform code is applied | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "rd-ue1": ""<br>}</pre> | no |
| <a name="input_queue_delay_seconds"></a> [queue\_delay\_seconds](#input\_queue\_delay\_seconds) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": 900,<br>  "rd-ue1": 120<br>}</pre> | no |
| <a name="input_queue_name"></a> [queue\_name](#input\_queue\_name) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": "DEVOPS_DWHG_SFTP_REDELIVERY",<br>  "rd-ue1": "DEVOPS_DWHG_SFTP_REDELIVERY"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_eb_event_bus"></a> [eb\_event\_bus](#output\_eb\_event\_bus) | n/a |
| <a name="output_eb_rule_dwhg_arn"></a> [eb\_rule\_dwhg\_arn](#output\_eb\_rule\_dwhg\_arn) | n/a |
| <a name="output_eb_rule_dwhg_name"></a> [eb\_rule\_dwhg\_name](#output\_eb\_rule\_dwhg\_name) | n/a |
| <a name="output_sqs_delay_in_seconds"></a> [sqs\_delay\_in\_seconds](#output\_sqs\_delay\_in\_seconds) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
