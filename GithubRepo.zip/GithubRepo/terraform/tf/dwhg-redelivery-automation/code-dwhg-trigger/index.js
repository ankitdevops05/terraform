var AWS = require('aws-sdk');
const https = require('https');
var ses = new AWS.SES({ region: "us-east-1", apiVersion: '2010-12-01' });
const kms = new AWS.KMS();

const DWHG_TOKEN_ENCRYPTED = process.env['DWHG_TOKEN'];
const RECIPIENT_CSV_LIST = process.env['RECIPIENT_CSV_LIST'] || "vu.to@sandata.com";
const DWHG_API_HOSTNAME = process.env['DWHG_API_HOSTNAME'] || "internal-xl.rd.us-east-1.sandata.com";

exports.handler = async function(event, context) {

    //Accept data from SQS
    for (const record of event.Records) {

        const { body } = record;
        console.log("body", body);
        const jsonBody = JSON.parse(body);
        console.log("jsonBody", jsonBody);
        const { export_id, sid, customer } = jsonBody.detail.tags;
        const cluster_name = jsonBody.detail.tags["`cluster_name`"];

        console.log("DWHG_TOKEN_ENCRYPTED", DWHG_TOKEN_ENCRYPTED)
        let decryptedToken = await decryptSecret(DWHG_TOKEN_ENCRYPTED);

        const inputParams = `customer: ${customer}; export_id: ${export_id}; sid: ${sid}; cluster_name: ${cluster_name}`

        //Send start trigger email
        let subjectStart = `[DWHG Redelivery] Starting to trigger Redelivery API - ${inputParams}`;
        let recipient_emails = RECIPIENT_CSV_LIST.split(",");
        let bodyStart = `INPUT PARAMETERS - ${inputParams}` + "\n\n" + `HTTPS API ENDPOINT - ${DWHG_API_HOSTNAME}/dwhg/export/join/api/v1/delivery/retry/exportId/${export_id}/sid/${sid}` +
        "\n\n\n>>> Already triggered the API, it may take up to 5 mins to receive the result. Please wait for the result from another email."
        let sesResponseStart = await sendEmail(subjectStart, recipient_emails, bodyStart);
        console.log("sesResponseStart from SES", sesResponseStart);

        //Trigger the API and send result email
        let subjectEnd = `[DWHG Redelivery] Getting result from Redelivery API - ${inputParams}`;
        console.log(`>>>Starting to trigger the redlivery api for exportId/${export_id}/sid/${sid}`)
        let apiResponse = await triggerDwhSftpRetryAPI(sid, export_id, decryptedToken);
        console.log("response from apiResponse", apiResponse);
        let bodyApiResponse = `INPUT PARAMETERS - ${inputParams}` + "\n\n" + `HTTPS API ENDPOINT - ${DWHG_API_HOSTNAME}/dwhg/export/join/api/v1/delivery/retry/exportId/${export_id}/sid/${sid}` +
        "\n\n\n>>> Result:\n"  + JSON.stringify(apiResponse,null, 4);
        console.log(`<<<Ending to trigger the redlivery api for exportId/${export_id}/sid/${sid}`)
        let sesResponseEnd = await sendEmail(subjectEnd, recipient_emails, bodyApiResponse);
        console.log("sesResponseEnd from SES", sesResponseEnd);

    };

    return {};
}

const triggerDwhSftpRetryAPI = async (sid, export_id, decryptedToken) => {
    //https://internal-xl.rd.us-east-1.sandata.com/dwhg/export/join/api/v1/delivery/retry/exportId/d19cd2e0-4705-a742-564644bc2e1a/sid/828981

    const DWHG_API_TRIGGER_PATH = `/dwhg/export/join/api/v1/delivery/retry/exportId/${export_id}/sid/${sid}`;

    console.log("DWHG_API_HOSTNAME=", DWHG_API_HOSTNAME);
    console.log("DWHG_API_TRIGGER_PATH=", DWHG_API_TRIGGER_PATH);
    console.log("DWHG_API_TOKEN=", decryptedToken.slice(0,3) + "######");

    const options = {
        hostname: DWHG_API_HOSTNAME,
        port: 443,
        path: DWHG_API_TRIGGER_PATH,
        method: 'GET',
        headers: {
            'token': decryptedToken,
            'sid': sid,
            'export_id': export_id
        },
    };

    let promise = new Promise((resolve, reject) => {
        const req = https.request(options, (res) => {
            res.setEncoding('utf8');
            let responseBody = '';

            res.on('data', (chunk) => {
                responseBody += chunk;
            });

            res.on('end', () => {

                const resStatusCode = res.statusCode;

                console.log("responseBody", responseBody)
                console.log("res.headers", res.headers)
                console.log("res.statusCode", res.statusCode)

                if(res.statusCode == 200) {
                    resolve(JSON.parse(responseBody));
                } else {
                    resolve({
                        statusCode: resStatusCode,
                        body: responseBody
                    })
                }

            });
        });

        req.on('error', (err) => {
            reject(err);
        });
        req.end();
    });

    return await promise;
}

const sendEmail = async (subject, recipient_emails, body) => {

    let params = {
        Destination: {
            ToAddresses: recipient_emails,
        },
        Message: {
            Subject: { Data: subject },
            Body: {
                Text: { Data: body },
            }
        },
        Source: "no-reply@sandata.com",
    };

    let sesPromise = ses.sendEmail(params).promise();

    let response = await sesPromise;

    return response;
}

const decryptSecret = async (encryptedValue) => {
    let decryptValue = ''
    try {
        const req = { CiphertextBlob: Buffer.from(encryptedValue, 'base64') };
        const data = await kms.decrypt(req).promise();
        decryptValue = data.Plaintext.toString('ascii');
    } catch (err) {
        throw err;
    }
    return decryptValue;
}