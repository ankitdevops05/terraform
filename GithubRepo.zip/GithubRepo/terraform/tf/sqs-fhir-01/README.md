# sqs-rapid7idr-01

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_sqs-rapid7-01"></a> [sqs-rapid7-01](#module\_sqs-rapid7-01) | git::git@github.com:sandatech/terraform-module-sqs.git | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_iam_user.fhir_queue_user](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_user) | resource |
| [aws_iam_user_policy.fhir_queue_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_user_policy) | resource |
| [aws_kms_key.fhir_key](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/kms_key) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_fhir_queue_username"></a> [fhir\_queue\_username](#input\_fhir\_queue\_username) | n/a | `map` | <pre>{<br>  "prod2-ue1": "prod2-fhir-sqs-user",<br>  "qa-ue1": "qa-fhir-sqs-user",<br>  "rd-ue1": "rd-fhir-sqs-user",<br>  "uat-ue1": "uat-fhir-sqs-user"<br>}</pre> | no |
| <a name="input_iam_user"></a> [iam\_user](#input\_iam\_user) | n/a | `map` | <pre>{<br>  "prod2-ue1": "prod2-fhir-sqs",<br>  "qa-ue1": "qa-fhir-sqs",<br>  "rd-ue1": "rd-fhir-sqs",<br>  "uat-ue1": "uat-fhir-sqs"<br>}</pre> | no |
| <a name="input_map_migrated"></a> [map\_migrated](#input\_map\_migrated) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "mig34085",<br>  "prod2-ue2": "mig34085",<br>  "qa-ue1": "mig34085",<br>  "qa-ue2": "mig34085",<br>  "rd-ue1": "mig34085",<br>  "rd-ue2": "mig34085",<br>  "sb-ue1": "mig34085",<br>  "ss-ue1": "mig34085",<br>  "uat-ue1": "mig34085",<br>  "uat-ue2": "mig34085"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_sqs_queue_name"></a> [sqs\_queue\_name](#input\_sqs\_queue\_name) | n/a | `map` | <pre>{<br>  "prod2-ue1": "prod2-fhir-sqs-01",<br>  "qa-ue1": "qa-fhir-sqs-01",<br>  "rd-ue1": "rd-fhir-sqs-01",<br>  "uat-ue1": "uat-fhir-sqs-01"<br>}</pre> | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
