# rds-common-storage-01

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | = 4.67.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_module-rds-01"></a> [module-rds-01](#module\_module-rds-01) | git@github.com:sandatech/terraform-aws-module-rds-01.git | v0.0.3 |
| <a name="module_module-rds-sg"></a> [module-rds-sg](#module\_module-rds-sg) | git@github.com:sandatech/terraform-aws-module-security-groups-01.git | v0.0.6 |

## Resources

| Name | Type |
|------|------|
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_backup_window"></a> [backup\_window](#input\_backup\_window) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "03:00-06:00",<br>  "qa-ue1": "03:00-06:00",<br>  "rd-ue1": "03:00-06:00",<br>  "sb-ue1": "03:00-06:00",<br>  "uat-ue1": "03:00-06:00"<br>}</pre> | no |
| <a name="input_engine_version"></a> [engine\_version](#input\_engine\_version) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "12.7",<br>  "qa-ue1": "12.7",<br>  "rd-ue1": "12.7",<br>  "sb-ue1": "12.5",<br>  "uat-ue1": "12.7"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_instance_class"></a> [instance\_class](#input\_instance\_class) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "db.r5.large",<br>  "qa-ue1": "db.r5.large",<br>  "rd-ue1": "db.r5.large",<br>  "sb-ue1": "db.t3.micro",<br>  "uat-ue1": "db.t4g.large"<br>}</pre> | no |
| <a name="input_maintenance_window"></a> [maintenance\_window](#input\_maintenance\_window) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "Sat:23:00-Sun:02:00",<br>  "qa-ue1": "Sat:23:00-Sun:02:00",<br>  "rd-ue1": "Sat:23:00-Sun:02:00",<br>  "sb-ue1": "Sat:23:00-Sun:02:00",<br>  "uat-ue1": "Sat:23:00-Sun:02:00"<br>}</pre> | no |
| <a name="input_monitoring_iam_role"></a> [monitoring\_iam\_role](#input\_monitoring\_iam\_role) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "arn:aws:iam::656560712260:role/sd-prod2-us-east-1-common-rds-monitoring-role-01",<br>  "qa-ue1": "arn:aws:iam::046839536952:role/sd-qa-us-east-1-common-rds-monitoring-role-01",<br>  "rd-ue1": "arn:aws:iam::817297989338:role/sd-rd-us-east-1-common-rds-monitoring-role-01",<br>  "sb-ue1": "arn:aws:iam::915867530647:role/sd-sb-us-east-1-common-rds-monitoring-role-01",<br>  "uat-ue1": "arn:aws:iam::244940236506:role/sd-uat-us-east-1-common-rds-monitoring-role-01"<br>}</pre> | no |
| <a name="input_monitoring_interval"></a> [monitoring\_interval](#input\_monitoring\_interval) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": 60,<br>  "qa-ue1": 60,<br>  "rd-ue1": 60,<br>  "uat-ue1": 60<br>}</pre> | no |
| <a name="input_password"></a> [password](#input\_password) | n/a | `string` | `""` | no |
| <a name="input_performance_insights_enabled"></a> [performance\_insights\_enabled](#input\_performance\_insights\_enabled) | n/a | `bool` | `true` | no |
| <a name="input_rds_sg_ports_ingress"></a> [rds\_sg\_ports\_ingress](#input\_rds\_sg\_ports\_ingress) | n/a | `map` | <pre>{<br>  "prod2-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata internal IPs",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "5432"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.16.36.0/22",<br>        "172.16.44.0/22",<br>        "172.16.52.0/22"<br>      ],<br>      "description": "Application Subnets",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "self": true,<br>      "to_port": [<br>        "5432"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.16.196.144/32"<br>      ],<br>      "description": "Bamboo",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "5432"<br>      ]<br>    }<br>  ],<br>  "qa-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19",<br>        "172.18.20.0/22"<br>      ],<br>      "description": "Sandata internal IPs",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "5432"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.16.76.0/22",<br>        "172.16.84.0/22",<br>        "172.16.68.0/22"<br>      ],<br>      "description": "Application Subnets",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "self": true,<br>      "to_port": [<br>        "5432"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.16.196.144/32"<br>      ],<br>      "description": "Bamboo",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "5432"<br>      ]<br>    }<br>  ],<br>  "rd-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata internal IPs",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "5432"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.16.132.0/22",<br>        "172.16.140.0/22",<br>        "172.16.148.0/22"<br>      ],<br>      "description": "Application Subnets",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "self": true,<br>      "to_port": [<br>        "5432"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.16.196.144/32"<br>      ],<br>      "description": "Bamboo",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "5432"<br>      ]<br>    }<br>  ],<br>  "sb-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19",<br>        "172.31.0.48/32"<br>      ],<br>      "description": "Sandata internal IPs",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "5432"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.16.164.0/22",<br>        "172.16.172.0/22",<br>        "172.16.180.0/22"<br>      ],<br>      "description": "Application Subnets",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "5432"<br>      ]<br>    }<br>  ],<br>  "uat-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata internal IPs",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "5432"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.16.228.0/22",<br>        "172.16.236.0/22",<br>        "172.16.244.0/22"<br>      ],<br>      "description": "Application Subnets",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "self": true,<br>      "to_port": [<br>        "5432"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.16.196.144/32"<br>      ],<br>      "description": "Bamboo",<br>      "from_port": [<br>        "5432"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "5432"<br>      ]<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_this_db_instance_address"></a> [this\_db\_instance\_address](#output\_this\_db\_instance\_address) | The address of the RDS instance |
| <a name="output_this_db_instance_arn"></a> [this\_db\_instance\_arn](#output\_this\_db\_instance\_arn) | The ARN of the RDS instance |
| <a name="output_this_db_instance_availability_zone"></a> [this\_db\_instance\_availability\_zone](#output\_this\_db\_instance\_availability\_zone) | The availability zone of the RDS instance |
| <a name="output_this_db_instance_domain_role"></a> [this\_db\_instance\_domain\_role](#output\_this\_db\_instance\_domain\_role) | The address of the RDS instance |
| <a name="output_this_db_instance_endpoint"></a> [this\_db\_instance\_endpoint](#output\_this\_db\_instance\_endpoint) | The connection endpoint |
| <a name="output_this_db_instance_hosted_zone_id"></a> [this\_db\_instance\_hosted\_zone\_id](#output\_this\_db\_instance\_hosted\_zone\_id) | The canonical hosted zone ID of the DB instance (to be used in a Route 53 Alias record) |
| <a name="output_this_db_instance_id"></a> [this\_db\_instance\_id](#output\_this\_db\_instance\_id) | The RDS instance ID |
| <a name="output_this_db_instance_name"></a> [this\_db\_instance\_name](#output\_this\_db\_instance\_name) | The database name |
| <a name="output_this_db_instance_port"></a> [this\_db\_instance\_port](#output\_this\_db\_instance\_port) | The database port |
| <a name="output_this_db_instance_resource_id"></a> [this\_db\_instance\_resource\_id](#output\_this\_db\_instance\_resource\_id) | The RDS Resource ID of this instance |
| <a name="output_this_db_instance_status"></a> [this\_db\_instance\_status](#output\_this\_db\_instance\_status) | The RDS instance status |
| <a name="output_this_db_instance_username"></a> [this\_db\_instance\_username](#output\_this\_db\_instance\_username) | The master username for the database |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
