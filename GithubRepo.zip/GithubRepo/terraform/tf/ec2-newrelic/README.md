# ec2-newrelic

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ec2"></a> [ec2](#module\_ec2) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.6 |

## Resources

| Name | Type |
|------|------|
| [aws_security_group.newrelic_sg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group_rule.newrelic_snmp](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.newrelic_ssh](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_ami.aws_linux](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ami) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_allowed_cirds"></a> [allowed\_cirds](#input\_allowed\_cirds) | List of VPC security groups to associate | `list(string)` | <pre>[<br>  "172.18.20.0/22",<br>  "10.15.0.0/20",<br>  "172.18.24.0/22"<br>]</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_instances_number"></a> [instances\_number](#input\_instances\_number) | n/a | `number` | `1` | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_instances_private_ips"></a> [instances\_private\_ips](#output\_instances\_private\_ips) | Private IPs assigned to the EC2 instance |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
