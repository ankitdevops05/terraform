const AWS = require('aws-sdk');
const ses = new AWS.SES({ region: "us-east-1", apiVersion: '2010-12-01' });
const RECIPIENT_CSV_LIST = process.env['RECIPIENT_CSV_LIST'] || "vu.to@sandata.com";

exports.handler = async function(event, context) {

    console.log("event", event);


        //let subject = `DWHG Redelivery - customer: ${customer}; export_id: ${export_id}; sid: ${sid};`;

        const { export_id, sid, customer } = event.detail.tags;
        const cluster_name = event.detail.tags["`cluster_name`"];

        let subject = `[DWHG Redelivery] Queuing A Redelivery Request - customer: ${customer}; export_id: ${export_id}; sid: ${sid}; cluster_name: ${cluster_name}`;
        let recipient_emails = RECIPIENT_CSV_LIST.split(",");
        let apiTrigger = "Queuing a DWHG redelivery request for 15 minutes and then trigger the DWHG Redelivery API. \n\n";
        let content = apiTrigger + "NewRelic Alert: \n" + JSON.stringify(event.detail, null, 4);

        let sesResponse = await sendEmail(subject, recipient_emails, content);
        console.log("response from SES", sesResponse);

    return {};
};


const sendEmail = async (subject, recipient_emails, body) => {

    let params = {
        Destination: {
            ToAddresses: recipient_emails,
        },
        Message: {
            Subject: { Data: subject },
            Body: {
                Text: { Data: body },
            }
        },
        Source: "no-reply@sandata.com",
    };

    let sesPromise = ses.sendEmail(params).promise();

    let response = await sesPromise;

    return response;
};