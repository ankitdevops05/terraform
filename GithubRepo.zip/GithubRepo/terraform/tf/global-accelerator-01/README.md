# global-accelerator-01
This is for SMC app01.sandata.com

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_globalaccelerator_accelerator.eks_ga](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/globalaccelerator_accelerator) | resource |
| [aws_globalaccelerator_endpoint_group.endpoint_ue1](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/globalaccelerator_endpoint_group) | resource |
| [aws_globalaccelerator_endpoint_group.endpoint_ue2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/globalaccelerator_endpoint_group) | resource |
| [aws_globalaccelerator_listener.eks_ga_443](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/globalaccelerator_listener) | resource |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [terraform_remote_state.alb_proxy_ue1](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |
| [terraform_remote_state.alb_proxy_ue2](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |
| [terraform_remote_state.aws_certs](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_alb_behind_glocal_accelerator_ue1"></a> [alb\_behind\_glocal\_accelerator\_ue1](#input\_alb\_behind\_glocal\_accelerator\_ue1) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "global-accelerator-alb-proxy-01",<br>  "qa-ue1": "global-accelerator-alb-proxy-01",<br>  "rd-ue1": "global-accelerator-alb-proxy-01",<br>  "sb-ue1": "",<br>  "ss-ue1": "",<br>  "uat-ue1": "global-accelerator-alb-proxy-01"<br>}</pre> | no |
| <a name="input_alb_behind_glocal_accelerator_ue2"></a> [alb\_behind\_glocal\_accelerator\_ue2](#input\_alb\_behind\_glocal\_accelerator\_ue2) | As GA is only running in US-EAST-1, use ue1 region to mapping name in secondary region | `map(string)` | <pre>{<br>  "prod2-ue1": "global-accelerator-alb-proxy-01",<br>  "qa-ue1": "global-accelerator-alb-proxy-01",<br>  "rd-ue1": "global-accelerator-alb-proxy-01",<br>  "sb-ue1": "",<br>  "ss-ue1": "",<br>  "uat-ue1": "global-accelerator-alb-proxy-01"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_traffic_dial_percentage_ue1"></a> [traffic\_dial\_percentage\_ue1](#input\_traffic\_dial\_percentage\_ue1) | n/a | `map(number)` | <pre>{<br>  "prod2-ue1": 100,<br>  "qa-ue1": 100,<br>  "rd-ue1": 100,<br>  "sb-ue1": 100,<br>  "ss-ue1": 100,<br>  "uat-ue1": 100<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_aws_globalaccelerator_accelerator_dns"></a> [aws\_globalaccelerator\_accelerator\_dns](#output\_aws\_globalaccelerator\_accelerator\_dns) | n/a |
| <a name="output_oh_traffic_settings"></a> [oh\_traffic\_settings](#output\_oh\_traffic\_settings) | n/a |
| <a name="output_va_traffic_settings"></a> [va\_traffic\_settings](#output\_va\_traffic\_settings) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
