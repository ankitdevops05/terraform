# eks-fargate-cluster-gen2-01

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_eks"></a> [eks](#module\_eks) | git@github.com:sandatech/terraform-aws-module-eks-01.git | v0.0.26 |

## Resources

| Name | Type |
|------|------|
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_aws_eks_addon_version_most_recent"></a> [aws\_eks\_addon\_version\_most\_recent](#input\_aws\_eks\_addon\_version\_most\_recent) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": true,<br>  "prod2-ue2": true,<br>  "qa-ue1": true,<br>  "qa-ue2": true,<br>  "rd-ue1": true,<br>  "rd-ue2": true,<br>  "sb-ue1": false,<br>  "ss-ue1": true,<br>  "uat-ue1": true,<br>  "uat-ue2": true<br>}</pre> | no |
| <a name="input_aws_eks_addons_enable"></a> [aws\_eks\_addons\_enable](#input\_aws\_eks\_addons\_enable) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": true,<br>  "prod2-ue2": true,<br>  "qa-ue1": true,<br>  "qa-ue2": true,<br>  "rd-ue1": true,<br>  "rd-ue2": true,<br>  "sb-ue1": false,<br>  "ss-ue1": true,<br>  "uat-ue1": true,<br>  "uat-ue2": true<br>}</pre> | no |
| <a name="input_desired_capacity"></a> [desired\_capacity](#input\_desired\_capacity) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "3",<br>  "prod2-ue2": "3",<br>  "qa-ue1": "3",<br>  "qa-ue2": "3",<br>  "rd-ue1": "3",<br>  "rd-ue2": "3",<br>  "sb-ue1": "2",<br>  "ss-ue1": "3",<br>  "ss-ue2": "3",<br>  "uat-ue1": "3",<br>  "uat-ue2": "3"<br>}</pre> | no |
| <a name="input_eks_version"></a> [eks\_version](#input\_eks\_version) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "1.25",<br>  "prod2-ue2": "1.25",<br>  "qa-ue1": "1.25",<br>  "qa-ue2": "1.25",<br>  "rd-ue1": "1.25",<br>  "rd-ue2": "1.25",<br>  "sb-ue1": "1.21",<br>  "ss-ue1": "1.25",<br>  "ss-ue2": "none",<br>  "uat-ue1": "1.25",<br>  "uat-ue2": "1.25"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_external_ip"></a> [external\_ip](#input\_external\_ip) | n/a | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "207.140.140.193/32",<br>    "10.15.0.0/20",<br>    "10.14.8.0/22",<br>    "172.16.206.61/32"<br>  ],<br>  "prod2-ue2": [<br>    "207.140.140.193/32",<br>    "10.15.0.0/20",<br>    "10.14.8.0/22",<br>    "172.16.206.61/32"<br>  ],<br>  "qa-ue1": [<br>    "207.140.140.193/32",<br>    "10.15.0.0/20",<br>    "10.14.8.0/22",<br>    "172.16.206.61/32"<br>  ],<br>  "qa-ue2": [<br>    "207.140.140.193/32",<br>    "10.15.0.0/20",<br>    "10.14.8.0/22",<br>    "172.16.206.61/32"<br>  ],<br>  "rd-ue1": [<br>    "207.140.140.193/32",<br>    "10.15.0.0/20",<br>    "10.14.8.0/22",<br>    "172.16.206.61/32"<br>  ],<br>  "rd-ue2": [<br>    "207.140.140.193/32",<br>    "10.15.0.0/20",<br>    "10.14.8.0/22",<br>    "172.16.206.61/32"<br>  ],<br>  "sb-ue1": [<br>    "207.140.140.193/32",<br>    "10.15.0.0/20",<br>    "10.14.8.0/22",<br>    "172.16.206.61/32"<br>  ],<br>  "ss-ue1": [<br>    "207.140.140.193/32",<br>    "10.15.0.0/20",<br>    "10.14.8.0/22",<br>    "172.16.206.61/32"<br>  ],<br>  "ss-ue2": [<br>    "207.140.140.193/32",<br>    "10.15.0.0/20",<br>    "10.14.8.0/22",<br>    "172.16.206.61/32"<br>  ],<br>  "uat-ue1": [<br>    "207.140.140.193/32",<br>    "10.15.0.0/20",<br>    "10.14.8.0/22",<br>    "172.16.206.61/32"<br>  ],<br>  "uat-ue2": [<br>    "207.140.140.193/32",<br>    "10.15.0.0/20",<br>    "10.14.8.0/22",<br>    "172.16.206.61/32"<br>  ]<br>}</pre> | no |
| <a name="input_fargate_profile_kube_system_labels"></a> [fargate\_profile\_kube\_system\_labels](#input\_fargate\_profile\_kube\_system\_labels) | n/a | `map(map(string))` | <pre>{<br>  "prod2-ue1": {},<br>  "prod2-ue2": {},<br>  "qa-ue1": {},<br>  "qa-ue2": {},<br>  "rd-ue1": {},<br>  "rd-ue2": {},<br>  "sb-ue1": {<br>    "eks.amazonaws.com/component": "coredns",<br>    "k8s-app": "kube-dns"<br>  },<br>  "ss-ue1": {},<br>  "ss-ue2": {},<br>  "uat-ue1": {},<br>  "uat-ue2": {}<br>}</pre> | no |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "t3.medium",<br>  "prod2-ue2": "t3.medium",<br>  "qa-ue1": "t3.medium",<br>  "qa-ue2": "t3.medium",<br>  "rd-ue1": "t3.medium",<br>  "rd-ue2": "t3.medium",<br>  "sb-ue1": "t3.small",<br>  "ss-ue1": "t3.medium",<br>  "ss-ue2": "t3.medium",<br>  "uat-ue1": "t3.medium",<br>  "uat-ue2": "t3.medium"<br>}</pre> | no |
| <a name="input_max_size"></a> [max\_size](#input\_max\_size) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "6",<br>  "prod2-ue2": "6",<br>  "qa-ue1": "6",<br>  "qa-ue2": "6",<br>  "rd-ue1": "6",<br>  "rd-ue2": "6",<br>  "sb-ue1": "4",<br>  "ss-ue1": "6",<br>  "ss-ue2": "6",<br>  "uat-ue1": "6",<br>  "uat-ue2": "6"<br>}</pre> | no |
| <a name="input_min_size"></a> [min\_size](#input\_min\_size) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "3",<br>  "prod2-ue2": "3",<br>  "qa-ue1": "3",<br>  "qa-ue2": "3",<br>  "rd-ue1": "3",<br>  "rd-ue2": "3",<br>  "sb-ue1": "2",<br>  "ss-ue1": "3",<br>  "ss-ue2": "3",<br>  "uat-ue1": "3",<br>  "uat-ue2": "3"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_EKSNodeSecGroup"></a> [EKSNodeSecGroup](#output\_EKSNodeSecGroup) | n/a |
| <a name="output_alb-ingress-controller-role-arn"></a> [alb-ingress-controller-role-arn](#output\_alb-ingress-controller-role-arn) | alb-ingress-controller-role-arn |
| <a name="output_config-map-aws-auth"></a> [config-map-aws-auth](#output\_config-map-aws-auth) | n/a |
| <a name="output_default_config_map_aws_auth"></a> [default\_config\_map\_aws\_auth](#output\_default\_config\_map\_aws\_auth) | n/a |
| <a name="output_ec2nodes"></a> [ec2nodes](#output\_ec2nodes) | n/a |
| <a name="output_ec2nodesandfargate"></a> [ec2nodesandfargate](#output\_ec2nodesandfargate) | n/a |
| <a name="output_eks_cluster_identity_oidc_issuer"></a> [eks\_cluster\_identity\_oidc\_issuer](#output\_eks\_cluster\_identity\_oidc\_issuer) | The OIDC Identity issuer for the cluster |
| <a name="output_eks_fargate_profile_arn"></a> [eks\_fargate\_profile\_arn](#output\_eks\_fargate\_profile\_arn) | ARN of the EKS Fargate Profile |
| <a name="output_eks_fargate_profile_id"></a> [eks\_fargate\_profile\_id](#output\_eks\_fargate\_profile\_id) | EKS Cluster name and EKS Fargate Profile name separated by a colon |
| <a name="output_eks_fargate_profile_role_arn"></a> [eks\_fargate\_profile\_role\_arn](#output\_eks\_fargate\_profile\_role\_arn) | ARN of the EKS Fargate Profile IAM role |
| <a name="output_eks_fargate_profile_role_name"></a> [eks\_fargate\_profile\_role\_name](#output\_eks\_fargate\_profile\_role\_name) | Name of the EKS Fargate Profile IAM role |
| <a name="output_eks_fargate_profile_status"></a> [eks\_fargate\_profile\_status](#output\_eks\_fargate\_profile\_status) | Status of the EKS Fargate Profile |
| <a name="output_kubeconfig"></a> [kubeconfig](#output\_kubeconfig) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
