# fms-waf-qa-ohio

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_waf"></a> [waf](#module\_waf) | git::git@github.com:sandatech/terraform-aws-module-waf2-01.git | v0.0.21 |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_blocked_ip_sets"></a> [blocked\_ip\_sets](#input\_blocked\_ip\_sets) | Blocked IPs | `map` | <pre>{<br>  "QA_BlockedIPSet": {<br>    "addresses": [<br>      "18.215.231.181/32"<br>    ],<br>    "priority": 10<br>  }<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_ip_sets"></a> [ip\_sets](#input\_ip\_sets) | URL Match sets to be added to waf2 | `map` | <pre>{<br>  "QA_EmployeesHomeIPSet": {<br>    "addresses": [<br>      "104.58.196.23/32",<br>      "173.52.37.189/32",<br>      "108.6.8.102/32",<br>      "67.87.37.66/32",<br>      "74.101.191.64/32",<br>      "67.245.124.124/32",<br>      "188.127.126.125/32",<br>      "146.255.132.119/32",<br>      "141.170.204.214/32"<br>    ],<br>    "priority": 22<br>  },<br>  "QA_ExternalSystemInteg": {<br>    "addresses": [<br>      "52.206.155.29/32"<br>    ],<br>    "priority": 24<br>  },<br>  "QA_KmsIPSet": {<br>    "addresses": [<br>      "125.212.208.58/32",<br>      "178.77.7.156/32"<br>    ],<br>    "priority": 27<br>  },<br>  "QA_LoopbackIPSet": {<br>    "addresses": [<br>      "127.0.0.1/32"<br>    ],<br>    "priority": 21<br>  },<br>  "QA_OfficeAndVpnIPSet": {<br>    "addresses": [<br>      "207.140.140.193/32",<br>      "172.18.24.0/22",<br>      "10.15.0.0/20",<br>      "172.18.20.0/22",<br>      "3.215.4.75/32"<br>    ],<br>    "priority": 23<br>  },<br>  "QA_SoftrayIPSet": {<br>    "addresses": [<br>      "77.77.221.115/32",<br>      "217.197.138.54/32",<br>      "108.54.216.100/32",<br>      "46.36.164.122/32",<br>      "74.12.76.94/32",<br>      "178.77.10.92/32",<br>      "109.175.106.25/32",<br>      "70.26.83.232/32",<br>      "77.77.214.146/32",<br>      "178.77.9.16/32",<br>      "31.185.126.141/32",<br>      "80.80.39.33/32",<br>      "77.77.222.49/32",<br>      "77.77.222.172/32",<br>      "109.175.97.115/32",<br>      "31.223.133.33/32",<br>      "217.197.136.25/32"<br>    ],<br>    "priority": 25<br>  },<br>  "QA_VendorsIPSet": {<br>    "addresses": [<br>      "76.73.219.56/32",<br>      "207.54.135.4/32",<br>      "69.54.57.42/32",<br>      "64.118.180.129/32",<br>      "64.118.180.10/32",<br>      "64.118.180.11/32",<br>      "52.72.89.101/32",<br>      "52.5.251.134/32",<br>      "23.21.34.188/32",<br>      "52.203.64.160/32",<br>      "117.217.127.56/32",<br>      "122.179.133.68/32",<br>      "223.225.95.254/32",<br>      "47.31.171.227/32",<br>      "210.18.157.68/32",<br>      "59.96.57.85/32",<br>      "77.77.214.146/32",<br>      "38.95.110.19/32"<br>    ],<br>    "priority": 20<br>  }<br>}</pre> | no |
| <a name="input_policy_name"></a> [policy\_name](#input\_policy\_name) | Rule group name | `string` | `"sd-admin-us-east-2-qa-fms-wafv2-policy-01"` | no |
| <a name="input_regex_sets"></a> [regex\_sets](#input\_regex\_sets) | Regex sets | `map` | <pre>{<br>  "QA_REGEX_match_condition": "/(?:(?:(?:ivr\\/twilio)|(?:(?:\\/saml))|(?:(?:\\/flight\\/devero_poc_import\\/))|(?:(?:\\/flight))))/"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_rule_group_name"></a> [rule\_group\_name](#input\_rule\_group\_name) | Rule group name | `string` | `"sd-admin-us-east-2-qa-rulegroup-01"` | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to add to all resources. | `map(string)` | <pre>{<br>  "Application": "Shared",<br>  "Backup": "",<br>  "Environment": "admin",<br>  "OS": "",<br>  "Owner": "Infrastructure",<br>  "Patch_Cycle": "",<br>  "Provisioned_by": "Terraform",<br>  "Purpose": "AWS WAF Policy and Rules",<br>  "Security": "",<br>  "Service": "Shared",<br>  "Version": "0.0.1",<br>  "map-migrated": "mig34085",<br>  "project": "WAFv2"<br>}</pre> | no |
| <a name="input_url_match_and_header"></a> [url\_match\_and\_header](#input\_url\_match\_and\_header) | URL Match urls and headers to be added to waf2 | `list` | <pre>[<br>  {<br>    "headers": [<br>      {<br>        "key": "x-sandatamapapikey",<br>        "token": "XYkjlbZDF4:Aafb9WBEKUGaJGynFkR6oA"<br>      },<br>      {<br>        "key": "x-key",<br>        "token": "XAnotherSecretValue"<br>      }<br>    ],<br>    "name": "QA_VC_MAP_URL_AND_HEADER",<br>    "priority": 60,<br>    "string": "vc/map"<br>  },<br>  {<br>    "headers": [<br>      {<br>        "key": "x-sandata-api-key",<br>        "token": "XYkjlbZDF4:Aafb9WBEKUGaJGynFkR6oA"<br>      },<br>      {<br>        "key": "x-key",<br>        "token": "XAnotherSecretValue"<br>      }<br>    ],<br>    "name": "QA_VC_WEB_URL_AND_HEADER",<br>    "priority": 61,<br>    "string": "vc/web"<br>  },<br>  {<br>    "headers": [<br>      {<br>        "key": "x-sandata-api-key",<br>        "token": "XYkjlbZDF4:Aafb9WBEKUGaJGynFkR6oA"<br>      },<br>      {<br>        "key": "x-key",<br>        "token": "XAnotherSecretValue"<br>      }<br>    ],<br>    "name": "QA_VC_MOBILE_AUTH_URL_AND_HEADER",<br>    "priority": 62,<br>    "string": "vc/mobile-auth"<br>  },<br>  {<br>    "headers": [<br>      {<br>        "key": "user-agent",<br>        "token": "TwilioProxy"<br>      },<br>      {<br>        "key": "x-key",<br>        "token": "XAnotherSecretValue"<br>      }<br>    ],<br>    "name": "QA_VC_IVR_URL_AND_HEADER",<br>    "priority": 63,<br>    "string": "vc/ivr/twilio"<br>  }<br>]</pre> | no |
| <a name="input_url_match_and_origin"></a> [url\_match\_and\_origin](#input\_url\_match\_and\_origin) | URL Match sets and origin to be added to waf2 | `list` | <pre>[<br>  {<br>    "name": "QA_SSO_AUTH_URL_AND_ORIGIN",<br>    "origin_urls": [<br>      "make-sure-there-are-atleast-2-origins-in-this-list",<br>      "https://idp.ss.us-east-1.sandata.com"<br>    ],<br>    "priority": 50,<br>    "string": "sso/auth"<br>  }<br>]</pre> | no |
| <a name="input_url_match_condition"></a> [url\_match\_condition](#input\_url\_match\_condition) | URL Match sets to be added to waf2 | `list` | <pre>[<br>  {<br>    "name": "QA_IVR_Regex_Set",<br>    "priority": 10,<br>    "string": "ivr/twilio"<br>  }<br>]</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_ipsets"></a> [ipsets](#output\_ipsets) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
