# s3-interfaces-replication

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_prod_s3_dev_interfaces_replicate_to_rd"></a> [prod\_s3\_dev\_interfaces\_replicate\_to\_rd](#module\_prod\_s3\_dev\_interfaces\_replicate\_to\_rd) | git@github.com:sandatech/terraform-aws-module-s3-replication-roles-policies.git | v0.0.4 |
| <a name="module_prod_s3_qa_interfaces_replicate_to_qa"></a> [prod\_s3\_qa\_interfaces\_replicate\_to\_qa](#module\_prod\_s3\_qa\_interfaces\_replicate\_to\_qa) | git@github.com:sandatech/terraform-aws-module-s3-replication-roles-policies.git | v0.0.4 |
| <a name="module_prod_s3_uat_interfaces_replicate_to_uat"></a> [prod\_s3\_uat\_interfaces\_replicate\_to\_uat](#module\_prod\_s3\_uat\_interfaces\_replicate\_to\_uat) | git@github.com:sandatech/terraform-aws-module-s3-replication-roles-policies.git | v0.0.4 |
| <a name="module_qa_replicate_to_prod_s3_qa_interfaces"></a> [qa\_replicate\_to\_prod\_s3\_qa\_interfaces](#module\_qa\_replicate\_to\_prod\_s3\_qa\_interfaces) | git@github.com:sandatech/terraform-aws-module-s3-replication-roles-policies.git | v0.0.4 |
| <a name="module_rd_replicate_to_prod_s3_dev_interfaces"></a> [rd\_replicate\_to\_prod\_s3\_dev\_interfaces](#module\_rd\_replicate\_to\_prod\_s3\_dev\_interfaces) | git@github.com:sandatech/terraform-aws-module-s3-replication-roles-policies.git | v0.0.4 |
| <a name="module_uat_replicate_to_prod_s3_uat_interfaces"></a> [uat\_replicate\_to\_prod\_s3\_uat\_interfaces](#module\_uat\_replicate\_to\_prod\_s3\_uat\_interfaces) | git@github.com:sandatech/terraform-aws-module-s3-replication-roles-policies.git | v0.0.4 |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_prod2_access_key"></a> [prod2\_access\_key](#input\_prod2\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_prod2_secret_key"></a> [prod2\_secret\_key](#input\_prod2\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_prod_access_key"></a> [prod\_access\_key](#input\_prod\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_prod_secret_key"></a> [prod\_secret\_key](#input\_prod\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_qa_access_key"></a> [qa\_access\_key](#input\_qa\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_qa_secret_key"></a> [qa\_secret\_key](#input\_qa\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_rd_access_key"></a> [rd\_access\_key](#input\_rd\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_rd_secret_key"></a> [rd\_secret\_key](#input\_rd\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_uat_access_key"></a> [uat\_access\_key](#input\_uat\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_uat_secret_key"></a> [uat\_secret\_key](#input\_uat\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_prod_s3_dev_interfaces_replicate_to_rd_iam_role_arn"></a> [prod\_s3\_dev\_interfaces\_replicate\_to\_rd\_iam\_role\_arn](#output\_prod\_s3\_dev\_interfaces\_replicate\_to\_rd\_iam\_role\_arn) | prod-dev to RD |
| <a name="output_prod_s3_dev_interfaces_replicate_to_rd_source_caller_id"></a> [prod\_s3\_dev\_interfaces\_replicate\_to\_rd\_source\_caller\_id](#output\_prod\_s3\_dev\_interfaces\_replicate\_to\_rd\_source\_caller\_id) | n/a |
| <a name="output_prod_s3_dev_interfaces_replicate_to_rd_target_caller_id"></a> [prod\_s3\_dev\_interfaces\_replicate\_to\_rd\_target\_caller\_id](#output\_prod\_s3\_dev\_interfaces\_replicate\_to\_rd\_target\_caller\_id) | n/a |
| <a name="output_prod_s3_qa_interfaces_replicate_to_qa_iam_role_arn"></a> [prod\_s3\_qa\_interfaces\_replicate\_to\_qa\_iam\_role\_arn](#output\_prod\_s3\_qa\_interfaces\_replicate\_to\_qa\_iam\_role\_arn) | prod-qa to QA |
| <a name="output_prod_s3_qa_interfaces_replicate_to_qa_source_caller_id"></a> [prod\_s3\_qa\_interfaces\_replicate\_to\_qa\_source\_caller\_id](#output\_prod\_s3\_qa\_interfaces\_replicate\_to\_qa\_source\_caller\_id) | n/a |
| <a name="output_prod_s3_qa_interfaces_replicate_to_qa_target_caller_id"></a> [prod\_s3\_qa\_interfaces\_replicate\_to\_qa\_target\_caller\_id](#output\_prod\_s3\_qa\_interfaces\_replicate\_to\_qa\_target\_caller\_id) | n/a |
| <a name="output_prod_s3_uat_interfaces_replicate_to_uat_iam_role_arn"></a> [prod\_s3\_uat\_interfaces\_replicate\_to\_uat\_iam\_role\_arn](#output\_prod\_s3\_uat\_interfaces\_replicate\_to\_uat\_iam\_role\_arn) | prod-uat to uat |
| <a name="output_prod_s3_uat_interfaces_replicate_to_uat_source_caller_id"></a> [prod\_s3\_uat\_interfaces\_replicate\_to\_uat\_source\_caller\_id](#output\_prod\_s3\_uat\_interfaces\_replicate\_to\_uat\_source\_caller\_id) | n/a |
| <a name="output_prod_s3_uat_interfaces_replicate_to_uat_target_caller_id"></a> [prod\_s3\_uat\_interfaces\_replicate\_to\_uat\_target\_caller\_id](#output\_prod\_s3\_uat\_interfaces\_replicate\_to\_uat\_target\_caller\_id) | n/a |
| <a name="output_qa_replicate_to_prod_s3_qa_interfaces_iam_role_arn"></a> [qa\_replicate\_to\_prod\_s3\_qa\_interfaces\_iam\_role\_arn](#output\_qa\_replicate\_to\_prod\_s3\_qa\_interfaces\_iam\_role\_arn) | QA to prod-qa |
| <a name="output_qa_replicate_to_prod_s3_qa_interfaces_source_caller_id"></a> [qa\_replicate\_to\_prod\_s3\_qa\_interfaces\_source\_caller\_id](#output\_qa\_replicate\_to\_prod\_s3\_qa\_interfaces\_source\_caller\_id) | n/a |
| <a name="output_qa_replicate_to_prod_s3_qa_interfaces_target_caller_id"></a> [qa\_replicate\_to\_prod\_s3\_qa\_interfaces\_target\_caller\_id](#output\_qa\_replicate\_to\_prod\_s3\_qa\_interfaces\_target\_caller\_id) | n/a |
| <a name="output_rd_replicate_to_prod_s3_dev_interfaces_iam_role_arn"></a> [rd\_replicate\_to\_prod\_s3\_dev\_interfaces\_iam\_role\_arn](#output\_rd\_replicate\_to\_prod\_s3\_dev\_interfaces\_iam\_role\_arn) | RD to prod-dev |
| <a name="output_rd_replicate_to_prod_s3_dev_interfaces_source_caller_id"></a> [rd\_replicate\_to\_prod\_s3\_dev\_interfaces\_source\_caller\_id](#output\_rd\_replicate\_to\_prod\_s3\_dev\_interfaces\_source\_caller\_id) | n/a |
| <a name="output_rd_replicate_to_prod_s3_dev_interfaces_target_caller_id"></a> [rd\_replicate\_to\_prod\_s3\_dev\_interfaces\_target\_caller\_id](#output\_rd\_replicate\_to\_prod\_s3\_dev\_interfaces\_target\_caller\_id) | n/a |
| <a name="output_uat_replicate_to_prod_s3_uat_interfaces_iam_role_arn"></a> [uat\_replicate\_to\_prod\_s3\_uat\_interfaces\_iam\_role\_arn](#output\_uat\_replicate\_to\_prod\_s3\_uat\_interfaces\_iam\_role\_arn) | uat to prod-uat |
| <a name="output_uat_replicate_to_prod_s3_uat_interfaces_source_caller_id"></a> [uat\_replicate\_to\_prod\_s3\_uat\_interfaces\_source\_caller\_id](#output\_uat\_replicate\_to\_prod\_s3\_uat\_interfaces\_source\_caller\_id) | n/a |
| <a name="output_uat_replicate_to_prod_s3_uat_interfaces_target_caller_id"></a> [uat\_replicate\_to\_prod\_s3\_uat\_interfaces\_target\_caller\_id](#output\_uat\_replicate\_to\_prod\_s3\_uat\_interfaces\_target\_caller\_id) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
