# formio

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_docdb"></a> [docdb](#module\_docdb) | git@github.com:sandatech/terraform-aws-module-documentdb-01.git | v0.0.4 |
| <a name="module_s3_bucket"></a> [s3\_bucket](#module\_s3\_bucket) | git@github.com:sandatech/terraform-aws-s3-bucket.git | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_iam_access_key.formio](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_access_key) | resource |
| [aws_iam_user.formiouser](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_user) | resource |
| [aws_iam_user_policy.lb_ro](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_user_policy) | resource |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_allowed_cidr_blocks"></a> [allowed\_cidr\_blocks](#input\_allowed\_cidr\_blocks) | n/a | `map` | <pre>{<br>  "prod2-ue1": [<br>    "10.15.0.0/20"<br>  ],<br>  "qa-ue1": [<br>    "10.15.0.0/20"<br>  ],<br>  "rd-ue1": [<br>    "10.15.0.0/20"<br>  ],<br>  "sb-ue1": [<br>    "0.0.0.0/0"<br>  ],<br>  "uat-ue1": [<br>    "10.15.0.0/20"<br>  ]<br>}</pre> | no |
| <a name="input_aws_docdb_clustername"></a> [aws\_docdb\_clustername](#input\_aws\_docdb\_clustername) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "sd-prod2-us-east-1-docdb-formio-cluster",<br>  "qa-ue1": "sd-qa-us-east-1-docdb-formio-cluster",<br>  "rd-ue1": "sd-rd-us-east-1-docbd-formio-cluster",<br>  "uat-ue1": "sd-uat-us-east-1-docdb-formio-cluster"<br>}</pre> | no |
| <a name="input_aws_docdb_parameter_group_family"></a> [aws\_docdb\_parameter\_group\_family](#input\_aws\_docdb\_parameter\_group\_family) | parameter\_group for mongo version | `string` | `"docdb4.0"` | no |
| <a name="input_cluster_size"></a> [cluster\_size](#input\_cluster\_size) | n/a | `map(number)` | <pre>{<br>  "prod2-ue1": 1,<br>  "qa-ue1": 1,<br>  "rd-ue1": 1,<br>  "sb-ue1": 1,<br>  "uat-ue1": 1<br>}</pre> | no |
| <a name="input_docdb_ca_cert_identifier"></a> [docdb\_ca\_cert\_identifier](#input\_docdb\_ca\_cert\_identifier) | docdb ca cert identifier | `map(string)` | <pre>{<br>  "prod2-ue1": "rds-ca-2019",<br>  "qa-ue1": "rds-ca-2019",<br>  "rd-ue1": "rds-ca-2019",<br>  "uat-ue1": "rds-ca-2019"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_instance_class"></a> [instance\_class](#input\_instance\_class) | n/a | `map` | <pre>{<br>  "prod2-ue1": "db.t3.medium",<br>  "qa-ue1": "db.t3.medium",<br>  "rd-ue1": "db.t3.medium",<br>  "sb-ue1": "db.t3.medium",<br>  "uat-ue1": "db.t3.medium"<br>}</pre> | no |
| <a name="input_master_password"></a> [master\_password](#input\_master\_password) | n/a | `string` | `""` | no |
| <a name="input_master_username"></a> [master\_username](#input\_master\_username) | n/a | `map` | <pre>{<br>  "prod2-ue1": "formio",<br>  "qa-ue1": "formio",<br>  "rd-ue1": "formio",<br>  "sb-ue1": "formio",<br>  "uat-ue1": "formio"<br>}</pre> | no |
| <a name="input_name"></a> [name](#input\_name) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "sd-prod2-us-east-1-docdb-formio",<br>  "qa-ue1": "sd-qa-us-east-1-docdb-formio",<br>  "rd-ue1": "sd-rd-us-east-1-docbd-formio",<br>  "uat-ue1": "sd-uat-us-east-1-docdb-formio"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_security_group_ids"></a> [security\_group\_ids](#input\_security\_group\_ids) | n/a | `map(list(string))` | <pre>{<br>  "prod2-ue1": [],<br>  "qa-ue1": [],<br>  "rd-ue1": [],<br>  "uat-ue1": []<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_aws_docdb_cluster_endpoint"></a> [aws\_docdb\_cluster\_endpoint](#output\_aws\_docdb\_cluster\_endpoint) | aws\_docdb\_cluster\_endpoint |
| <a name="output_aws_docdb_cluster_identifier"></a> [aws\_docdb\_cluster\_identifier](#output\_aws\_docdb\_cluster\_identifier) | aws docdb cluster identifier |
| <a name="output_aws_docdb_cluster_port"></a> [aws\_docdb\_cluster\_port](#output\_aws\_docdb\_cluster\_port) | aws\_docdb\_cluster\_port |
| <a name="output_s3_access_user_key"></a> [s3\_access\_user\_key](#output\_s3\_access\_user\_key) | n/a |
| <a name="output_s3_access_user_secret"></a> [s3\_access\_user\_secret](#output\_s3\_access\_user\_secret) | secret |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
