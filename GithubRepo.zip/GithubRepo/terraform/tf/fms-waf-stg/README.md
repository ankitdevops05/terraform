# fms-waf-stg

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_waf"></a> [waf](#module\_waf) | git::git@github.com:sandatech/terraform-aws-module-waf2-01.git | v0.0.19 |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_capacity"></a> [capacity](#input\_capacity) | n/a | `number` | `1500` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_ip_sets"></a> [ip\_sets](#input\_ip\_sets) | URL Match sets to be added to waf2 | `map` | <pre>{<br>  "STG_EmployeesHomeIPSet": {<br>    "addresses": [<br>      "104.58.196.23/32",<br>      "173.52.37.189/32",<br>      "108.6.8.102/32",<br>      "123.201.65.207/32",<br>      "69.119.68.3/32",<br>      "24.9.107.201/32",<br>      "24.146.154.112/32",<br>      "189.203.174.55/32",<br>      "38.145.165.23/32",<br>      "47.18.146.111/32",<br>      "68.237.35.181/32",<br>      "74.132.8.247/32",<br>      "49.204.190.42/32",<br>      "27.78.39.111/32"<br>    ],<br>    "priority": 22<br>  },<br>  "STG_ExternalSystemInteg": {<br>    "addresses": [],<br>    "priority": 24<br>  },<br>  "STG_KmsIPSet": {<br>    "addresses": [],<br>    "priority": 27<br>  },<br>  "STG_LoopbackIPSet": {<br>    "addresses": [<br>      "127.0.0.1/32"<br>    ],<br>    "priority": 21<br>  },<br>  "STG_OfficeAndVpnIPSet": {<br>    "addresses": [<br>      "207.140.140.193/32",<br>      "172.18.24.0/22",<br>      "10.15.0.0/20",<br>      "172.18.20.0/22",<br>      "3.215.4.75/32"<br>    ],<br>    "priority": 23<br>  },<br>  "STG_SoftrayIPSet": {<br>    "addresses": [],<br>    "priority": 25<br>  },<br>  "STG_VendorsIPSet": {<br>    "addresses": [<br>      "38.95.110.19/32"<br>    ],<br>    "priority": 20<br>  }<br>}</pre> | no |
| <a name="input_policy_name"></a> [policy\_name](#input\_policy\_name) | Rule group name | `string` | `"sd-admin-us-east-1-stg-fms-wafv2-policy-01"` | no |
| <a name="input_regex_sets"></a> [regex\_sets](#input\_regex\_sets) | Regex sets | `map` | `{}` | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_rule_group_name"></a> [rule\_group\_name](#input\_rule\_group\_name) | Rule group name | `string` | `"sd-admin-us-east-1-stg-rulegroup-01"` | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to add to all resources. | `map(string)` | <pre>{<br>  "Application": "WAFv2",<br>  "Backup": "",<br>  "Environment": "admin",<br>  "OS": "",<br>  "Owner": "Infrastructure",<br>  "Patch_Cycle": "",<br>  "Provisioned_by": "Terraform",<br>  "Purpose": "AWS FMS Policy and Rules",<br>  "Security": "",<br>  "Service": "WAFv2",<br>  "Version": "0.0.1",<br>  "project": "WAFv2"<br>}</pre> | no |
| <a name="input_url_match_and_header"></a> [url\_match\_and\_header](#input\_url\_match\_and\_header) | URL Match urls and headers to be added to waf2 | `list` | <pre>[<br>  {<br>    "headers": [<br>      {<br>        "key": "apiid",<br>        "token": "904b3047-e227-46a6-b10d-03701f9639fa"<br>      },<br>      {<br>        "key": "apikey",<br>        "token": "6cc1dba6-2d40-46d0-b1c8-644c48736802"<br>      }<br>    ],<br>    "name": "RD_IDD_YOSEMITE_URL_AND_HEADER",<br>    "priority": 70,<br>    "string": "api/databases"<br>  }<br>]</pre> | no |
| <a name="input_url_match_and_origin"></a> [url\_match\_and\_origin](#input\_url\_match\_and\_origin) | URL Match sets and origin to be added to waf2 | `list` | <pre>[<br>  {<br>    "name": "STG_YOSEMITE_FORMIO",<br>    "origin_urls": [<br>      "https://portal.form.io",<br>      "https://pro.formview.io"<br>    ],<br>    "priority": 67,<br>    "string": "api/databases"<br>  }<br>]</pre> | no |
| <a name="input_url_match_condition"></a> [url\_match\_condition](#input\_url\_match\_condition) | URL Match sets to be added to waf2 | `list` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_ipsets"></a> [ipsets](#output\_ipsets) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
