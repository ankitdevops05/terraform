# Need to setup the python package locally with the following command
# urllib3==1.26.1 is needed for working with the current version of boto3
pip3 install requests -t .

# There is a conflict with urllib3-2.0 which is in default setup of requests, so re-install the specific version 1.26
rm -rf ./urllib3
rm -rf ./urllib3-2.0.4.dist-info

pip3 install urllib3==1.26.1  -t .