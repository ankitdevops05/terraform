import requests
import boto3
import json
import os

from botocore.exceptions import ClientError
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

from datetime import datetime, timedelta


def lambda_handler(event, context):

    #Intialize the secret
    dashboard_guid = os.environ.get('DASHBOARD_GUID')
    recipients_csv = os.environ.get('RECIPIENTS_CSV')

    with open('/tmp/vault/secret.json') as f:
        secret = json.load(f)
    newrelic_key = secret['data']['NEWRELIC_API_KEY']

    #Prepare variables for call NewRelic API to generate PDF
    now = datetime.now()
    first_day_of_previous_month = datetime(now.year, now.month - 1, 1, 0, 1 ) + timedelta(hours=5)
    last_day_of_previous_month = datetime(now.year, now.month, 1, 0) - timedelta(minutes=1) + timedelta(hours=4)

    epoc_start = int(first_day_of_previous_month.timestamp())*1000
    epoc_end = int(last_day_of_previous_month.timestamp())*1000

    print(f"Epoc start: {epoc_start}")
    print(f"Epoc end: {epoc_end}")

    # Call API to handle PDF
    filename = generate_newrelic_report_file(dashboard_guid, newrelic_key, epoc_start, epoc_end)

    print("PDF file Location:" + filename);

    if now.day == 10:
        print(f"Day of the month is: {now.day}")
        recipients_csv += ",vto@sandata.com"

    print(f"Recipients: {recipients_csv}")

    if len(filename) > 0:
        send_email_with_attachment(filename, recipients_csv)
        print(f"Sent email to: {recipients_csv}");


def generate_newrelic_report_file(dashboard_guid, newrelic_key, epoc_start, epoc_end):
    # NerdGraph endpoint
    endpoint = "https://api.newrelic.com/graphql"
    query = f"""
        mutation {{
            dashboardCreateSnapshotUrl(
                guid: "{dashboard_guid}"
                params: {{timeWindow: {{beginTime: {epoc_start}, endTime: {epoc_end} }}}}
            )
        }}
    """
    headers = {'API-Key': f'{newrelic_key}'}
    response = requests.post(endpoint, headers=headers, json={"query": query})

    print(response.status_code)

    if response.status_code == 200:
        # convert a JSON into an equivalent python dictionary
        json_dictionary = json.loads(response.content)
        print(json_dictionary)

        # only interested with the dashboard url
        url_pdf = json_dictionary["data"]["dashboardCreateSnapshotUrl"]
        print(url_pdf)

        # rename the downloaded file, and save it in the working directory
        dashboard_response_pdf = requests.get(url_pdf, stream=True)
        filename = f'/tmp/sandata_monthly_performance_metrics.pdf'
        open(filename, 'wb').write(dashboard_response_pdf.content);

        return filename


def send_email_with_attachment(path_to_attached_file, recipients):
    # Replace sender@example.com with your "From" address.
    # This address must be verified with Amazon SES.
    SENDER = "noreply<no-reply@sandata.com>"

    # Replace recipient@example.com with a "To" address. If your account
    # is still in the sandbox, this address must be verified.
    # RECIPIENT = "vu.to@sandata.com"

    # Specify a configuration set. If you do not want to use a configuration
    # set, comment the following variable, and the
    # ConfigurationSetName=CONFIGURATION_SET argument below.
    # CONFIGURATION_SET = "ConfigSet"

    # If necessary, replace us-west-1 with the AWS Region you're using for Amazon SES.
    AWS_REGION = "us-east-1"

    # The subject line for the email.
    SUBJECT = "Sandata Monthly Performance Metrics Report"

    # The full path to the file that will be attached to the email.
    ATTACHMENT = path_to_attached_file

    # The email body for recipients with non-HTML email clients.
    BODY_TEXT = "Hi,\r\nPlease see the attached file for Sandata Monthly Performance Metrics."

    # The HTML body of the email.
    BODY_HTML = """\
    <html>
    <head></head>
    <body>
    <p>Please see the attached file for Sandata Monthly Performance Metrics.</p>
    </body>
    </html>
    """

    # The character encoding for the email.
    CHARSET = "utf-8"

    # Create a new SES resource and specify a region.
    client = boto3.client('ses', region_name=AWS_REGION)

    # Create a multipart/mixed parent container.
    msg = MIMEMultipart('mixed')
    # Add subject, from and to lines.
    msg['Subject'] = SUBJECT
    msg['From'] = SENDER
    msg['To'] = recipients

    # Create a multipart/alternative child container.
    msg_body = MIMEMultipart('alternative')

    # Encode the text and HTML content and set the character encoding. This step is
    # necessary if you're sending a message with characters outside the ASCII range.
    textpart = MIMEText(BODY_TEXT.encode(CHARSET), 'plain', CHARSET)
    htmlpart = MIMEText(BODY_HTML.encode(CHARSET), 'html', CHARSET)

    # Add the text and HTML parts to the child container.
    msg_body.attach(textpart)
    msg_body.attach(htmlpart)

    # Define the attachment part and encode it using MIMEApplication.
    att = MIMEApplication(open(ATTACHMENT, 'rb').read())

    # Add a header to tell the email client to treat this part as an attachment,
    # and to give the attachment a name.
    att.add_header('Content-Disposition', 'attachment', filename=os.path.basename(ATTACHMENT))

    # Attach the multipart/alternative child container to the multipart/mixed
    # parent container.
    msg.attach(msg_body)

    # Add the attachment to the parent container.
    msg.attach(att)
    # print(msg)

    try:
        # Provide the contents of the email.
        response = client.send_raw_email(
            Source=SENDER,
            Destinations=recipients.split(","),
            RawMessage={
                'Data': msg.as_string(),
            },
            # ConfigurationSetName=CONFIGURATION_SET
        )
    # Display an error if something goes wrong.
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(response['MessageId'])