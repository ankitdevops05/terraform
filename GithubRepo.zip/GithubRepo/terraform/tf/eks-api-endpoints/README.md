# eks-api-endpoints

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_template"></a> [template](#provider\_template) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_module-apigw-02"></a> [module-apigw-02](#module\_module-apigw-02) | app.terraform.io/sandata-tech/module-apigw-02/aws | 0.0.1 |

## Resources

| Name | Type |
|------|------|
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [template_file.domo_apis](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |
| [template_file.om_apis](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |
| [template_file.swagger_api](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_custom_domain_name"></a> [custom\_domain\_name](#input\_custom\_domain\_name) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "app.prod2.us-east-1.sandata.com",<br>  "qa-ue1": "app.qa.us-east-1.sandata.com",<br>  "rd-ue1": "app.rd.us-east-1.sandata.com",<br>  "rd-ue2": "app.rd.us-east-2.sandata.com",<br>  "uat-ue1": "uat-app.sandata.com"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_om_cognito"></a> [om\_cognito](#input\_om\_cognito) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": {<br>    "oauth2_url": "https://sd-prod2-us-east-1-ordermanager-api-user-pool.auth.us-east-1.amazoncognito.com/oauth2/token",<br>    "user_pool_arn": "arn:aws:cognito-idp:us-east-1:656560712260:userpool/us-east-1_MWObpSjtO"<br>  },<br>  "qa-ue1": {<br>    "oauth2_url": "https://sd-qa-us-east-1-ordermanager-api-user-pool.auth.us-east-1.amazoncognito.com/oauth2/token",<br>    "user_pool_arn": "arn:aws:cognito-idp:us-east-1:046839536952:userpool/us-east-1_p5EfuW8PQ"<br>  },<br>  "rd-ue1": {<br>    "oauth2_url": "https://sd-rd-us-east-1-ordermanager-api-user-pool.auth.us-east-1.amazoncognito.com/oauth2/token",<br>    "user_pool_arn": "arn:aws:cognito-idp:us-east-1:817297989338:userpool/us-east-1_KkBExzwsj"<br>  },<br>  "rd-ue2": {<br>    "oauth2_url": "https://sd-rd-us-east-1-ordermanager-api-user-pool.auth.us-east-1.amazoncognito.com/oauth2/token",<br>    "user_pool_arn": "arn:aws:cognito-idp:us-east-1:817297989338:userpool/us-east-1_KkBExzwsj"<br>  },<br>  "uat-ue1": {<br>    "oauth2_url": "https://sd-uat-us-east-1-ordermanager-api-user-pool.auth.us-east-1.amazoncognito.com/oauth2/token",<br>    "user_pool_arn": "arn:aws:cognito-idp:us-east-1:244940236506:userpool/us-east-1_F5rRupNhn"<br>  }<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_api_id"></a> [api\_id](#output\_api\_id) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
