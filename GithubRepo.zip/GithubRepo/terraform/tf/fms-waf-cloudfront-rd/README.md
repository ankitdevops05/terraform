# fms-waf-cloudfront-rd

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_waf"></a> [waf](#module\_waf) | git::git@github.com:sandatech/terraform-aws-module-waf2-01.git | v0.0.20 |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_ip_sets"></a> [ip\_sets](#input\_ip\_sets) | URL Match sets to be added to waf2 | `map` | `{}` | no |
| <a name="input_policy_name"></a> [policy\_name](#input\_policy\_name) | Rule group name | `string` | `"sd-admin-ue1-rd-fms-wafv2-cloudfront-policy-01"` | no |
| <a name="input_regex_sets"></a> [regex\_sets](#input\_regex\_sets) | Regex sets | `map` | `{}` | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_rule_group_name"></a> [rule\_group\_name](#input\_rule\_group\_name) | Rule group name | `string` | `"sd-admin-ue1-rd-cloudfront-rulegroup-01"` | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to add to all resources. | `map(string)` | <pre>{<br>  "Application": "WAFv2",<br>  "Backup": "",<br>  "Environment": "admin",<br>  "OS": "",<br>  "Owner": "Infrastructure",<br>  "Patch_Cycle": "",<br>  "Provisioned_by": "Terraform",<br>  "Purpose": "AWS FMS Policy and Rules for Cloudfront",<br>  "Security": "",<br>  "Service": "WAFv2",<br>  "Version": "0.0.1",<br>  "project": "WAFv2"<br>}</pre> | no |
| <a name="input_url_match_and_header"></a> [url\_match\_and\_header](#input\_url\_match\_and\_header) | URL Match urls and headers to be added to waf2 | `list` | `[]` | no |
| <a name="input_url_match_and_origin"></a> [url\_match\_and\_origin](#input\_url\_match\_and\_origin) | URL Match sets and origin to be added to waf2 | `list` | `[]` | no |
| <a name="input_url_match_condition"></a> [url\_match\_condition](#input\_url\_match\_condition) | URL Match sets to be added to waf2 | `list` | <pre>[<br>  {<br>    "name": "CF_RD_REGION_URL",<br>    "priority": 10,<br>    "string": "us-east-1.sandata.com"<br>  }<br>]</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_ipsets"></a> [ipsets](#output\_ipsets) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
