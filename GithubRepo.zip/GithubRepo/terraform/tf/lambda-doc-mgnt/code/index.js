// This is a dummy code that shows a way to access secret with Vault layer as needed

/**
var AWS = require('aws-sdk');
const fs = require('fs');

exports.handler = async function(event, context, callback) {

  const fileSecret = fs.readFileSync('/tmp/vault/secret.json', 'utf8');


  if(fileSecret){
    const jsonSecret = JSON.parse(fileSecret);

    //THIS IS FOR TESTING, DO NOT PRINT OUT SENSITIVE DATA from VAULT SECRET IN ANY ACTUAL CODE
    console.log("Secret info: ",  jsonSecret.data);
  }


  return { "success": true};
};
*/