# lambda-example-vault-integration:

Please following the steps to allow AWS-lambda-role to access Vault to get the secret info

1) Need to setup Vault CLI (https://developer.hashicorp.com/vault/docs/commands) and export those environment values in Terminal.
Change the variables according to your Lambda function name and role

```bash

export LAMBDA_NAME=lambda-example-vault-integration
export LAMBDA_ROLE_ARN=arn:aws:iam::817297989338:role/lambda-example-vault-integration-lambda-role
export VAULT_ADDR=https://vault.rd.us-east-1.sandata.com
export VAULT_TOKEN=***

```

2) Create a new Vault access policy for the lambda function after you have Vault CLI setup and export the VAULT_ADDR, VAULT_TOKEN in step 1.  In this case, the vault policy is the same lambda name

```bash

cat << EOF | vault policy write "${LAMBDA_NAME}" -
path "app-kv/lambda/${LAMBDA_NAME}" {
  capabilities = ["read", "list"]
}
EOF

```

3) Binding the AWS IAM role of lambda function to Vault policy, so the lambda can access Vault through the AWS IAM role

```bash

vault write "auth/aws/role/${LAMBDA_NAME}" \
    auth_type=iam \
    bound_iam_principal_arn="${LAMBDA_ROLE_ARN}" \
    policies="${LAMBDA_NAME}" \
    ttl=5m

```

