#!/bin/bash

eval "$(jq -r '@sh "export TOKEN=\(.token_var) TAG=\(.tag_var)"')"
if [[ -z "${TOKEN}" ]]; then export TOKEN=none; fi
if [[ -z "${TAG}" ]]; then export TAG=none; fi
# if [[ -z "${RUNS}" ]]; then export RUNS=none; fi

# RUN=$(jq -Rsc 'split("\n")[:-1] | map(select(length>0 | sed 's/\r$//'))' <<< $RUNS)
WS=$(echo $TAG | sed 's/,//')


##Get Runs
RESULTS=$(curl \
--header "Authorization: Bearer $TOKEN" \
--header "Content-Type: application/vnd.api+json" \
"https://app.terraform.io/api/v2/workspaces/$WS/runs?filter%5Bstatus%5D=pending%2Cplan_queued" | jq 'setpath(["0","a"]; 1)' | jq -r '.data | map([.id, .type, .attributes.status] | join(", ")) | join("\n")' | awk '{print $1}' | sed 's/,//')

OUT=$(echo $RESULTS | jq -R 'split(" ")')

#Create a JSON object and pass it back
jq -n --arg ws "$WS" \
      --arg out "$OUT" \
      '{"ws":$ws, "out":$out}'