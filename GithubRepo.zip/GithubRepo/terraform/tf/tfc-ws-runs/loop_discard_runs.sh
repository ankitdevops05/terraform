#!/bin/bash

eval "$(jq -r '@sh "export TOKEN=\(.token_var) RUNS=\(.run_var)"')"
if [[ -z "${TOKEN}" ]]; then export TOKEN=none; fi
if [[ -z "${RUNS}" ]]; then export RUNS=none; fi

RUN=$(echo $RUNS)

RESULTS=$(curl \
   --header "Authorization: Bearer $TOKEN" \
   --header "Content-Type: application/vnd.api+json" \
   --request POST\
   https://app.terraform.io/api/v2/runs/$RUN/actions/cancel)


Create a JSON object and pass it back
jq -n --arg run "$RUN" \
      --arg results "$RESULTS" \
      '{"run":$run, "results":$results}'
