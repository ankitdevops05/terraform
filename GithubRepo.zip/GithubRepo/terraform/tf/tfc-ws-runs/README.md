# tfc-configuration

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_external"></a> [external](#provider\_external) | n/a |
| <a name="provider_tfe"></a> [tfe](#provider\_tfe) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [external_external.all_organization_runs](https://registry.terraform.io/providers/hashicorp/external/latest/docs/data-sources/external) | data source |
| [external_external.cancel_pending_runs](https://registry.terraform.io/providers/hashicorp/external/latest/docs/data-sources/external) | data source |
| [tfe_workspace_ids.all](https://registry.terraform.io/providers/hashicorp/tfe/latest/docs/data-sources/workspace_ids) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_token"></a> [token](#input\_token) | Token for the Terraform Cloud Sandata organization. | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_all_organization_runs"></a> [all\_organization\_runs](#output\_all\_organization\_runs) | n/a |
| <a name="output_cancel_pending_runs"></a> [cancel\_pending\_runs](#output\_cancel\_pending\_runs) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
