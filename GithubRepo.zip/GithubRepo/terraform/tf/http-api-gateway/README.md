# http-api-gateway

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_template"></a> [template](#provider\_template) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_apigatewayv2_api.http_api](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/apigatewayv2_api) | resource |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [template_file.open_api](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |
| [terraform_remote_state.vpclink](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_eks_alb_listener_vault_arn"></a> [eks\_alb\_listener\_vault\_arn](#input\_eks\_alb\_listener\_vault\_arn) | ALB listener ARN point to EKS Fargate vault | `map(string)` | <pre>{<br>  "prod2-ue1": "arn:aws:elasticloadbalancing:us-east-1:656560712260:listener/app/cee2abf2-vault-vault-5586/c70abcf0a8e0f4e7/60356f845809420d",<br>  "prod2-ue2": "arn:aws:elasticloadbalancing:us-east-2:656560712260:listener/app/k8s-vault-vault-e9da8e86f3/927cb4407e34b395/0a00d5368221bf7d",<br>  "qa-ue1": "arn:aws:elasticloadbalancing:us-east-1:046839536952:listener/app/0483bc2e-vault-vault-5586/a156e4bb8e9f175a/5ace1e88ac0fc1be",<br>  "qa-ue2": "arn:aws:elasticloadbalancing:us-east-2:046839536952:listener/app/k8s-vault-vault-086f6a598c/18259119a24ce847/9138caf3d07de2b6",<br>  "rd-ue1": "arn:aws:elasticloadbalancing:us-east-1:817297989338:listener/app/7a9ea1a4-vault-vault-5586/08b20110800b2445/8022caa795ed9a6b",<br>  "rd-ue2": "arn:aws:elasticloadbalancing:us-east-2:817297989338:listener/app/k8s-vault-vault-7b4152a404/a34eb65438b538c7/2d93d454b7496b34",<br>  "uat-ue1": "arn:aws:elasticloadbalancing:us-east-1:244940236506:listener/app/a4c8b79c-vault-vault-5586/6fbf7014962524d0/d0669b63ead3ac2a",<br>  "uat-ue2": "arn:aws:elasticloadbalancing:us-east-2:244940236506:listener/app/k8s-vault-vault-fbcf3fac5e/3beb986599644d2f/386eac516b9e04c6"<br>}</pre> | no |
| <a name="input_eks_nlb_listener_ingress_arn"></a> [eks\_nlb\_listener\_ingress\_arn](#input\_eks\_nlb\_listener\_ingress\_arn) | Network Loadbalancer listener pointing to EKS | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "",<br>  "qa-ue1": "",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_api_endpoint"></a> [api\_endpoint](#output\_api\_endpoint) | n/a |
| <a name="output_id"></a> [id](#output\_id) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
