var AWS = require('aws-sdk');
var secretsManager = new AWS.SecretsManager({region: "us-east-1"});

const secret_name = "oracle-evv-v8-aggregator";

exports.handler = async function(event, context, callback) {
  var params = {
    SecretId: secret_name
  };

  try {
    const data = await secretsManager.getSecretValue(params).promise();
    const jsonSecret = JSON.parse(data.SecretString);

    console.log("Secret value: ",  jsonSecret.host);
  } catch (error) {
    console.log("Error retrieving secret: ", error);
  }

  return { "success": true};
};

