# lb-proxy-yosemite-gateway

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_module_lb_proxy_sg"></a> [module\_lb\_proxy\_sg](#module\_module\_lb\_proxy\_sg) | git@github.com:sandatech/terraform-aws-module-security-groups-01.git | v0.0.6 |

## Resources

| Name | Type |
|------|------|
| [aws_lb.lb_proxy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb) | resource |
| [aws_lb_listener.backend443](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_listener) | resource |
| [aws_lb_target_group.lb_tg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group) | resource |
| [aws_lb_target_group_attachment.attach_instances](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group_attachment) | resource |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [terraform_remote_state.aws_certs](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_lb_sg_ports_egress"></a> [lb\_sg\_ports\_egress](#input\_lb\_sg\_ports\_egress) | List of VPC security groups to associate | `list` | <pre>[<br>  {<br>    "cidr_blocks": [<br>      "0.0.0.0/0"<br>    ],<br>    "description": "Default Egress Rule",<br>    "from_port": [<br>      "0"<br>    ],<br>    "protocols": [<br>      "-1"<br>    ],<br>    "security_groups": [],<br>    "self": true,<br>    "to_port": [<br>      "0"<br>    ]<br>  }<br>]</pre> | no |
| <a name="input_map_migrated"></a> [map\_migrated](#input\_map\_migrated) | map-migrated = "mig34085" | `map(string)` | <pre>{<br>  "prod2-ue1": "mig34085",<br>  "prod2-ue2": "mig34085",<br>  "qa-ue1": "mig34085",<br>  "qa-ue2": "mig34085",<br>  "rd-ue1": "mig34085",<br>  "rd-ue2": "mig34085",<br>  "sb-ue1": "mig34085",<br>  "sb-ue2": "mig34085",<br>  "ss-ue1": "mig34085",<br>  "ss-ue2": "mig34085",<br>  "stg-ue1": "mig34085",<br>  "stg-ue2": "mig34085",<br>  "uat-ue1": "mig34085",<br>  "uat-ue2": "mig34085"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_yosemite_proxy_ips"></a> [yosemite\_proxy\_ips](#input\_yosemite\_proxy\_ips) | n/a | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "10.5.56.100"<br>  ],<br>  "qa-ue1": [<br>    ""<br>  ],<br>  "rd-ue1": [<br>    "10.5.20.70"<br>  ],<br>  "stg-ue1": [<br>    "10.5.20.61"<br>  ],<br>  "uat-ue1": [<br>    ""<br>  ]<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_alb_proxy_for_yosemite_dns_name"></a> [alb\_proxy\_for\_yosemite\_dns\_name](#output\_alb\_proxy\_for\_yosemite\_dns\_name) | n/a |
| <a name="output_alb_proxy_for_yosemite_name"></a> [alb\_proxy\_for\_yosemite\_name](#output\_alb\_proxy\_for\_yosemite\_name) | n/a |
| <a name="output_alb_proxy_for_yosemite_security_group_id"></a> [alb\_proxy\_for\_yosemite\_security\_group\_id](#output\_alb\_proxy\_for\_yosemite\_security\_group\_id) | n/a |
| <a name="output_lb_proxy_yosemite_arn"></a> [lb\_proxy\_yosemite\_arn](#output\_lb\_proxy\_yosemite\_arn) | n/a |
| <a name="output_yosemite_proxy_ips"></a> [yosemite\_proxy\_ips](#output\_yosemite\_proxy\_ips) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
