# s3-static-am
Setup S3 static site for SMC Manual in central approach.  It means that the site will be host in SharedService account for DEV/QA/UAT and then Prod for Production reference

- Setup S3 and cloudfront distribution
- Setup cloudfront function to apply security headers at response

```hcl
  //Apply security headers
  cf_viewer_response = {
    function_name = "am-viewer-response-apply-security-headers"
    function_name_description = "apply security headers for am.${var.environment[local.workspace]}.${var.region}.sandata.com"
    source_code_file = "${path.module}/code/viewer-response-with-security-headers.js"
  }

```<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_records"></a> [records](#module\_records) | git@github.com:sandatech/terraform-aws-route53.git//modules/records | n/a |
| <a name="module_s3_static_site"></a> [s3\_static\_site](#module\_s3\_static\_site) | git@github.com:sandatech/terraform-aws-module-s3-staticbucket-and-cloudfront.git | v0.0.7 |

## Resources

| Name | Type |
|------|------|
| [aws_route53_zone.selected](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_cf_aws_certificate_arn"></a> [cf\_aws\_certificate\_arn](#input\_cf\_aws\_certificate\_arn) | Use ss:  *.ss.us-east-1.sandata.com Use prod cert star.sandata.com which supports *.prod2.us-east-1.sandata.com  *.us-east-1.sandata.com, *.va.sandata.com, *.sandata.com | `map(string)` | <pre>{<br>  "prod2-ue1": "arn:aws:acm:us-east-1:656560712260:certificate/0cef30e4-53f3-4f25-9edc-01c1987154d9",<br>  "qa-ue1": "arn:aws:acm:us-east-1:046839536952:certificate/d4835813-c36b-4965-8ff8-0b85b77bcc00",<br>  "rd-ue1": "arn:aws:acm:us-east-1:817297989338:certificate/dec4654b-241d-4f37-a87f-1a792f427768",<br>  "uat-ue1": "arn:aws:acm:us-east-1:244940236506:certificate/73e02499-9ec6-4095-b5f0-06dfc148ce7c"<br>}</pre> | no |
| <a name="input_cf_public_domain_name"></a> [cf\_public\_domain\_name](#input\_cf\_public\_domain\_name) | n/a | `map(any)` | <pre>{<br>  "qa-ue1": [<br>    "portal-ui.qa.us-east-1.sandata.com"<br>  ],<br>  "rd-ue1": [<br>    "portal-ui.rd.us-east-1.sandata.com"<br>  ],<br>  "uat-ue1": [<br>    "portal-ui.uat.us-east-1.sandata.com"<br>  ]<br>}</pre> | no |
| <a name="input_envir_zone"></a> [envir\_zone](#input\_envir\_zone) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "prod2.us-east-1.sandata.com.",<br>  "qa-ue1": "qa.us-east-1.sandata.com.",<br>  "rd-ue1": "rd.us-east-1.sandata.com.",<br>  "uat-ue1": "uat.us-east-1.sandata.com."<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_header_referer"></a> [header\_referer](#input\_header\_referer) | n/a | `map` | <pre>{<br>  "prod2-ue1": "portaluiprod2",<br>  "qa-ue1": "portaluiqa",<br>  "rd-ue1": "portaluird",<br>  "uat-ue1": "portaluiuat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_s3_base_name"></a> [s3\_base\_name](#input\_s3\_base\_name) | n/a | `string` | `"portal-ui"` | no |
| <a name="input_s3_internal_domain_name"></a> [s3\_internal\_domain\_name](#input\_s3\_internal\_domain\_name) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "portal-ui.prod2.us-east-1.sandata.com",<br>  "qa-ue1": "portal-ui.qa.us-east-1.sandata.com",<br>  "rd-ue1": "portal-ui.rd.us-east-1.sandata.com",<br>  "uat-ue1": "portal-ui.uat.us-east-1.sandata.com"<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cloudfront_arn"></a> [cloudfront\_arn](#output\_cloudfront\_arn) | Cloudfront ARN including cloudfront distribution id |
| <a name="output_cloudfront_domain_name"></a> [cloudfront\_domain\_name](#output\_cloudfront\_domain\_name) | This is public cloudfront URL, so we can use to verify security headers for lower environments |
| <a name="output_s3_static_site_internal_url"></a> [s3\_static\_site\_internal\_url](#output\_s3\_static\_site\_internal\_url) | This is an internal URL, so we can verify the deployment to S3 |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
