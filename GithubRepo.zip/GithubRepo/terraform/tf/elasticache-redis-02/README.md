# elasticache-redis-02

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_redis"></a> [redis](#module\_redis) | git@github.com:sandatech/terraform-aws-module-elasticache-redis-01.git | v0.0.4 |

## Resources

| Name | Type |
|------|------|
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_alarm_actions"></a> [alarm\_actions](#input\_alarm\_actions) | Notifications Topic | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "arn:aws:sns:us-east-1:656560712260:redis-sns-01"<br>  ],<br>  "prod2-ue2": [<br>    "arn:aws:sns:us-east-2:656560712260:redis-sns-01"<br>  ],<br>  "qa-ue1": [<br>    "arn:aws:sns:us-east-1:046839536952:redis-sns-01"<br>  ],<br>  "qa-ue2": [<br>    "arn:aws:sns:us-east-2:046839536952:redis-sns-01"<br>  ],<br>  "rd-ue1": [<br>    "arn:aws:sns:us-east-1:817297989338:redis-sns-01"<br>  ],<br>  "rd-ue2": [<br>    "arn:aws:sns:us-east-2:817297989338:redis-sns-01"<br>  ],<br>  "uat-ue1": [<br>    "arn:aws:sns:us-east-1:244940236506:redis-sns-01"<br>  ],<br>  "uat-ue2": [<br>    "arn:aws:sns:us-east-2:244940236506:redis-sns-01"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cirds"></a> [allowed\_cirds](#input\_allowed\_cirds) | List of VPC security groups to associate | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "10.15.0.0/20",<br>    "172.24.0.0/20"<br>  ],<br>  "prod2-ue2": [<br>    "10.15.0.0/20",<br>    "172.24.0.0/20",<br>    "172.17.32.0/19"<br>  ],<br>  "qa-ue1": [<br>    "10.15.0.0/20",<br>    "172.31.0.0/20"<br>  ],<br>  "qa-ue2": [<br>    "10.15.0.0/20",<br>    "172.31.0.0/20",<br>    "172.17.64.0/19"<br>  ],<br>  "rd-ue1": [<br>    "10.15.0.0/20",<br>    "172.24.0.0/16"<br>  ],<br>  "rd-ue2": [<br>    "10.15.0.0/20",<br>    "172.24.0.0/16",<br>    "172.17.128.0/19"<br>  ],<br>  "uat-ue1": [<br>    "10.15.0.0/20"<br>  ],<br>  "uat-ue2": [<br>    "10.15.0.0/20",<br>    "172.17.224.0/19"<br>  ]<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | Instance Type | `map(string)` | <pre>{<br>  "prod2-ue1": "cache.m5.large",<br>  "prod2-ue2": "cache.m5.large",<br>  "qa-ue1": "cache.m5.large",<br>  "qa-ue2": "cache.t3.small",<br>  "rd-ue1": "cache.m5.large",<br>  "rd-ue2": "cache.t3.small",<br>  "uat-ue1": "cache.m5.large",<br>  "uat-ue2": "cache.t3.small"<br>}</pre> | no |
| <a name="input_multi_az"></a> [multi\_az](#input\_multi\_az) | Boolean to toggle Multi-AZ. | `map(bool)` | <pre>{<br>  "prod2-ue1": true,<br>  "prod2-ue2": true,<br>  "qa-ue1": true,<br>  "qa-ue2": true,<br>  "rd-ue1": true,<br>  "rd-ue2": true,<br>  "uat-ue1": true,<br>  "uat-ue2": true<br>}</pre> | no |
| <a name="input_notification_topic_arn"></a> [notification\_topic\_arn](#input\_notification\_topic\_arn) | Notifications Topic | `map(string)` | <pre>{<br>  "prod2-ue1": "arn:aws:sns:us-east-1:656560712260:redis-sns-01",<br>  "prod2-ue2": "arn:aws:sns:us-east-2:656560712260:redis-sns-01",<br>  "qa-ue1": "arn:aws:sns:us-east-1:046839536952:redis-sns-01",<br>  "qa-ue2": "arn:aws:sns:us-east-2:046839536952:redis-sns-01",<br>  "rd-ue1": "arn:aws:sns:us-east-1:817297989338:redis-sns-01",<br>  "rd-ue2": "arn:aws:sns:us-east-2:817297989338:redis-sns-01",<br>  "uat-ue1": "arn:aws:sns:us-east-1:244940236506:redis-sns-01",<br>  "uat-ue2": "arn:aws:sns:us-east-2:244940236506:redis-sns-01"<br>}</pre> | no |
| <a name="input_ok_actions"></a> [ok\_actions](#input\_ok\_actions) | Notifications Topic | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "arn:aws:sns:us-east-1:656560712260:redis-sns-01"<br>  ],<br>  "prod2-ue2": [<br>    "arn:aws:sns:us-east-2:656560712260:redis-sns-01"<br>  ],<br>  "qa-ue1": [<br>    "arn:aws:sns:us-east-1:046839536952:redis-sns-01"<br>  ],<br>  "qa-ue2": [<br>    "arn:aws:sns:us-east-2:046839536952:redis-sns-01"<br>  ],<br>  "rd-ue1": [<br>    "arn:aws:sns:us-east-1:817297989338:redis-sns-01"<br>  ],<br>  "rd-ue2": [<br>    "arn:aws:sns:us-east-2:817297989338:redis-sns-01"<br>  ],<br>  "uat-ue1": [<br>    "arn:aws:sns:us-east-1:244940236506:redis-sns-01"<br>  ],<br>  "uat-ue2": [<br>    "arn:aws:sns:us-east-2:244940236506:redis-sns-01"<br>  ]<br>}</pre> | no |
| <a name="input_password"></a> [password](#input\_password) | n/a | `any` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_endpoint"></a> [endpoint](#output\_endpoint) | n/a |
| <a name="output_id"></a> [id](#output\_id) | n/a |
| <a name="output_port"></a> [port](#output\_port) | n/a |
| <a name="output_security_group_id"></a> [security\_group\_id](#output\_security\_group\_id) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
