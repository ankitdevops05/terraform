# eks-apigw-deployment-release

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_api_gateway_deployment.release](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_deployment) | resource |
| [aws_api_gateway_method_settings.log_settings_release_stage](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_method_settings) | resource |
| [aws_api_gateway_stage.release](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_stage) | resource |
| [aws_cloudwatch_log_group.cloudwatch_api](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_log_group) | resource |
| [aws_api_gateway_rest_api.apigw](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/api_gateway_rest_api) | data source |
| [terraform_remote_state.vpclink](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_api_id"></a> [api\_id](#input\_api\_id) | Api Geteway ID | `map(string)` | <pre>{<br>  "prod2-ue1": "pivc7jzgld",<br>  "qa-ue1": "h45dda9z08",<br>  "rd-ue1": "glcky4unw1",<br>  "rd-ue2": "ffzdkofqil",<br>  "uat-ue1": "vxhryaaeu7"<br>}</pre> | no |
| <a name="input_apigw_settings"></a> [apigw\_settings](#input\_apigw\_settings) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": {<br>    "cloudwatch_retention_in_days": 60,<br>    "data_trace_enabled": true,<br>    "logging_level": "INFO",<br>    "metrics_enabled": true,<br>    "throttling_burst_limit": 5000,<br>    "throttling_rate_limit": 10000<br>  },<br>  "qa-ue1": {<br>    "cloudwatch_retention_in_days": 3,<br>    "data_trace_enabled": false,<br>    "logging_level": "INFO",<br>    "metrics_enabled": false,<br>    "throttling_burst_limit": -1,<br>    "throttling_rate_limit": -1<br>  },<br>  "rd-ue1": {<br>    "cloudwatch_retention_in_days": 3,<br>    "data_trace_enabled": false,<br>    "logging_level": "INFO",<br>    "metrics_enabled": false,<br>    "throttling_burst_limit": 5000,<br>    "throttling_rate_limit": 10000<br>  },<br>  "rd-ue2": {<br>    "cloudwatch_retention_in_days": 1,<br>    "data_trace_enabled": false,<br>    "logging_level": "INFO",<br>    "metrics_enabled": false,<br>    "throttling_burst_limit": 5000,<br>    "throttling_rate_limit": 10000<br>  },<br>  "uat-ue1": {<br>    "cloudwatch_retention_in_days": 30,<br>    "data_trace_enabled": true,<br>    "logging_level": "INFO",<br>    "metrics_enabled": true,<br>    "throttling_burst_limit": -1,<br>    "throttling_rate_limit": -1<br>  }<br>}</pre> | no |
| <a name="input_deployment_id"></a> [deployment\_id](#input\_deployment\_id) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "ibci1x",<br>  "qa-ue1": "cfgaus",<br>  "rd-ue1": "py5zos",<br>  "rd-ue2": "",<br>  "uat-ue1": "f7b013"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_nlb_url"></a> [nlb\_url](#input\_nlb\_url) | Network load balancer URL for EKS cluster | `map(string)` | <pre>{<br>  "prod2-ue1": "a1556094978e741f3bcd67b9a93e5f8a-687a7b4d742865c3.elb.us-east-1.amazonaws.com",<br>  "qa-ue1": "aa6d394d0e37344788e0a71b65528777-bec9d8280b681d67.elb.us-east-1.amazonaws.com",<br>  "rd-ue1": "a8d1145dcf76044999b419405feb4950-f7c4e1740649661d.elb.us-east-1.amazonaws.com",<br>  "rd-ue2": "internal.rd.us-east-2.sandata.com",<br>  "uat-ue1": "a416a67c0b2b04de2b9a9678a438b6d5-962432a9a7f1b29d.elb.us-east-1.amazonaws.com"<br>}</pre> | no |
| <a name="input_om_cognito_url"></a> [om\_cognito\_url](#input\_om\_cognito\_url) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "https://sd-prod2-us-east-1-api-user-pool.auth.us-east-1.amazoncognito.com/oauth2/token",<br>  "qa-ue1": "https://sd-qa-us-east-1-api-user-pool.auth.us-east-1.amazoncognito.com/oauth2/token",<br>  "rd-ue1": "https://sd-rd-us-east-1-api-user-pool.auth.us-east-1.amazoncognito.com/oauth2/token",<br>  "rd-ue2": "https://dummy-cognito.rd.us-east-2.sandata.com/oauth2/token",<br>  "uat-ue1": "https://sd-uat-us-east-1-api-user-pool.auth.us-east-1.amazoncognito.com/oauth2/token"<br>}</pre> | no |
| <a name="input_om_nlb_url"></a> [om\_nlb\_url](#input\_om\_nlb\_url) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "om-nlb.prod2.us-east-1.sandata.com",<br>  "qa-ue1": "om-nlb.qa.us-east-1.sandata.com",<br>  "rd-ue1": "om-nlb.rd.us-east-1.sandata.com",<br>  "rd-ue2": "om-nlb.rd.us-east-2.sandata.com",<br>  "uat-ue1": "om-nlb.uat.us-east-1.sandata.com"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_xray_enabled"></a> [xray\_enabled](#input\_xray\_enabled) | Enable xray tracing | `map` | <pre>{<br>  "prod2-ue1": true,<br>  "qa-ue1": false,<br>  "rd-ue1": false,<br>  "rd-ue2": false,<br>  "uat-ue1": true<br>}</pre> | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
