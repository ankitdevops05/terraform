/*
Can run this CLI to get list of IP from Health checkers

health_check_id=93a0ae10-3d3e-44fc-af71-5cfcf913e849
aws route53 get-health-check-status --health-check-id $health_check_id --profile tf_rd | jq '.HealthCheckObservations[] | .IPAddress' | jq -s | tr '\n' ' ' | sed 's/ //g'

  */

const ALLOWED_IPS = JSON.parse(process.env['ALLOWED_IPS']);
const IGNORE_ALLOWED_IPS = (process.env['IGNORE_ALLOWED_IPS'] === 'true');

exports.handler = async(event, context) => {
    console.log("ALLOWED_IPS", ALLOWED_IPS);
    console.log('Received event:', JSON.stringify(event, null, 2));

    let response = {
        "isAuthorized": false,
        "context": {
            "message": "Invalid Request"
        }
    };

    const sourceIP = event.requestContext.http.sourceIp;
    console.log("SourceIP:", sourceIP);
    console.log("IGNORE_ALLOWED_IPS:", IGNORE_ALLOWED_IPS);

    const match = IGNORE_ALLOWED_IPS || ALLOWED_IPS.find(element => {
      if (element.includes(sourceIP)) {
        return true;
      }
    });

    console.log("Match:", match);

    if (match) {
        response = {
            "isAuthorized": true,
            "context": {
                "message": "Valid Request"
            }
        };
    }

    return response;

};