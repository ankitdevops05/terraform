# lambda-authorizer-http-api-gateway
- Validate the request before it hits the backend services
<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_archive"></a> [archive](#provider\_archive) | n/a |
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_lambda-app"></a> [lambda-app](#module\_lambda-app) | git::git@github.com:sandatech/terraform-aws-module-lambda-generic.git | v0.0.1 |

## Resources

| Name | Type |
|------|------|
| [aws_iam_role_policy.lambda_kms_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy_attachment.lambda_basic_execution](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_lambda_permission.api_gateway_invoke_function](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission) | resource |
| [archive_file.lambda_zip](https://registry.terraform.io/providers/hashicorp/archive/latest/docs/data-sources/file) | data source |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_iam_policy_document.kms_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_env_vars_allowed_ips"></a> [env\_vars\_allowed\_ips](#input\_env\_vars\_allowed\_ips) | Allowed IPs to send to Lambda functions | `map(string)` | <pre>{<br>  "prod2-ue1": "[\"104.58.196.23\",\"54.241.32.112\",\"54.245.168.48\",\"54.244.52.208\",\"54.243.31.240\",\"107.23.255.16\"]",<br>  "prod2-ue2": "[\"104.58.196.23\",\"15.177.2.78\",\"15.177.22.76\",\"15.177.14.76\",\"15.177.18.76\",\"15.177.6.76\"]",<br>  "qa-ue1": "[\"104.58.196.23\",\"54.241.32.93\",\"15.177.2.0\",\"54.244.52.253\",\"54.245.168.29\",\"107.23.255.61\",\"54.183.255.189\"]",<br>  "qa-ue2": "[\"54.241.32.75\",\"54.244.52.235\",\"107.23.255.43\",\"54.183.255.171\",\"54.243.31.203\",\"54.245.168.11\"]",<br>  "rd-ue1": "[\"104.58.196.23\",\"54.243.31.229\",\"54.245.168.37\",\"54.241.32.101\",\"107.23.255.5\",\"54.244.52.197\",\"54.183.255.133\"]",<br>  "rd-ue2": "[\"15.177.22.113\",\"15.177.2.115\",\"15.177.10.113\",\"15.177.14.113\",\"15.177.6.113\",\"15.177.18.113\"]",<br>  "uat-ue1": "[\"104.58.196.23\",\"15.177.2.63\",\"15.177.22.61\",\"15.177.18.61\",\"15.177.10.61\",\"15.177.6.61\",\"15.177.14.61\"]",<br>  "uat-ue2": "[\"104.58.196.23\",\"54.245.168.48\",\"54.241.32.112\",\"54.244.52.208\",\"54.243.31.240\",\"107.23.255.16\",\"54.183.255.144\"]"<br>}</pre> | no |
| <a name="input_env_vars_ignore_allowed_ips"></a> [env\_vars\_ignore\_allowed\_ips](#input\_env\_vars\_ignore\_allowed\_ips) | Allowed IPs to send to Lambda functions | `map(string)` | <pre>{<br>  "prod2-ue1": "false",<br>  "prod2-ue2": "false",<br>  "qa-ue1": "false",<br>  "qa-ue2": "false",<br>  "rd-ue1": "false",<br>  "rd-ue2": "false",<br>  "uat-ue1": "false",<br>  "uat-ue2": "false"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_lambda_function_name"></a> [lambda\_function\_name](#input\_lambda\_function\_name) | n/a | `string` | `"lambda-authorizer-http-api-gateway"` | no |
| <a name="input_lambda_source_code_hash"></a> [lambda\_source\_code\_hash](#input\_lambda\_source\_code\_hash) | If the hash is the the same there is no update to source code package when Terraform code is applied | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "qa-ue1": "",<br>  "rd-ue1": "",<br>  "uat-ue1": ""<br>}</pre> | no |
| <a name="input_nodejs_runtime_version"></a> [nodejs\_runtime\_version](#input\_nodejs\_runtime\_version) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "nodejs16.x",<br>  "prod2-ue2": "nodejs16.x",<br>  "qa-ue1": "nodejs16.x",<br>  "qa-ue2": "nodejs16.x",<br>  "rd-ue1": "nodejs16.x",<br>  "rd-ue2": "nodejs16.x",<br>  "uat-ue1": "nodejs16.x",<br>  "uat-ue2": "nodejs16.x"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
