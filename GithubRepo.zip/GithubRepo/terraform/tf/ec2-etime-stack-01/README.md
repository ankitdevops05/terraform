# amp-web-01

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ec201"></a> [ec201](#module\_ec201) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.7 |
| <a name="module_ec202"></a> [ec202](#module\_ec202) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.7 |
| <a name="module_ec203"></a> [ec203](#module\_ec203) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.7 |
| <a name="module_module-fs-sg"></a> [module-fs-sg](#module\_module-fs-sg) | git::git@github.com:sandatech/terraform-aws-module-security-groups-01.git | v0.0.6 |
| <a name="module_module-sftp-sg"></a> [module-sftp-sg](#module\_module-sftp-sg) | git::git@github.com:sandatech/terraform-aws-module-security-groups-01.git | v0.0.6 |

## Resources

| Name | Type |
|------|------|
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `string` | `""` | no |
| <a name="input_associate_public_ip"></a> [associate\_public\_ip](#input\_associate\_public\_ip) | n/a | `bool` | `false` | no |
| <a name="input_env_hostname"></a> [env\_hostname](#input\_env\_hostname) | n/a | `map` | <pre>{<br>  "qa-ue1": "rd",<br>  "rd-ue1": "rd"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_fs_ami"></a> [fs\_ami](#input\_fs\_ami) | Instance count | `map(string)` | <pre>{<br>  "qa-ue1": "ami-01da06843eba4a2e2",<br>  "rd-ue1": "ami-01331b027e7cb096d"<br>}</pre> | no |
| <a name="input_fs_ebs_block_device"></a> [fs\_ebs\_block\_device](#input\_fs\_ebs\_block\_device) | n/a | `map` | <pre>{<br>  "qa-ue1": [],<br>  "rd-ue1": []<br>}</pre> | no |
| <a name="input_fs_instance_type"></a> [fs\_instance\_type](#input\_fs\_instance\_type) | n/a | `map(string)` | <pre>{<br>  "qa-ue1": "m5.large",<br>  "rd-ue1": "m5.large"<br>}</pre> | no |
| <a name="input_fs_root_block_device"></a> [fs\_root\_block\_device](#input\_fs\_root\_block\_device) | Configuration for root block device | `map` | <pre>{<br>  "qa-ue1": [<br>    {<br>      "delete_on_termination": true,<br>      "encrypted": true,<br>      "volume_size": 100,<br>      "volume_type": "gp3"<br>    }<br>  ],<br>  "rd-ue1": [<br>    {<br>      "delete_on_termination": true,<br>      "encrypted": true,<br>      "volume_size": 100,<br>      "volume_type": "gp3"<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_fs_sg_name"></a> [fs\_sg\_name](#input\_fs\_sg\_name) | n/a | `string` | `"sam-fs-01-sg"` | no |
| <a name="input_iam_instance_profile"></a> [iam\_instance\_profile](#input\_iam\_instance\_profile) | n/a | `string` | `"EC2-Domain-Join"` | no |
| <a name="input_instance_count"></a> [instance\_count](#input\_instance\_count) | Instance count | `map(string)` | <pre>{<br>  "qa-ue1": "1",<br>  "rd-ue1": "1"<br>}</pre> | no |
| <a name="input_monitoring"></a> [monitoring](#input\_monitoring) | n/a | `bool` | `true` | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `string` | `""` | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `string` | `""` | no |
| <a name="input_sftp01_ami"></a> [sftp01\_ami](#input\_sftp01\_ami) | Instance count | `map(string)` | <pre>{<br>  "qa-ue1": "ami-0affefc43a46d3687",<br>  "rd-ue1": "ami-01331b027e7cb096d"<br>}</pre> | no |
| <a name="input_sftp01_server_secondary_ips"></a> [sftp01\_server\_secondary\_ips](#input\_sftp01\_server\_secondary\_ips) | n/a | `map` | <pre>{<br>  "qa-ue1": [<br>    "172.16.68.110",<br>    "172.16.68.220"<br>  ],<br>  "rd-ue1": [<br>    "172.16.132.110",<br>    "172.16.132.210"<br>  ]<br>}</pre> | no |
| <a name="input_sftp02_ami"></a> [sftp02\_ami](#input\_sftp02\_ami) | Instance count | `map(string)` | <pre>{<br>  "qa-ue1": "ami-01072d9d3828554bf",<br>  "rd-ue1": "ami-0bce4985d40f6eaf5"<br>}</pre> | no |
| <a name="input_sftp02_server_secondary_ips"></a> [sftp02\_server\_secondary\_ips](#input\_sftp02\_server\_secondary\_ips) | n/a | `map` | <pre>{<br>  "qa-ue1": [<br>    "172.16.76.110",<br>    "172.16.76.111"<br>  ],<br>  "rd-ue1": [<br>    "172.16.133.110",<br>    "172.16.133.211"<br>  ]<br>}</pre> | no |
| <a name="input_sftp_ebs_block_device"></a> [sftp\_ebs\_block\_device](#input\_sftp\_ebs\_block\_device) | n/a | `map` | <pre>{<br>  "qa-ue1": [<br>    {<br>      "delete_on_termination": true,<br>      "device_name": "/dev/sdb",<br>      "encrypted": true,<br>      "volume_size": 100,<br>      "volume_type": "gp3"<br>    }<br>  ],<br>  "rd-ue1": [<br>    {<br>      "delete_on_termination": true,<br>      "device_name": "/dev/sdb",<br>      "encrypted": true,<br>      "volume_size": 100,<br>      "volume_type": "gp3"<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_sftp_instance_type"></a> [sftp\_instance\_type](#input\_sftp\_instance\_type) | n/a | `map(string)` | <pre>{<br>  "qa-ue1": "m5.large",<br>  "rd-ue1": "m5.large"<br>}</pre> | no |
| <a name="input_sftp_root_block_device"></a> [sftp\_root\_block\_device](#input\_sftp\_root\_block\_device) | Configuration for root block device | `map` | <pre>{<br>  "qa-ue1": [<br>    {<br>      "delete_on_termination": true,<br>      "encrypted": true,<br>      "volume_size": 150,<br>      "volume_type": "gp3"<br>    }<br>  ],<br>  "rd-ue1": [<br>    {<br>      "delete_on_termination": true,<br>      "encrypted": true,<br>      "volume_size": 150,<br>      "volume_type": "gp3"<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_sftp_sg_name"></a> [sftp\_sg\_name](#input\_sftp\_sg\_name) | n/a | `string` | `"sam-sftp-01-sg"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id_01"></a> [id\_01](#output\_id\_01) | List of IDs of instances |
| <a name="output_id_02"></a> [id\_02](#output\_id\_02) | List of IDs of instances |
| <a name="output_id_03"></a> [id\_03](#output\_id\_03) | List of IDs of instances |
| <a name="output_instances_private_ips_01"></a> [instances\_private\_ips\_01](#output\_instances\_private\_ips\_01) | Private IPs assigned to the EC2 instance |
| <a name="output_instances_private_ips_02"></a> [instances\_private\_ips\_02](#output\_instances\_private\_ips\_02) | Private IPs assigned to the EC2 instance |
| <a name="output_instances_private_ips_03"></a> [instances\_private\_ips\_03](#output\_instances\_private\_ips\_03) | Private IPs assigned to the EC2 instance |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
