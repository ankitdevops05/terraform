# amp-dlm

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_amp-dlm"></a> [amp-dlm](#module\_amp-dlm) | git::git@github.com:sandatech/terraform-aws-module-dlm.git | v0.0.1 |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_name"></a> [name](#input\_name) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "AMP",<br>  "qa-ue1": "AMP",<br>  "rd-ue1": "AMP",<br>  "uat-ue1": "AMP"<br>}</pre> | no |
| <a name="input_number_of_snapshots_retained"></a> [number\_of\_snapshots\_retained](#input\_number\_of\_snapshots\_retained) | n/a | `map(number)` | <pre>{<br>  "prod2-ue1": 7,<br>  "qa-ue1": 7,<br>  "rd-ue1": 7,<br>  "uat-ue1": 7<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_schedule_name"></a> [schedule\_name](#input\_schedule\_name) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "AMP backup schedule",<br>  "qa-ue1": "AMP backup schedule",<br>  "rd-ue1": "AMP backup schedule",<br>  "uat-ue1": "AMP backup schedule"<br>}</pre> | no |
| <a name="input_schedule_times"></a> [schedule\_times](#input\_schedule\_times) | n/a | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "08:00"<br>  ],<br>  "qa-ue1": [<br>    "08:00"<br>  ],<br>  "rd-ue1": [<br>    "08:00"<br>  ],<br>  "uat-ue1": [<br>    "08:00"<br>  ]<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_tags_to_snapshot"></a> [tags\_to\_snapshot](#input\_tags\_to\_snapshot) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": {<br>    "Application": "AMP"<br>  },<br>  "qa-ue1": {<br>    "Application": "AMP"<br>  },<br>  "rd-ue1": {<br>    "Application": "AMP"<br>  },<br>  "uat-ue1": {<br>    "Application": "AMP"<br>  }<br>}</pre> | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
