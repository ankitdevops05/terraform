# amp-db-04

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ec2-db01"></a> [ec2-db01](#module\_ec2-db01) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.5 |

## Resources

| Name | Type |
|------|------|
| [aws_security_group.amp-db-servers-sg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group_rule.WinRm-rule-1-db-Allow-Bamboo-Servers](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.WinRm-rule-1-db-Allow-SS-App-Subnet](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.db-amp-Allows-Bamboo-Servers](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.db-amp-Allows-pw-ssrs-server](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.db-amp-Application-Subnets](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.db-amp-NY5SSRS-Server](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.db-amp-all](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.db-amp-all1](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.db-amp-jenkins-node](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.db-amp-sandata-internal-ip](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.db-amp2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.http-rule-db](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.rdp-rule-db](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.smb-rule-db](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.winRM-rule-db-Allows-Bamboo-Servers](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.winRM-rule-db-Allows-SS-App-Subnet](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_ami.windows_2016_base](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ami) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_allowed_cidrs_1433_group_1"></a> [allowed\_cidrs\_1433\_group\_1](#input\_allowed\_cidrs\_1433\_group\_1) | List of VPC security groups to associate to Allow Bamboo Servers | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "172.16.198.25/32",<br>    "172.16.197.243/32"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs_1433_group_2"></a> [allowed\_cidrs\_1433\_group\_2](#input\_allowed\_cidrs\_1433\_group\_2) | List of VPC security groups to associate for Sandata internal IP | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "208.64.40.0/22",<br>    "172.19.0.0/19",<br>    "172.18.20.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs_1433_group_3"></a> [allowed\_cidrs\_1433\_group\_3](#input\_allowed\_cidrs\_1433\_group\_3) | List of VPC security groups to associate for all jenkins node | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "172.31.2.95/32",<br>    "172.31.2.96/32",<br>    "172.31.2.98/32",<br>    "172.31.2.99/32"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs_1433_group_4"></a> [allowed\_cidrs\_1433\_group\_4](#input\_allowed\_cidrs\_1433\_group\_4) | List of VPC security groups to associate for all Application Subnets | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "172.16.132.0/22",<br>    "172.16.148.0/22",<br>    "172.16.140.0/22"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs_1433_group_5"></a> [allowed\_cidrs\_1433\_group\_5](#input\_allowed\_cidrs\_1433\_group\_5) | List of VPC security groups to associate for all NY5 SSRS Server | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "10.12.128.101/32",<br>    "10.12.128.102/32",<br>    "10.12.128.100/32"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs_1433_group_6"></a> [allowed\_cidrs\_1433\_group\_6](#input\_allowed\_cidrs\_1433\_group\_6) | List of VPC security groups to associate to Allows pw ssrs server | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "192.168.62.102/32",<br>    "192.168.62.101/32"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs_3389"></a> [allowed\_cidrs\_3389](#input\_allowed\_cidrs\_3389) | List of VPC security groups to associate to alllow sandata internal ip | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "172.18.20.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20",<br>    "208.64.40.0/22",<br>    "172.19.0.0/19"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs_4445"></a> [allowed\_cidrs\_4445](#input\_allowed\_cidrs\_4445) | List of VPC security groups to associate to allow Sandata internal ips | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "172.19.0.0/19",<br>    "208.64.40.0/22",<br>    "172.18.20.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs_445"></a> [allowed\_cidrs\_445](#input\_allowed\_cidrs\_445) | List of VPC security groups to associate to allow Sandata internal ips | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "172.18.20.0/22",<br>    "208.64.40.0/22",<br>    "172.19.0.0/19",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs_5985_group_1"></a> [allowed\_cidrs\_5985\_group\_1](#input\_allowed\_cidrs\_5985\_group\_1) | List of VPC security groups to associate Allows Bamboo Servers | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "172.16.198.25/32",<br>    "172.16.197.243/32"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs_5985_group_2"></a> [allowed\_cidrs\_5985\_group\_2](#input\_allowed\_cidrs\_5985\_group\_2) | List of VPC security groups to associate Allows SS App Subnet | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "172.16.204.0/22",<br>    "172.16.212.0/22"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs_5986_group_1"></a> [allowed\_cidrs\_5986\_group\_1](#input\_allowed\_cidrs\_5986\_group\_1) | List of VPC security groups to associate to Allow Bamboo Servers | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "172.16.197.243/32"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs_5986_group_2"></a> [allowed\_cidrs\_5986\_group\_2](#input\_allowed\_cidrs\_5986\_group\_2) | List of VPC security groups to associate to Allows SS App Subnet | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "172.16.204.0/22",<br>    "172.16.196.0/22",<br>    "172.16.212.0/22"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_cidrs_80"></a> [allowed\_cidrs\_80](#input\_allowed\_cidrs\_80) | List of VPC security groups to associate | `map(list(string))` | <pre>{<br>  "rd-ue1": [<br>    "172.16.132.0/22",<br>    "172.16.140.0/22",<br>    "172.16.148.0/22"<br>  ]<br>}</pre> | no |
| <a name="input_db04_chard"></a> [db04\_chard](#input\_db04\_chard) | db04 chard | `map(string)` | <pre>{<br>  "rd-ue1": ""<br>}</pre> | no |
| <a name="input_db04_instance_count"></a> [db04\_instance\_count](#input\_db04\_instance\_count) | db04 instance count | `map(number)` | <pre>{<br>  "rd-ue1": 1<br>}</pre> | no |
| <a name="input_db04_instance_type"></a> [db04\_instance\_type](#input\_db04\_instance\_type) | db04 instance type | `map(string)` | <pre>{<br>  "rd-ue1": "m5.xlarge"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_instances_private_ips_db01"></a> [instances\_private\_ips\_db01](#output\_instances\_private\_ips\_db01) | Private IPs assigned to the EC2 instance |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
