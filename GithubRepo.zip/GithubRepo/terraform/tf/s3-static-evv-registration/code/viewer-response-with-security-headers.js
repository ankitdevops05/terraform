function handler(event) {
  var response = event.response;
  var headers = response.headers;

  // Set HTTP security headers
  // Since JavaScript doesn't allow for hyphens in variable names, we use the dict["key"] notation
  headers["strict-transport-security"] = {
    value: "max-age=63072000; includeSubdomains; preload",
  };
  headers["content-security-policy"] = {
    value:
      "default-src 'self' *.sandata.com https://www.google.com/recaptcha/; img-src 'self' https://*.sandata.com/; script-src 'self' 'unsafe-eval' 'unsafe-inline' https://www.google.com/recaptcha/ https://www.gstatic.com/recaptcha/; style-src 'self' 'unsafe-inline' fonts.googleapis.com maxcdn.bootstrapcdn.com; font-src 'self' fonts.googleapis.com fonts.gstatic.com;connect-src 'self' http://*.sandata.com/;object-src 'none'",
  };
  headers["x-content-type-options"] = { value: "nosniff" };
  headers["x-frame-options"] = { value: "DENY" };
  headers["x-xss-protection"] = { value: "1; mode=block" };
  headers["referrer-policy"] = { value: "same-origin" };
  //A new settings for feature-policy
  headers["permissions-policy"] = {
    value:
      "accelerometer 'none'; camera 'none'; geolocation 'none'; gyroscope 'none'; magnetometer 'none'; microphone 'none'; payment 'none'; usb 'none'",
  };

  headers["access-control-allow-origin"] = { value: "https://*.sandata.com" };
  headers["access-control-allow-methods"] = { value: "GET, HEAD" };
  headers["access-control-max-age"] = { value: "86400" };

  // Return the response to viewers
  return response;
}
