# eks-netapp-spot-01

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ocean-aws-k8s"></a> [ocean-aws-k8s](#module\_ocean-aws-k8s) | git::https://github.com/spotinst/terraform-spotinst-ocean-aws-k8s.git | 8997fcc26119da424abda4df1daef5394dbd1a16 |
| <a name="module_ocean-controller"></a> [ocean-controller](#module\_ocean-controller) | spotinst/ocean-controller/spotinst | 0.41.0 |

## Resources

| Name | Type |
|------|------|
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_eks_cluster.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/eks_cluster) | data source |
| [aws_eks_cluster_auth.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/eks_cluster_auth) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [terraform_remote_state.eks-cluster](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | EKS cluster and Ocean cluster name | `map` | <pre>{<br>  "rd-ue1": "sd-rd-us-east-1-eks-01"<br>}</pre> | no |
| <a name="input_cluster_version"></a> [cluster\_version](#input\_cluster\_version) | Kubernetes version | `string` | `"1.22"` | no |
| <a name="input_eksAutoscalerpolicy_name"></a> [eksAutoscalerpolicy\_name](#input\_eksAutoscalerpolicy\_name) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "AmazonEKSClusterAutoscalerPolicy",<br>  "prod2-ue2": "AmazonEKSClusterAutoscalerPolicy-prod2-ue2",<br>  "qa-ue1": "AmazonEKSClusterAutoscalerPolicy",<br>  "qa-ue2": "AmazonEKSClusterAutoscalerPolicy-qa-ue2",<br>  "rd-ue1": "AmazonEKSClusterAutoscalerPolicy",<br>  "rd-ue2": "AmazonEKSClusterAutoscalerPolicy-rd-ue2",<br>  "sb-ue1": "AmazonEKSClusterAutoscalerPolicy",<br>  "ss-ue1": "AmazonEKSClusterAutoscalerPolicy",<br>  "uat-ue1": "AmazonEKSClusterAutoscalerPolicy",<br>  "uat-ue2": "AmazonEKSClusterAutoscalerPolicy-uat-ue2"<br>}</pre> | no |
| <a name="input_eks_ami"></a> [eks\_ami](#input\_eks\_ami) | eks 1.22: ami-03a30cc1dda93f173 on 01/2023 | `map(string)` | <pre>{<br>  "prod2-ue1": "ami-0878b75b482934e1f",<br>  "prod2-ue2": "ami-07b7136d362146ad8",<br>  "qa-ue1": "ami-0878b75b482934e1f",<br>  "qa-ue2": "ami-07b7136d362146ad8",<br>  "rd-ue1": "ami-03a30cc1dda93f173",<br>  "rd-ue2": "ami-07b7136d362146ad8",<br>  "sb-ue1": "ami-03c45fa21d6d9e641",<br>  "ss-ue1": "ami-0878b75b482934e1f",<br>  "uat-ue1": "ami-0878b75b482934e1f",<br>  "uat-ue2": "ami-07b7136d362146ad8"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_private_subnets"></a> [private\_subnets](#input\_private\_subnets) | AWS private subnet IDs | `map` | <pre>{<br>  "rd-ue1": [<br>    "subnet-0a5dcbb302f5e60bb",<br>    "subnet-07f687619a5c10008",<br>    "subnet-0cc79b9e76a788c2a"<br>  ],<br>  "sb-ue1": [<br>    "subnet-0b4b73b0b702c695d",<br>    "subnet-0ab2e6b9abf558fa4",<br>    "subnet-02279b1091a27ffa3"<br>  ]<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_spotinst_account"></a> [spotinst\_account](#input\_spotinst\_account) | Spot account id | `map` | <pre>{<br>  "rd-ue1": "act-b8ee85b8"<br>}</pre> | no |
| <a name="input_spotinst_token"></a> [spotinst\_token](#input\_spotinst\_token) | Spot token | `string` | `""` | no |
| <a name="input_target_group"></a> [target\_group](#input\_target\_group) | # Load Balancers ## | `map` | <pre>{<br>  "rd-ue1": "arn:aws:elasticloadbalancing:us-east-1:817297989338:targetgroup/k8s-ingressn-ingressn-3346777256/eae817002dd24303"<br>}</pre> | no |
| <a name="input_worker_instance_profile_arn"></a> [worker\_instance\_profile\_arn](#input\_worker\_instance\_profile\_arn) | n/a | `map` | <pre>{<br>  "rd-ue1": "arn:aws:iam::817297989338:instance-profile/sd-rd-us-east-1-ec2-profile-01"<br>}</pre> | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
