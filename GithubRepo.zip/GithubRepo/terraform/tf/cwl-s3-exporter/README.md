# cwl-s3-exporter

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_module-cwl-s3-exporter-01"></a> [module-cwl-s3-exporter-01](#module\_module-cwl-s3-exporter-01) | git@github.com:sandatech/terraform-aws-module-cwl-s3-exporter-01.git | v0.0.6 |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_create_bucket"></a> [create\_bucket](#input\_create\_bucket) | Boolean to create an s3 bucket. | `map` | <pre>{<br>  "admin-ue1": true,<br>  "prod-ue1": false,<br>  "prod2-ue1": false,<br>  "qa-ue1": false,<br>  "qa2-ue1": false,<br>  "rd-ue1": false,<br>  "sb-ue1": false,<br>  "ss-ue1": false,<br>  "stg-ue1": false,<br>  "uat-ue1": false<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_filters"></a> [filters](#input\_filters) | Filters for the Cloudwatch event rules. The number drives the minute in which to kick off the cron schedule. | `map` | <pre>{<br>  "admin-ue1": {<br>    "directoryservice": "4",<br>    "flow": "2",<br>    "lambda": "0",<br>    "multi": "6"<br>  },<br>  "prod-ue1": {<br>    "aws": "15",<br>    "flow": "17",<br>    "vault": "19"<br>  },<br>  "prod2-ue1": {<br>    "aws": "15",<br>    "flow": "17",<br>    "vault": "19"<br>  },<br>  "qa-ue1": {<br>    "aws": "10",<br>    "flow": "12",<br>    "vault": "14"<br>  },<br>  "qa2-ue1": {<br>    "aws": "10",<br>    "flow": "12",<br>    "vault": "14"<br>  },<br>  "rd-ue1": {<br>    "aws": "0",<br>    "flow": "2",<br>    "vault": "4"<br>  },<br>  "sb-ue1": {<br>    "aws": "20",<br>    "flow": "22",<br>    "vault": "24"<br>  },<br>  "ss-ue1": {<br>    "aws": "20",<br>    "flow": "22",<br>    "vault": "24"<br>  },<br>  "stg-ue1": {<br>    "aws": "12",<br>    "flow": "14",<br>    "vault": "16"<br>  },<br>  "uat-ue1": {<br>    "aws": "15",<br>    "flow": "17",<br>    "vault": "19"<br>  }<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_retention_in_days"></a> [retention\_in\_days](#input\_retention\_in\_days) | n/a | `map(string)` | <pre>{<br>  "admin-ue1": "1",<br>  "prod-ue1": "60",<br>  "prod2-ue1": "60",<br>  "qa-ue1": "14",<br>  "qa2-ue1": "14",<br>  "rd-ue1": "14",<br>  "sb-ue1": "14",<br>  "ss-ue1": "14",<br>  "stg-ue1": "60",<br>  "uat-ue1": "60"<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
