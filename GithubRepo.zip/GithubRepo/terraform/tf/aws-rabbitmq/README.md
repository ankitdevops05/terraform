# aws-rabbitmq

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_aws_rabbitmq_sg"></a> [aws\_rabbitmq\_sg](#module\_aws\_rabbitmq\_sg) | git::git@github.com:sandatech/terraform-aws-module-security-groups-01.git | v0.0.6 |

## Resources

| Name | Type |
|------|------|
| [aws_mq_broker.rabbitmq](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/mq_broker) | resource |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_engine_version"></a> [engine\_version](#input\_engine\_version) | AWS Managed-RabbitMQ engine\_version | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "3.9.13",<br>  "qa-ue1": "",<br>  "qa-ue2": "3.9.13",<br>  "rd-ue1": "3.9.13",<br>  "rd-ue2": "3.9.13",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_host_instance_type"></a> [host\_instance\_type](#input\_host\_instance\_type) | AWS Managed-RabbitMQ host instance type | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "mq.m5.large",<br>  "qa-ue1": "",<br>  "qa-ue2": "mq.m5.large",<br>  "rd-ue1": "mq.m5.large",<br>  "rd-ue2": "mq.m5.large",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_rabbitmq_name"></a> [rabbitmq\_name](#input\_rabbitmq\_name) | n/a | `string` | `"aws-rabbitmq-01"` | no |
| <a name="input_rabbitmq_password"></a> [rabbitmq\_password](#input\_rabbitmq\_password) | AWS Managed-RabbitMQ password to login into cluster | `any` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_sg_ports_egress"></a> [sg\_ports\_egress](#input\_sg\_ports\_egress) | n/a | `list` | <pre>[<br>  {<br>    "cidr_blocks": [<br>      "0.0.0.0/0"<br>    ],<br>    "description": "Default Egress Rule",<br>    "from_port": [<br>      "0"<br>    ],<br>    "protocols": [<br>      "-1"<br>    ],<br>    "security_groups": [],<br>    "self": false,<br>    "to_port": [<br>      "0"<br>    ]<br>  }<br>]</pre> | no |
| <a name="input_sg_ports_ingress"></a> [sg\_ports\_ingress](#input\_sg\_ports\_ingress) | n/a | `map` | <pre>{<br>  "prod2-ue2": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.17.32.0/19",<br>        "172.16.32.0/19"<br>      ],<br>      "description": "Allowed access from Sandata network",<br>      "from_port": [<br>        "5671"<br>      ],<br>      "protocols": [<br>        "TCP"<br>      ],<br>      "security_groups": [],<br>      "self": false,<br>      "to_port": [<br>        "5671"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.17.32.0/19",<br>        "172.16.32.0/19"<br>      ],<br>      "description": "Allowed access from Sandata network",<br>      "from_port": [<br>        "443"<br>      ],<br>      "protocols": [<br>        "TCP"<br>      ],<br>      "security_groups": [],<br>      "self": false,<br>      "to_port": [<br>        "443"<br>      ]<br>    }<br>  ],<br>  "qa-ue2": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.17.64.0/19",<br>        "172.16.64.0/19"<br>      ],<br>      "description": "Allowed access from Sandata network",<br>      "from_port": [<br>        "5671"<br>      ],<br>      "protocols": [<br>        "TCP"<br>      ],<br>      "security_groups": [],<br>      "self": false,<br>      "to_port": [<br>        "5671"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.17.64.0/19",<br>        "172.16.64.0/19"<br>      ],<br>      "description": "Allowed access from Sandata network",<br>      "from_port": [<br>        "443"<br>      ],<br>      "protocols": [<br>        "TCP"<br>      ],<br>      "security_groups": [],<br>      "self": false,<br>      "to_port": [<br>        "443"<br>      ]<br>    }<br>  ],<br>  "rd-ue2": [<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.17.128.0/19",<br>        "172.16.128.0/19"<br>      ],<br>      "description": "Allowed access from Sandata network",<br>      "from_port": [<br>        "5671"<br>      ],<br>      "protocols": [<br>        "TCP"<br>      ],<br>      "security_groups": [],<br>      "self": false,<br>      "to_port": [<br>        "5671"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.18.20.0/22",<br>        "172.18.24.0/22",<br>        "10.15.0.0/20",<br>        "172.17.128.0/19",<br>        "172.16.128.0/19"<br>      ],<br>      "description": "Allowed access from Sandata network",<br>      "from_port": [<br>        "443"<br>      ],<br>      "protocols": [<br>        "TCP"<br>      ],<br>      "security_groups": [],<br>      "self": false,<br>      "to_port": [<br>        "443"<br>      ]<br>    }<br>  ]<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_aws_mq_broker_arn"></a> [aws\_mq\_broker\_arn](#output\_aws\_mq\_broker\_arn) | n/a |
| <a name="output_aws_mq_broker_instances"></a> [aws\_mq\_broker\_instances](#output\_aws\_mq\_broker\_instances) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
