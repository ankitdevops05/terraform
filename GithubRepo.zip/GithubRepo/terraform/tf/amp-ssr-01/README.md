# amp-ssr-01

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ec2"></a> [ec2](#module\_ec2) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.5 |
| <a name="module_ec2-ssr02"></a> [ec2-ssr02](#module\_ec2-ssr02) | git@github.com:sandatech/terraform-aws-module-ec2-instance-01.git | v0.0.5 |

## Resources

| Name | Type |
|------|------|
| [aws_security_group.amp-ssr-servers-sg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group_rule.amp-445](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.amp-ssr-servers-sg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.nginx-amp](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.nginx-amp-443](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.nginx-amp-80](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.nginx-amp-81](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.rdp-rule](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_allowed_cidrs"></a> [allowed\_cidrs](#input\_allowed\_cidrs) | List of VPC security groups to associate | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "10.15.0.0/20",<br>    "172.16.132.161/32"<br>  ],<br>  "qa-ue1": [<br>    "10.15.0.0/20",<br>    "172.16.132.161/32"<br>  ],<br>  "qa-ue2": [<br>    "10.15.0.0/20",<br>    "172.16.132.161/32"<br>  ],<br>  "rd-ue1": [<br>    "172.18.20.0/22",<br>    "172.18.24.0/24",<br>    "10.15.0.0/20",<br>    "192.168.134.0/23",<br>    "172.16.192.0/19",<br>    "10.14.8.0/22"<br>  ],<br>  "rd-ue2": [<br>    "10.15.0.0/20",<br>    "172.16.132.161/32"<br>  ],<br>  "uat-ue1": [<br>    "10.15.0.0/20",<br>    "172.16.132.161/32"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_ssr_cidrs"></a> [allowed\_ssr\_cidrs](#input\_allowed\_ssr\_cidrs) | List of VPC security groups to associate | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "172.16.192.0/19"<br>  ],<br>  "qa-ue1": [<br>    "172.16.192.0/19"<br>  ],<br>  "rd-ue1": [<br>    "172.16.192.0/19"<br>  ],<br>  "rd-ue2": [<br>    "172.16.192.0/19"<br>  ],<br>  "uat-ue1": [<br>    "172.16.192.0/19"<br>  ]<br>}</pre> | no |
| <a name="input_allowed_winrm_cidrs"></a> [allowed\_winrm\_cidrs](#input\_allowed\_winrm\_cidrs) | List of VPC security groups to associate | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "172.16.192.0/19"<br>  ],<br>  "qa-ue1": [<br>    "172.16.192.0/19"<br>  ],<br>  "rd-ue1": [<br>    "172.16.192.0/19"<br>  ],<br>  "rd-ue2": [<br>    "172.16.192.0/19"<br>  ],<br>  "uat-ue1": [<br>    "172.16.192.0/19"<br>  ]<br>}</pre> | no |
| <a name="input_create_ssr_02"></a> [create\_ssr\_02](#input\_create\_ssr\_02) | n/a | `map(bool)` | <pre>{<br>  "prod2-ue1": true,<br>  "qa-ue1": false,<br>  "rd-ue1": false,<br>  "rd-ue2": false,<br>  "uat-ue1": false<br>}</pre> | no |
| <a name="input_ebs_optimized_ss01"></a> [ebs\_optimized\_ss01](#input\_ebs\_optimized\_ss01) | n/a | `map(bool)` | <pre>{<br>  "prod2-ue1": true,<br>  "qa-ue1": false,<br>  "rd-ue1": false,<br>  "rd-ue2": false,<br>  "uat-ue1": false<br>}</pre> | no |
| <a name="input_env_hostname"></a> [env\_hostname](#input\_env\_hostname) | n/a | `map` | <pre>{<br>  "prod2-ue1": "prod2",<br>  "qa-ue1": "qa",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "poc",<br>  "uat-ue1": "uat"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_instances_number"></a> [instances\_number](#input\_instances\_number) | n/a | `map(number)` | <pre>{<br>  "prod2-ue1": 1,<br>  "qa-ue1": 1,<br>  "rd-ue1": 1,<br>  "rd-ue2": 1,<br>  "uat-ue1": 1<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_ssr02_instance_type"></a> [ssr02\_instance\_type](#input\_ssr02\_instance\_type) | ssr instance type | `map(string)` | <pre>{<br>  "prod2-ue1": "c5.2xlarge",<br>  "qa-ue1": "",<br>  "rd-ue1": "",<br>  "uat-ue1": ""<br>}</pre> | no |
| <a name="input_ssr_ami"></a> [ssr\_ami](#input\_ssr\_ami) | ssr name | `map(string)` | <pre>{<br>  "prod2-ue1": "ami-076f1954a2bb091a4",<br>  "qa-ue1": "ami-0c9ed30458cc009e1",<br>  "rd-ue1": "ami-080ae7ba4aab9a462",<br>  "rd-ue2": "ami-09ea242dd90946980",<br>  "uat-ue1": "ami-0f97607bff5ce6161"<br>}</pre> | no |
| <a name="input_ssr_ami_02"></a> [ssr\_ami\_02](#input\_ssr\_ami\_02) | ssr name | `map(string)` | <pre>{<br>  "prod2-ue1": "ami-016e5415a2d9eaf4e",<br>  "qa-ue1": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "uat-ue1": ""<br>}</pre> | no |
| <a name="input_ssr_instance_type"></a> [ssr\_instance\_type](#input\_ssr\_instance\_type) | ssr instance type | `map(string)` | <pre>{<br>  "prod2-ue1": "c5.xlarge",<br>  "qa-ue1": "t3.medium",<br>  "rd-ue1": "t3.medium",<br>  "rd-ue2": "t3.medium",<br>  "uat-ue1": "t3.medium"<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_instances_private_ips"></a> [instances\_private\_ips](#output\_instances\_private\_ips) | Private IPs assigned to the EC2 instance |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
