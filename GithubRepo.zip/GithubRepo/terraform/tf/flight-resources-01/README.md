# flight-resources-01

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | = 4.67.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | = 4.67.0 |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_client"></a> [client](#module\_client) | git@github.com:sandatech/terraform-aws-module-flight-client-01.git | v0.0.4 |

## Resources

| Name | Type |
|------|------|
| [aws_security_group.flight_rds](https://registry.terraform.io/providers/hashicorp/aws/4.67.0/docs/resources/security_group) | resource |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_allocated_storage"></a> [allocated\_storage](#input\_allocated\_storage) | n/a | `map(number)` | <pre>{<br>  "prod2-ue1": 50,<br>  "qa-ue1": 50,<br>  "rd-ue1": 20,<br>  "uat-ue1": 50<br>}</pre> | no |
| <a name="input_allowed_cirds_1433"></a> [allowed\_cirds\_1433](#input\_allowed\_cirds\_1433) | List of VPC security groups to associate | `list(string)` | <pre>[<br>  "172.18.20.0/22",<br>  "172.18.24.0/22",<br>  "10.15.0.0/20"<br>]</pre> | no |
| <a name="input_client_db_instance_class"></a> [client\_db\_instance\_class](#input\_client\_db\_instance\_class) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "db.m5.xlarge",<br>  "qa-ue1": "db.t3.medium",<br>  "rd-ue1": "db.t3.medium",<br>  "uat-ue1": "db.t3.medium"<br>}</pre> | no |
| <a name="input_client_db_password"></a> [client\_db\_password](#input\_client\_db\_password) | n/a | `string` | `""` | no |
| <a name="input_client_db_username"></a> [client\_db\_username](#input\_client\_db\_username) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "postgres",<br>  "qa-ue1": "flight_dal",<br>  "rd-ue1": "postgres",<br>  "uat-ue1": "flight_dal"<br>}</pre> | no |
| <a name="input_db_restore_snapshot"></a> [db\_restore\_snapshot](#input\_db\_restore\_snapshot) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "arn:aws:rds:us-east-1:656560712260:snapshot:flight-snap-09-08-20",<br>  "qa-ue1": "arn:aws:rds:us-east-1:046839536952:snapshot:flight-qa-9-1-2020",<br>  "rd-ue1": "arn:aws:rds:us-east-1:817297989338:snapshot:flight-8-31-2020",<br>  "uat-ue1": "arn:aws:rds:us-east-1:244940236506:snapshot:flight-uat-client-09-01-20"<br>}</pre> | no |
| <a name="input_engine_version"></a> [engine\_version](#input\_engine\_version) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "11.12",<br>  "qa-ue1": "11.12",<br>  "rd-ue1": "11.12",<br>  "uat-ue1": "11.12"<br>}</pre> | no |
| <a name="input_env"></a> [env](#input\_env) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "prod2",<br>  "qa-ue1": "qa",<br>  "rd-ue1": "rd",<br>  "uat-ue1": "uat"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_final_snapshot_identifier"></a> [final\_snapshot\_identifier](#input\_final\_snapshot\_identifier) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "sd-prod2-us-east-1-rds-labs-client20200909000944",<br>  "qa-ue1": "sd-qa-us-east-1-rds-labs-client20200901192337",<br>  "rd-ue1": "sd-rd-us-east-1-rds-labs-client20200901011720",<br>  "uat-ue1": "sd-uat-us-east-1-rds-labs-client20200901200730"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_sqs_arn"></a> [sqs\_arn](#input\_sqs\_arn) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "arn:aws:sqs:us-east-1:656560712260:EMAIL_SERVICE",<br>  "qa-ue1": "arn:aws:sqs:us-east-1:046839536952:EMAIL_SERVICE",<br>  "rd-ue1": "arn:aws:sqs:us-east-1:817297989338:EMAIL_SERVICE",<br>  "uat-ue1": "arn:aws:sqs:us-east-1:244940236506:EMAIL_SERVICE"<br>}</pre> | no |
| <a name="input_vault-server"></a> [vault-server](#input\_vault-server) | n/a | `string` | `"vault.vault.svc.cluster.local"` | no |
| <a name="input_vault-token"></a> [vault-token](#input\_vault-token) | n/a | `string` | `""` | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
