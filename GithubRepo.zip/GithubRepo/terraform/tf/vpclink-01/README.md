# vpclink-01

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_api_gateway_vpc_link.api](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_vpc_link) | resource |
| [aws_api_gateway_vpc_link.map_api](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_vpc_link) | resource |
| [aws_api_gateway_vpc_link.om_api](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_vpc_link) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_cluster_ingress_nlb_arn"></a> [cluster\_ingress\_nlb\_arn](#input\_cluster\_ingress\_nlb\_arn) | Network Loadbalancer pointing to EKS | `map(string)` | <pre>{<br>  "prod2-ue1": "arn:aws:elasticloadbalancing:us-east-1:656560712260:loadbalancer/net/a1556094978e741f3bcd67b9a93e5f8a/687a7b4d742865c3",<br>  "prod2-ue2": "",<br>  "qa-ue1": "arn:aws:elasticloadbalancing:us-east-1:046839536952:loadbalancer/net/a3ab06d57cff9415bbdd77c43c15dbab/4464eb40941ff34e",<br>  "qa-ue2": "",<br>  "rd-ue1": "arn:aws:elasticloadbalancing:us-east-1:817297989338:loadbalancer/net/a8a7d2889f3994973a3ca8102041bbe0/0efa38742dc3f33e",<br>  "rd-ue2": "arn:aws:elasticloadbalancing:us-east-2:817297989338:loadbalancer/net/a456bc5a3cca64c7e84785febf1953de/cfc7e2248bdb86bb",<br>  "uat-ue1": "arn:aws:elasticloadbalancing:us-east-1:244940236506:loadbalancer/net/a52e3cd646819435aaf119c7de7aacac/8f90606a174e643c",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_map_ingress_nlb_arn"></a> [map\_ingress\_nlb\_arn](#input\_map\_ingress\_nlb\_arn) | Network Loadbalancer pointing to VisitCapture/MAP webservers | `map(string)` | <pre>{<br>  "prod2-ue1": "arn:aws:elasticloadbalancing:us-east-1:656560712260:loadbalancer/net/nlb-smc-lb-01/05f16119f824dc40",<br>  "prod2-ue2": "",<br>  "qa-ue1": "arn:aws:elasticloadbalancing:us-east-1:046839536952:loadbalancer/net/nlb-smc-lb-01/192e6195c39a78b8",<br>  "qa-ue2": "",<br>  "rd-ue1": "arn:aws:elasticloadbalancing:us-east-1:817297989338:loadbalancer/net/nlb-smc-lb-01/16f40655c7843c51",<br>  "rd-ue2": "arn:aws:elasticloadbalancing:us-east-2:817297989338:loadbalancer/net/nlb-smc-lb-01/e3b4c373e82b0082",<br>  "uat-ue1": "arn:aws:elasticloadbalancing:us-east-1:244940236506:loadbalancer/net/nlb-smc-lb-01/a7f1797cdf5615d9",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_om_ingress_nlb_arn"></a> [om\_ingress\_nlb\_arn](#input\_om\_ingress\_nlb\_arn) | Network Loadbalancer pointing to OrderManager webservers | `map(string)` | <pre>{<br>  "prod2-ue1": "arn:aws:elasticloadbalancing:us-east-1:656560712260:loadbalancer/net/nlb-om-lb-01/e395bb6cab38c2b3",<br>  "prod2-ue2": "",<br>  "qa-ue1": "arn:aws:elasticloadbalancing:us-east-1:046839536952:loadbalancer/net/nlb-om-lb-01/5df1c6546ccbb5f0",<br>  "qa-ue2": "",<br>  "rd-ue1": "arn:aws:elasticloadbalancing:us-east-1:817297989338:loadbalancer/net/nlb-om-lb-01/ea01f27135dada85",<br>  "rd-ue2": "",<br>  "uat-ue1": "arn:aws:elasticloadbalancing:us-east-1:244940236506:loadbalancer/net/nlb-om-lb-01/9585fe99c1f6d3ae",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_map_vpc_link_id"></a> [map\_vpc\_link\_id](#output\_map\_vpc\_link\_id) | n/a |
| <a name="output_om_vpc_link_id"></a> [om\_vpc\_link\_id](#output\_om\_vpc\_link\_id) | n/a |
| <a name="output_vpc_link_id"></a> [vpc\_link\_id](#output\_vpc\_link\_id) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
