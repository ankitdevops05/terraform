# eks-cluster-01

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0.6 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 4.67.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 4.67.0 |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_eks"></a> [eks](#module\_eks) | git::git@github.com:sandatech/terraform-aws-module-eks-01.git | v0.0.26 |

## Resources

| Name | Type |
|------|------|
| [aws_autoscaling_schedule.eks_cluster_down](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/autoscaling_schedule) | resource |
| [aws_autoscaling_schedule.eks_cluster_up](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/autoscaling_schedule) | resource |
| [aws_iam_policy.AmazonEKSClusterAutoscalerPolicy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_asg_name"></a> [asg\_name](#input\_asg\_name) | Name of the ASG. Only exists for legacy purposes, but leave blank if making a new one. | `map(string)` | <pre>{<br>  "prod2-ue1": "tf-asg-20201120174354044700000001",<br>  "prod2-ue2": "",<br>  "qa-ue1": "tf-asg-20201020152810539100000006",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "uat-ue1": "tf-asg-20201103152834286100000006",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_aws_eks_addon_version_most_recent"></a> [aws\_eks\_addon\_version\_most\_recent](#input\_aws\_eks\_addon\_version\_most\_recent) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": true,<br>  "prod2-ue2": true,<br>  "qa-ue1": true,<br>  "qa-ue2": true,<br>  "rd-ue1": true,<br>  "rd-ue2": true,<br>  "sb-ue1": false,<br>  "ss-ue1": true,<br>  "uat-ue1": true,<br>  "uat-ue2": false<br>}</pre> | no |
| <a name="input_aws_eks_addons_enable"></a> [aws\_eks\_addons\_enable](#input\_aws\_eks\_addons\_enable) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": true,<br>  "prod2-ue2": true,<br>  "qa-ue1": true,<br>  "qa-ue2": true,<br>  "rd-ue1": true,<br>  "rd-ue2": true,<br>  "sb-ue1": false,<br>  "ss-ue1": true,<br>  "uat-ue1": true,<br>  "uat-ue2": true<br>}</pre> | no |
| <a name="input_desired_capacity"></a> [desired\_capacity](#input\_desired\_capacity) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "19",<br>  "prod2-ue2": "1",<br>  "qa-ue1": "1",<br>  "qa-ue2": "3",<br>  "rd-ue1": "0",<br>  "rd-ue2": "2",<br>  "sb-ue1": "2",<br>  "ss-ue1": "2",<br>  "uat-ue1": "0",<br>  "uat-ue2": "2"<br>}</pre> | no |
| <a name="input_eksAutoscalerpolicy_name"></a> [eksAutoscalerpolicy\_name](#input\_eksAutoscalerpolicy\_name) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "AmazonEKSClusterAutoscalerPolicy",<br>  "prod2-ue2": "AmazonEKSClusterAutoscalerPolicy-prod2-ue2",<br>  "qa-ue1": "AmazonEKSClusterAutoscalerPolicy",<br>  "qa-ue2": "AmazonEKSClusterAutoscalerPolicy-qa-ue2",<br>  "rd-ue1": "AmazonEKSClusterAutoscalerPolicy",<br>  "rd-ue2": "AmazonEKSClusterAutoscalerPolicy-rd-ue2",<br>  "sb-ue1": "AmazonEKSClusterAutoscalerPolicy",<br>  "ss-ue1": "AmazonEKSClusterAutoscalerPolicy",<br>  "uat-ue1": "AmazonEKSClusterAutoscalerPolicy",<br>  "uat-ue2": "AmazonEKSClusterAutoscalerPolicy-uat-ue2"<br>}</pre> | no |
| <a name="input_eks_ami"></a> [eks\_ami](#input\_eks\_ami) | Check the latest image here: https://docs.aws.amazon.com/eks/latest/userguide/eks-optimized-ami.html eks 1.22: ami-03a30cc1dda93f173 on 01/2023 eks 1.23: ami-00b56546df5a8bc0e on 03-29-2023 eks 1.23: ami-098c939daa5e43f83 on 04-25-2023 eks 1.23: ami-02d001eb8650bb388 - ohio region eks 1.24: ami-06cc1a30a3bb015c2 - ohio region eks 1.24: ami-0520c6ee8495b7794 - va region (08/29/2023) eks 1.25: ami-08801ec7e481f738a - ohio region (11/17/2023) eks 1.25: ami-0f1b832b8b8057046 - va region (11/16/2023) | `map(string)` | <pre>{<br>  "prod2-ue1": "ami-0f1b832b8b8057046",<br>  "prod2-ue2": "ami-08801ec7e481f738a",<br>  "qa-ue1": "ami-0f1b832b8b8057046",<br>  "qa-ue2": "ami-08801ec7e481f738a",<br>  "rd-ue1": "ami-0f1b832b8b8057046",<br>  "rd-ue2": "ami-08801ec7e481f738a",<br>  "sb-ue1": "ami-03a30cc1dda93f173",<br>  "ss-ue1": "ami-0f1b832b8b8057046",<br>  "uat-ue1": "ami-0f1b832b8b8057046",<br>  "uat-ue2": "ami-none"<br>}</pre> | no |
| <a name="input_eks_encryption_enabled"></a> [eks\_encryption\_enabled](#input\_eks\_encryption\_enabled) | n/a | `map(bool)` | <pre>{<br>  "prod2-ue1": false,<br>  "prod2-ue2": true,<br>  "qa-ue1": false,<br>  "qa-ue2": true,<br>  "rd-ue1": false,<br>  "rd-ue2": true,<br>  "sb-ue1": true,<br>  "ss-ue1": false,<br>  "uat-ue1": false,<br>  "uat-ue2": true<br>}</pre> | no |
| <a name="input_eks_version"></a> [eks\_version](#input\_eks\_version) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "1.25",<br>  "prod2-ue2": "1.25",<br>  "qa-ue1": "1.25",<br>  "qa-ue2": "1.25",<br>  "rd-ue1": "1.25",<br>  "rd-ue2": "1.25",<br>  "sb-ue1": "1.22",<br>  "ss-ue1": "1.25",<br>  "uat-ue1": "1.25",<br>  "uat-ue2": "none"<br>}</pre> | no |
| <a name="input_enable_schedule_scaling"></a> [enable\_schedule\_scaling](#input\_enable\_schedule\_scaling) | n/a | `map(bool)` | <pre>{<br>  "prod2-ue1": false,<br>  "prod2-ue2": false,<br>  "qa-ue1": false,<br>  "qa-ue2": false,<br>  "rd-ue1": false,<br>  "rd-ue2": false,<br>  "sb-ue1": false,<br>  "ss-ue1": false,<br>  "uat-ue1": false,<br>  "uat-ue2": false<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_external_ip"></a> [external\_ip](#input\_external\_ip) | IP for AWS Security Group | `list(string)` | <pre>[<br>  "172.19.0.0/19",<br>  "192.168.138.0/24",<br>  "172.16.197.243/32",<br>  "172.16.198.25/32",<br>  "10.15.0.0/20",<br>  "10.14.8.0/22",<br>  "172.16.206.61/32"<br>]</pre> | no |
| <a name="input_identifier"></a> [identifier](#input\_identifier) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "01",<br>  "prod2-ue2": "01",<br>  "qa-ue1": "01",<br>  "qa-ue2": "01",<br>  "rd-ue1": "01",<br>  "rd-ue2": "01",<br>  "sb-ue1": "01",<br>  "ss-ue1": "01",<br>  "uat-ue1": "01",<br>  "uat-ue2": "01"<br>}</pre> | no |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "m5.2xlarge",<br>  "prod2-ue2": "m5.xlarge",<br>  "qa-ue1": "m5.xlarge",<br>  "qa-ue2": "m5.xlarge",<br>  "rd-ue1": "m5.2xlarge",<br>  "rd-ue2": "m5.xlarge",<br>  "sb-ue1": "m5.large",<br>  "ss-ue1": "m5.xlarge",<br>  "uat-ue1": "m5.xlarge",<br>  "uat-ue2": "m5.xlarge"<br>}</pre> | no |
| <a name="input_kubelet_extra_args"></a> [kubelet\_extra\_args](#input\_kubelet\_extra\_args) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "--max-pods=54",<br>  "prod2-ue2": "--max-pods=54",<br>  "qa-ue1": "--max-pods=54",<br>  "qa-ue2": "--max-pods=54",<br>  "rd-ue1": "--max-pods=54",<br>  "rd-ue2": "--max-pods=54",<br>  "sb-ue1": "--max-pods=54",<br>  "ss-ue1": "--max-pods=54",<br>  "uat-ue1": "--max-pods=54",<br>  "uat-ue2": "--max-pods=54"<br>}</pre> | no |
| <a name="input_launch_configuration_enabled"></a> [launch\_configuration\_enabled](#input\_launch\_configuration\_enabled) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": true,<br>  "prod2-ue2": true,<br>  "qa-ue1": true,<br>  "qa-ue2": true,<br>  "rd-ue1": true,<br>  "rd-ue2": false,<br>  "sb-ue1": true,<br>  "ss-ue1": true,<br>  "uat-ue1": true,<br>  "uat-ue2": true<br>}</pre> | no |
| <a name="input_launch_template_enabled"></a> [launch\_template\_enabled](#input\_launch\_template\_enabled) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": true,<br>  "prod2-ue2": true,<br>  "qa-ue1": true,<br>  "qa-ue2": true,<br>  "rd-ue1": true,<br>  "rd-ue2": true,<br>  "sb-ue1": true,<br>  "ss-ue1": true,<br>  "uat-ue1": true,<br>  "uat-ue2": true<br>}</pre> | no |
| <a name="input_map_migrated"></a> [map\_migrated](#input\_map\_migrated) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "mig34085",<br>  "prod2-ue2": "mig34085",<br>  "qa-ue1": "mig34085",<br>  "qa-ue2": "mig34085",<br>  "rd-ue1": "mig34085",<br>  "rd-ue2": "mig34085",<br>  "sb-ue1": "mig34085",<br>  "ss-ue1": "mig34085",<br>  "uat-ue1": "mig34085",<br>  "uat-ue2": "mig34085"<br>}</pre> | no |
| <a name="input_max_size"></a> [max\_size](#input\_max\_size) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "20",<br>  "prod2-ue2": "5",<br>  "qa-ue1": "20",<br>  "qa-ue2": "7",<br>  "rd-ue1": "0",<br>  "rd-ue2": "10",<br>  "sb-ue1": "3",<br>  "ss-ue1": "4",<br>  "uat-ue1": "0",<br>  "uat-ue2": "5"<br>}</pre> | no |
| <a name="input_min_size"></a> [min\_size](#input\_min\_size) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "16",<br>  "prod2-ue2": "1",<br>  "qa-ue1": "1",<br>  "qa-ue2": "1",<br>  "rd-ue1": "0",<br>  "rd-ue2": "0",<br>  "sb-ue1": "1",<br>  "ss-ue1": "2",<br>  "uat-ue1": "0",<br>  "uat-ue2": "1"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_retention_in_days"></a> [retention\_in\_days](#input\_retention\_in\_days) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "60",<br>  "prod2-ue2": "60",<br>  "qa-ue1": "30",<br>  "qa-ue2": "30",<br>  "rd-ue1": "30",<br>  "rd-ue2": "14",<br>  "sb-ue1": "14",<br>  "ss-ue1": "14",<br>  "uat-ue1": "30",<br>  "uat-ue2": "30"<br>}</pre> | no |
| <a name="input_scaling_schedule_end_down"></a> [scaling\_schedule\_end\_down](#input\_scaling\_schedule\_end\_down) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "",<br>  "qa-ue1": "",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "sb-ue1": "2023-02-18T11:30:00Z",<br>  "ss-ue1": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_scaling_schedule_end_up"></a> [scaling\_schedule\_end\_up](#input\_scaling\_schedule\_end\_up) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "",<br>  "qa-ue1": "",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "sb-ue1": "2023-02-18T02:30:00Z",<br>  "ss-ue1": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_scaling_schedule_start_down"></a> [scaling\_schedule\_start\_down](#input\_scaling\_schedule\_start\_down) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "",<br>  "qa-ue1": "",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "sb-ue1": "2022-02-18T11:00:00Z",<br>  "ss-ue1": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_scaling_schedule_start_up"></a> [scaling\_schedule\_start\_up](#input\_scaling\_schedule\_start\_up) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "",<br>  "qa-ue1": "",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "sb-ue1": "2022-02-18T02:00:00Z",<br>  "ss-ue1": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_schedule_desired_capacity_down"></a> [schedule\_desired\_capacity\_down](#input\_schedule\_desired\_capacity\_down) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "",<br>  "qa-ue1": "",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "sb-ue1": "0",<br>  "ss-ue1": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_schedule_desired_capacity_up"></a> [schedule\_desired\_capacity\_up](#input\_schedule\_desired\_capacity\_up) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "",<br>  "qa-ue1": "",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "sb-ue1": "2",<br>  "ss-ue1": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_schedule_max_size_down"></a> [schedule\_max\_size\_down](#input\_schedule\_max\_size\_down) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "",<br>  "qa-ue1": "",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "sb-ue1": "0",<br>  "ss-ue1": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_schedule_max_size_up"></a> [schedule\_max\_size\_up](#input\_schedule\_max\_size\_up) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "",<br>  "qa-ue1": "",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "sb-ue1": "3",<br>  "ss-ue1": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_schedule_min_size_down"></a> [schedule\_min\_size\_down](#input\_schedule\_min\_size\_down) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "",<br>  "qa-ue1": "",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "sb-ue1": "0",<br>  "ss-ue1": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_schedule_min_size_up"></a> [schedule\_min\_size\_up](#input\_schedule\_min\_size\_up) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "",<br>  "qa-ue1": "",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "sb-ue1": "1",<br>  "ss-ue1": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_schedule_recurrence_down"></a> [schedule\_recurrence\_down](#input\_schedule\_recurrence\_down) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "",<br>  "qa-ue1": "",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "sb-ue1": "11 00 * * *",<br>  "ss-ue1": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_schedule_recurrence_up"></a> [schedule\_recurrence\_up](#input\_schedule\_recurrence\_up) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "",<br>  "qa-ue1": "",<br>  "qa-ue2": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "sb-ue1": "02 00 * * *",<br>  "ss-ue1": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_volume_type"></a> [volume\_type](#input\_volume\_type) | n/a | `map(any)` | <pre>{<br>  "prod2-ue1": "gp3",<br>  "prod2-ue2": "gp3",<br>  "qa-ue1": "gp3",<br>  "qa-ue2": "gp3",<br>  "rd-ue1": "gp3",<br>  "rd-ue2": "gp3",<br>  "sb-ue1": "gp3",<br>  "ss-ue1": "gp3",<br>  "uat-ue1": "gp3",<br>  "uat-ue2": "gp3"<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_EKSNodeSecGroup"></a> [EKSNodeSecGroup](#output\_EKSNodeSecGroup) | n/a |
| <a name="output_alb-ingress-controller-role-arn"></a> [alb-ingress-controller-role-arn](#output\_alb-ingress-controller-role-arn) | alb-ingress-controller-role-arn |
| <a name="output_config-map-aws-auth"></a> [config-map-aws-auth](#output\_config-map-aws-auth) | n/a |
| <a name="output_default_config_map_aws_auth"></a> [default\_config\_map\_aws\_auth](#output\_default\_config\_map\_aws\_auth) | n/a |
| <a name="output_ec2nodes"></a> [ec2nodes](#output\_ec2nodes) | n/a |
| <a name="output_ec2nodesandfargate"></a> [ec2nodesandfargate](#output\_ec2nodesandfargate) | n/a |
| <a name="output_eks_cluster_identity_oidc_issuer"></a> [eks\_cluster\_identity\_oidc\_issuer](#output\_eks\_cluster\_identity\_oidc\_issuer) | The OIDC Identity issuer for the cluster |
| <a name="output_eks_fargate_profile_arn"></a> [eks\_fargate\_profile\_arn](#output\_eks\_fargate\_profile\_arn) | ARN of the EKS Fargate Profile |
| <a name="output_eks_fargate_profile_id"></a> [eks\_fargate\_profile\_id](#output\_eks\_fargate\_profile\_id) | EKS Cluster name and EKS Fargate Profile name separated by a colon |
| <a name="output_eks_fargate_profile_role_arn"></a> [eks\_fargate\_profile\_role\_arn](#output\_eks\_fargate\_profile\_role\_arn) | ARN of the EKS Fargate Profile IAM role |
| <a name="output_eks_fargate_profile_role_name"></a> [eks\_fargate\_profile\_role\_name](#output\_eks\_fargate\_profile\_role\_name) | Name of the EKS Fargate Profile IAM role |
| <a name="output_eks_fargate_profile_status"></a> [eks\_fargate\_profile\_status](#output\_eks\_fargate\_profile\_status) | Status of the EKS Fargate Profile |
| <a name="output_kubeconfig"></a> [kubeconfig](#output\_kubeconfig) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
