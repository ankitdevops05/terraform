# ec2-bamboo-agent

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_module-sam-windows-session-state-sg"></a> [module-sam-windows-session-state-sg](#module\_module-sam-windows-session-state-sg) | git@github.com:sandatech/terraform-aws-module-security-groups-01.git | v0.0.6 |
| <a name="module_session01"></a> [session01](#module\_session01) | git@github.com:sandatech/terraform-aws-ec2-instance.git | n/a |
| <a name="module_session02"></a> [session02](#module\_session02) | git@github.com:sandatech/terraform-aws-ec2-instance.git | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_route53_record.session01](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.session02](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_ami.aws_linux](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ami) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_dns_name"></a> [dns\_name](#input\_dns\_name) | n/a | `map` | <pre>{<br>  "prod2-ue1": "sam-ss",<br>  "qa-ue1": "sam-ss",<br>  "rd-ue1": "sam-ss",<br>  "uat-ue1": "sam-ss"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_sam_win_sam_session_sg_ports_ingress"></a> [sam\_win\_sam\_session\_sg\_ports\_ingress](#input\_sam\_win\_sam\_session\_sg\_ports\_ingress) | n/a | `map` | <pre>{<br>  "prod2-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata Internal IPs",<br>      "from_port": [<br>        "3389"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "3389"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.16.36.0/22",<br>        "172.16.44.0/22",<br>        "172.16.52.0/22"<br>      ],<br>      "description": "Application Subnets",<br>      "from_port": [<br>        "42424"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "42424"<br>      ]<br>    }<br>  ],<br>  "qa-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata Internal IPs",<br>      "from_port": [<br>        "3389"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "3389"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.16.68.0/22",<br>        "172.16.76.0/22",<br>        "172.16.84.0/22"<br>      ],<br>      "description": "Application Subnets",<br>      "from_port": [<br>        "42424"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "42424"<br>      ]<br>    }<br>  ],<br>  "rd-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata Internal IPs",<br>      "from_port": [<br>        "3389"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "3389"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.16.132.0/22",<br>        "172.16.140.0/22",<br>        "172.16.148.0/22"<br>      ],<br>      "description": "Application Subnets",<br>      "from_port": [<br>        "42424"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "42424"<br>      ]<br>    }<br>  ],<br>  "uat-ue1": [<br>    {<br>      "cidr_blocks": [<br>        "10.15.0.0/20",<br>        "172.19.0.0/19"<br>      ],<br>      "description": "Sandata Internal IPs",<br>      "from_port": [<br>        "3389"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "3389"<br>      ]<br>    },<br>    {<br>      "cidr_blocks": [<br>        "172.16.228.0/22",<br>        "172.16.236.0/22",<br>        "172.16.244.0/22"<br>      ],<br>      "description": "Application Subnets",<br>      "from_port": [<br>        "42424"<br>      ],<br>      "protocols": [<br>        "tcp"<br>      ],<br>      "to_port": [<br>        "42424"<br>      ]<br>    }<br>  ]<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_state_01_ami"></a> [state\_01\_ami](#input\_state\_01\_ami) | n/a | `map` | <pre>{<br>  "prod2-ue1": "ami-05b0cd1af6c0c34e3",<br>  "qa-ue1": "ami-05b0cd1af6c0c34e3",<br>  "rd-ue1": "ami-05b0cd1af6c0c34e3",<br>  "uat-ue1": "ami-05b0cd1af6c0c34e3"<br>}</pre> | no |
| <a name="input_state_01_size"></a> [state\_01\_size](#input\_state\_01\_size) | n/a | `map` | <pre>{<br>  "prod2-ue1": "m5.xlarge",<br>  "qa-ue1": "r6i.large",<br>  "rd-ue1": "r6i.large",<br>  "uat-ue1": "r6i.large"<br>}</pre> | no |
| <a name="input_state_02_ami"></a> [state\_02\_ami](#input\_state\_02\_ami) | n/a | `map` | <pre>{<br>  "prod2-ue1": "ami-05b0cd1af6c0c34e3",<br>  "qa-ue1": "ami-05b0cd1af6c0c34e3",<br>  "rd-ue1": "ami-05b0cd1af6c0c34e3",<br>  "uat-ue1": "ami-05b0cd1af6c0c34e3"<br>}</pre> | no |
| <a name="input_state_02_size"></a> [state\_02\_size](#input\_state\_02\_size) | n/a | `map` | <pre>{<br>  "prod2-ue1": "m5.xlarge",<br>  "qa-ue1": "r6i.large",<br>  "rd-ue1": "r6i.large",<br>  "uat-ue1": "r6i.large"<br>}</pre> | no |
| <a name="input_zone_id"></a> [zone\_id](#input\_zone\_id) | n/a | `map` | <pre>{<br>  "prod2-ue1": "Z08705443VKPJM2VC28CK",<br>  "qa-ue1": "Z09252773C268RBRMRFM5",<br>  "rd-ue1": "Z10112833A0S1SDUH1M7T",<br>  "uat-ue1": "Z10140453QDUP7UZIFSEB"<br>}</pre> | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
