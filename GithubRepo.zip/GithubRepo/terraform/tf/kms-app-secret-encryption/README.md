# kms-app-secret-encryption: creating kms keys in central place
- All KMS application keys across environments RD/QA/UAT/PROD2 are provisioned in Admin account (security purpose instead in Shared account)
- The KMS keys can be used by Lambda, and other applications<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_kms_alias.kms_app_secret_encryption_alias](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/kms_alias) | resource |
| [aws_kms_key.kms_app_secret_encryption](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/kms_key) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_applied_environments"></a> [applied\_environments](#input\_applied\_environments) | n/a | `map` | <pre>{<br>  "admin-ue1": {<br>    "prod2-ue1": "656560712260",<br>    "qa-ue1": "046839536952",<br>    "rd-ue1": "817297989338",<br>    "sb-ue1": "915867530647",<br>    "ss-ue1": "137598536613",<br>    "stg-ue1": "546645935380",<br>    "uat-ue1": "244940236506"<br>  },<br>  "admin-ue2": {<br>    "prod2-ue2": "656560712260",<br>    "qa-ue2": "046839536952",<br>    "rd-ue2": "817297989338",<br>    "uat-ue2": "244940236506"<br>  }<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_kms_alias"></a> [kms\_alias](#output\_kms\_alias) | KMS ID and ARN |
| <a name="output_kms_keys"></a> [kms\_keys](#output\_kms\_keys) | KMS ID and ARN |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
