# rds-idm-mysql-01

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13 |
| <a name="requirement_random"></a> [random](#requirement\_random) | ~> 2.3.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_aurora"></a> [aurora](#module\_aurora) | git@github.com:sandatech/terraform-aws-module-rds-aurora-01.git | v0.0.4 |

## Resources

| Name | Type |
|------|------|
| [aws_db_parameter_group.aurora_db_parameter_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/db_parameter_group) | resource |
| [aws_rds_cluster_parameter_group.aurora_cluster_parameter_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/rds_cluster_parameter_group) | resource |
| [aws_security_group.db_servers](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group_rule.allow_access](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_allowed_cirds"></a> [allowed\_cirds](#input\_allowed\_cirds) | List of VPC security groups to associate | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "172.18.20.0/22",<br>    "10.14.8.19/32"<br>  ],<br>  "qa-ue1": [<br>    "172.18.20.0/22",<br>    "10.15.0.0/20",<br>    "172.18.24.0/22",<br>    "10.14.8.19/32",<br>    "172.16.197.126/32"<br>  ],<br>  "rd-ue1": [<br>    "172.18.20.0/22",<br>    "172.18.24.0/22",<br>    "10.15.0.0/20",<br>    "10.14.8.19/32",<br>    "172.16.197.126/32"<br>  ],<br>  "uat-ue1": [<br>    "172.18.20.0/22",<br>    "10.15.0.0/20",<br>    "172.18.24.0/22",<br>    "10.14.8.19/32"<br>  ]<br>}</pre> | no |
| <a name="input_engine_mode"></a> [engine\_mode](#input\_engine\_mode) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "provisioned",<br>  "qa-ue1": "provisioned",<br>  "rd-ue1": "provisioned",<br>  "uat-ue1": "provisioned"<br>}</pre> | no |
| <a name="input_engine_version"></a> [engine\_version](#input\_engine\_version) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "5.7.mysql_aurora.2.08.2",<br>  "qa-ue1": "5.7.mysql_aurora.2.08.2",<br>  "rd-ue1": "5.7.mysql_aurora.2.08.2",<br>  "uat-ue1": "5.7.mysql_aurora.2.08.2"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "db.r5.large",<br>  "qa-ue1": "db.t3.small",<br>  "rd-ue1": "db.t3.small",<br>  "uat-ue1": "db.t3.small"<br>}</pre> | no |
| <a name="input_monitoring_interval"></a> [monitoring\_interval](#input\_monitoring\_interval) | n/a | `map(string)` | <pre>{<br>  "prod2-ue1": "60",<br>  "qa-ue1": "60",<br>  "rd-ue1": "60",<br>  "uat-ue1": "60"<br>}</pre> | no |
| <a name="input_password"></a> [password](#input\_password) | n/a | `string` | `""` | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_replica_count"></a> [replica\_count](#input\_replica\_count) | n/a | `map` | <pre>{<br>  "prod2-ue1": 2,<br>  "qa-ue1": 1,<br>  "rd-ue1": 1,<br>  "uat-ue1": 1<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_this_rds_cluster_database_name"></a> [this\_rds\_cluster\_database\_name](#output\_this\_rds\_cluster\_database\_name) | Name for an automatically created database on cluster creation |
| <a name="output_this_rds_cluster_endpoint"></a> [this\_rds\_cluster\_endpoint](#output\_this\_rds\_cluster\_endpoint) | The cluster endpoint |
| <a name="output_this_rds_cluster_id"></a> [this\_rds\_cluster\_id](#output\_this\_rds\_cluster\_id) | The ID of the cluster |
| <a name="output_this_rds_cluster_instance_endpoints"></a> [this\_rds\_cluster\_instance\_endpoints](#output\_this\_rds\_cluster\_instance\_endpoints) | A list of all cluster instance endpoints |
| <a name="output_this_rds_cluster_master_password"></a> [this\_rds\_cluster\_master\_password](#output\_this\_rds\_cluster\_master\_password) | The master password |
| <a name="output_this_rds_cluster_master_username"></a> [this\_rds\_cluster\_master\_username](#output\_this\_rds\_cluster\_master\_username) | The master username |
| <a name="output_this_rds_cluster_port"></a> [this\_rds\_cluster\_port](#output\_this\_rds\_cluster\_port) | The port |
| <a name="output_this_rds_cluster_reader_endpoint"></a> [this\_rds\_cluster\_reader\_endpoint](#output\_this\_rds\_cluster\_reader\_endpoint) | The cluster reader endpoint |
| <a name="output_this_rds_cluster_resource_id"></a> [this\_rds\_cluster\_resource\_id](#output\_this\_rds\_cluster\_resource\_id) | The Resource ID of the cluster |
| <a name="output_this_security_group_id"></a> [this\_security\_group\_id](#output\_this\_security\_group\_id) | The security group ID of the cluster |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
