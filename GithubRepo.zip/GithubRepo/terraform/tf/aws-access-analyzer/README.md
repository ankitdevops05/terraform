# aws-access-analyzer

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_access-analyzer"></a> [access-analyzer](#module\_access-analyzer) | git@github.com:sandatech/terraform-aws-module-access-analyzer-.git | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_analyzer_name"></a> [analyzer\_name](#input\_analyzer\_name) | Name for the IAM Access Analyzer | `string` | `"Sandata-org-access-analyzer"` | no |
| <a name="input_enabled"></a> [enabled](#input\_enabled) | Set to false will not create an Analyzer | `bool` | `true` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_is_organization"></a> [is\_organization](#input\_is\_organization) | Set this to true if the IAM Access Analyzer should be enabled in an Organization Master Account | `bool` | `true` | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Add these tags to all resources created by this module | `map(any)` | <pre>{<br>  "Name": "organization-access-analyser",<br>  "Provisioned": "Terraform"<br>}</pre> | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
