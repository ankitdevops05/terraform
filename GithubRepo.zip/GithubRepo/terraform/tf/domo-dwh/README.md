
## Terraform Scripts for Setting up AWS DMS Resources

### Assumes availability of below infrastucture components
- As a prerequisite user who is running the terraform scripts should have all the necessary resource creation permissions in the AWS account
- Service Roles for DMS and Redshift operations. These are the roles that will be used for the AWS service like redshift and dms in order to put cloudwatch logs, create and access the s3 bucket by DMS, establish networks connections etc. In case where the Redshift and DMS resources are created via AWS console, AWS automatically creates these roles if they are not present. However when using CLI or any programmatic approach these needs to be created manually. Hence they should be present beforehand. Ref: https://docs.aws.amazon.com/redshift/latest/mgmt/copy-unload-iam-role.html
  - Roles
    - dms-access-for-endpoint
    - dms-cloudwatch-logs-role
    - dms-vpc-role
- Network components - VPC and Subnets for DMS instance
- Security Groups - For DMS instance

### Infra Project Layout
- main - Contains resouce creation scripts for
  - DMS Subnet Group and DMS Instance
  - DMS Source and Target Endpoints
  - Event subscriptions for replication instance and tasks
- variables - Contain parameters used in resource creation
- tasks - tasks module contains all the DMS task definitions

### Architecture diagram depicting connectivity
Below diagram catpures the AWS resources and various connectivity between them
![Architecture diagram depicting connectivity](sandata_on-prem-dms.png)

### Deploying Resources
- Deployment makes use of the terraform workspace concept for seperating environments
- Terraform inputs are provided via `tfvars` files for each environment e.g. `sandbox.env.tfvars`
- Make sure all the variables are updated as required for the environment the scripts will be run against.
- As part of the deployment Redshift Cluster should be created first. See redshift readme.
- Once the DMS replication user is created in Redshift we can proceed creating the DMS resources.Set the below environment variables. These are the passwords for the source and target database users
```
  export TF_VAR_source_db_username=replication_user_dms
  export TF_VAR_source_db_password=<password>
  export TF_VAR_dms_redshift_username=dmsdbuser
  export TF_VAR_dms_redshift_password=<password>
```
Terraform commands as below,
  - Create or select the workspace e.g. `terraform workspace new/select sandbox`
  - Initialize the workspace - `terraform init`
  - Run plan - `terraform plan -var-file=sandbox.env.tfvars`
  - Apply the resources - `terraform apply -var-file=sandbox.env.tfvars`

This will create the DMS replication instance, endpoints and the replication tasks\
This will also create a SNS topic and add DMS event subscriptions for both replication task and replication instances. It also adds a SNS subscription to a email which is configured via the variables
<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 3.27 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 3.27 |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_redshift_cluster.redshift-cluster-dwh](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/redshift_cluster) | resource |
| [aws_redshift_subnet_group.subnet-group-dwh](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/redshift_subnet_group) | resource |
| [aws_s3_bucket.evv-repl-logs](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_bucket_acl.example_bucket_acl](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_acl) | resource |
| [aws_security_group.dmstask](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group.redshift_cluster](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group_rule.dmstask_allow_dmstask_all](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.redshift_allow_dmstask_5439](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.redshift_allow_dmstask_55439](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.redshift_allow_onprem_5439](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.redshift_allow_onprem_55439](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_security_group_rule.redshift_allow_redshift_all](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group_rule) | resource |
| [aws_ami.ubuntu](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ami) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `string` | `""` | no |
| <a name="input_availability_zone"></a> [availability\_zone](#input\_availability\_zone) | Instance class to use for DMS. | `map(string)` | <pre>{<br>  "prod2-ue1": "b",<br>  "qa-ue1": "b",<br>  "rd-ue1": "b",<br>  "stg-ue1": "b"<br>}</pre> | no |
| <a name="input_dms_endpoint_id_br"></a> [dms\_endpoint\_id\_br](#input\_dms\_endpoint\_id\_br) | n/a | `map` | <pre>{<br>  "prod2-ue1": "sd-prod2-us-east-1-dms-ep-oracle-tpa-source-br-1",<br>  "rd-ue1": "sd-rd-us-east-1-dms-ep-oracle-tpa-source-br-1"<br>}</pre> | no |
| <a name="input_dms_redshift_password"></a> [dms\_redshift\_password](#input\_dms\_redshift\_password) | Target Database Password for DMS. Specified in TFC. | `string` | `""` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_onprem_ingress_cidrs"></a> [onprem\_ingress\_cidrs](#input\_onprem\_ingress\_cidrs) | n/a | `map` | <pre>{<br>  "prod2-ue1": [<br>    "10.15.0.0/20"<br>  ],<br>  "qa-ue1": [<br>    "10.15.0.0/20",<br>    "172.16.132.0/22",<br>    "172.16.140.0/22",<br>    "172.16.148.0/22"<br>  ],<br>  "rd-ue1": [<br>    "10.15.0.0/20",<br>    "172.16.132.0/22",<br>    "172.16.140.0/22",<br>    "172.16.148.0/22"<br>  ]<br>}</pre> | no |
| <a name="input_redshift_cluster_nodes"></a> [redshift\_cluster\_nodes](#input\_redshift\_cluster\_nodes) | Number of nodes in Redshift cluster | `map(number)` | <pre>{<br>  "prod2-ue1": 5,<br>  "qa-ue1": 2,<br>  "rd-ue1": 2,<br>  "stg-ue1": 2<br>}</pre> | no |
| <a name="input_redshift_cluster_type"></a> [redshift\_cluster\_type](#input\_redshift\_cluster\_type) | Redshift cluster type. | `map(string)` | <pre>{<br>  "prod2-ue1": "multi-node",<br>  "qa-ue1": "multi-node",<br>  "rd-ue1": "multi-node",<br>  "stg-ue1": "multi-node"<br>}</pre> | no |
| <a name="input_redshift_master_password"></a> [redshift\_master\_password](#input\_redshift\_master\_password) | Master user password for the redshift cluster. Specified in TFC. | `string` | `""` | no |
| <a name="input_redshift_node_type"></a> [redshift\_node\_type](#input\_redshift\_node\_type) | Redshift cluster node type. | `map(string)` | <pre>{<br>  "prod2-ue1": "ra3.4xlarge",<br>  "qa-ue1": "ra3.4xlarge",<br>  "rd-ue1": "ra3.4xlarge",<br>  "stg-ue1": "ra3.4xlarge"<br>}</pre> | no |
| <a name="input_redshift_port"></a> [redshift\_port](#input\_redshift\_port) | redshift Port. | `map(number)` | <pre>{<br>  "prod2-ue1": 55439,<br>  "qa-ue1": 5455,<br>  "rd-ue1": 55439,<br>  "uat-ue1": 55439<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `string` | `""` | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `string` | `""` | no |
| <a name="input_source_db_port"></a> [source\_db\_port](#input\_source\_db\_port) | Source Database Port. | `map(number)` | <pre>{<br>  "prod2-ue1": 1526,<br>  "rd-ue1": 1526,<br>  "stg-ue1": 1526<br>}</pre> | no |
| <a name="input_source_db_port_br"></a> [source\_db\_port\_br](#input\_source\_db\_port\_br) | n/a | `map` | <pre>{<br>  "prod2-ue1": "1521",<br>  "rd-ue1": "1521"<br>}</pre> | no |
| <a name="input_source_extra_connection_attributes"></a> [source\_extra\_connection\_attributes](#input\_source\_extra\_connection\_attributes) | Redshift cluster type. | `map(string)` | <pre>{<br>  "prod2-ue1": "ArchivedLogDestId=1;AdditionalArchivedLogDestId=2;ArchivedLogsOnly=true;StandbyDelayTime=30",<br>  "qa-ue1": "ArchivedLogDestId=1;AdditionalArchivedLogDestId=2;ArchivedLogsOnly=true;StandbyDelayTime=30",<br>  "rd-ue1": "ArchivedLogDestId=1;AdditionalArchivedLogDestId=2;ArchivedLogsOnly=true;StandbyDelayTime=30",<br>  "stg-ue1": "ArchivedLogDestId=1;AdditionalArchivedLogDestId=2;ArchivedLogsOnly=true;StandbyDelayTime=30"<br>}</pre> | no |
| <a name="input_source_server_name"></a> [source\_server\_name](#input\_source\_server\_name) | Hostname of the Source Server | `map(string)` | <pre>{<br>  "prod2-ue1": "tpa1-exa2-scan.sandata.com",<br>  "rd-ue1": "tpa1-exa2-scan.sandata.com",<br>  "stg-ue1": "tpa1-exa2-scan.sandata.com"<br>}</pre> | no |
| <a name="input_source_server_name_br"></a> [source\_server\_name\_br](#input\_source\_server\_name\_br) | n/a | `map` | <pre>{<br>  "prod2-ue1": "tpa1-exa2-scan.sandata.com",<br>  "rd-ue1": "tpa1-exa2-scan.sandata.com"<br>}</pre> | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags | `map` | <pre>{<br>  "Application": "domo-dwh",<br>  "Backup": "",<br>  "OS": "",<br>  "Owner": "Infrastructure",<br>  "Patch_Cycle": "",<br>  "Provisioned_by": "Terraform",<br>  "Purpose": "domo dwh",<br>  "Security": "",<br>  "Service": "domo-dwh",<br>  "Version": "0.0.1",<br>  "map-migrated": "comm34085"<br>}</pre> | no |
| <a name="input_target_extra_connection_attributes"></a> [target\_extra\_connection\_attributes](#input\_target\_extra\_connection\_attributes) | Redshift cluster type. | `map(string)` | <pre>{<br>  "prod2-ue1": "MaxFileSize=524288",<br>  "qa-ue1": "MaxFileSize=524288",<br>  "rd-ue1": "MaxFileSize=524288",<br>  "stg-ue1": "MaxFileSize=524288"<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_redshift_arn"></a> [redshift\_arn](#output\_redshift\_arn) | n/a |
| <a name="output_redshift_az"></a> [redshift\_az](#output\_redshift\_az) | n/a |
| <a name="output_redshift_cluster_identifier"></a> [redshift\_cluster\_identifier](#output\_redshift\_cluster\_identifier) | Redshift outputs |
| <a name="output_redshift_cluster_version"></a> [redshift\_cluster\_version](#output\_redshift\_cluster\_version) | n/a |
| <a name="output_redshift_dns_name"></a> [redshift\_dns\_name](#output\_redshift\_dns\_name) | n/a |
| <a name="output_redshift_endpoint"></a> [redshift\_endpoint](#output\_redshift\_endpoint) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
