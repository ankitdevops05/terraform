# alt-evv-dataintake-sqs

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_iam_policy.sqs_s3_bucket_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_s3_bucket.sqs_s3_bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_bucket_object.sqs_s3_folder](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_object) | resource |
| [aws_sqs_queue.sqs_queue](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sqs_queue) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_bucket_name"></a> [bucket\_name](#input\_bucket\_name) | Name of the bucket. | `map(string)` | <pre>{<br>  "prod2-ue1": "com-sandata-va-prod2-alt-evv-sqs",<br>  "prod2-ue2": "com-sandata-prod2-alt-evv-sqs",<br>  "qa-ue1": "com-sandata-va-qa-alt-evv-sqs",<br>  "rd-ue1": "com-sandata-va-rd-alt-evv-sqs",<br>  "rd-ue2": "com-sandata-oh-rd-alt-evv-sqs",<br>  "uat-ue1": "com-sandata-va-uat-alt-evv-sqs-01",<br>  "uat-ue2": "com-sandata-uat-alt-evv-sqs"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_iam_policy_name"></a> [iam\_policy\_name](#input\_iam\_policy\_name) | Name of the IAM policy. | `map(string)` | <pre>{<br>  "prod2-ue1": "alt-evv-sqs-s3-access-va",<br>  "prod2-ue2": "alt-evv-sqs-s3-access",<br>  "qa-ue1": "alt-evv-sqs-s3-access-va",<br>  "rd-ue1": "alt-evv-sqs-s3-access-va",<br>  "rd-ue2": "alt-evv-sqs-s3-access-oh",<br>  "uat-ue1": "alt-evv-sqs-s3-access-va",<br>  "uat-ue2": "alt-evv-sqs-s3-access"<br>}</pre> | no |
| <a name="input_queue_types"></a> [queue\_types](#input\_queue\_types) | The types of messages to create queues for. | `map(list(string))` | <pre>{<br>  "prod2-ue1": [<br>    "Client",<br>    "Employee",<br>    "Visit",<br>    "Schedule"<br>  ],<br>  "prod2-ue2": [<br>    "Client",<br>    "Employee",<br>    "Visit",<br>    "Schedule"<br>  ],<br>  "qa-ue1": [<br>    "Client",<br>    "Employee",<br>    "Visit",<br>    "Schedule"<br>  ],<br>  "rd-ue1": [<br>    "Client",<br>    "Employee",<br>    "Visit",<br>    "Schedule"<br>  ],<br>  "rd-ue2": [<br>    "Client",<br>    "Employee",<br>    "Visit",<br>    "Schedule"<br>  ],<br>  "uat-ue1": [<br>    "Client",<br>    "Employee",<br>    "Visit",<br>    "Schedule"<br>  ],<br>  "uat-ue2": [<br>    "Client",<br>    "Employee",<br>    "Visit",<br>    "Schedule"<br>  ]<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_sqs_bucket_arn"></a> [sqs\_bucket\_arn](#input\_sqs\_bucket\_arn) | ARN of the SQS bucket. This should equal nothing unless explicitly needed. | `map(string)` | <pre>{<br>  "prod2-ue1": "",<br>  "prod2-ue2": "arn:aws:s3:::com-sandata-va-prod2-alt-evv-sqs",<br>  "qa-ue1": "",<br>  "rd-ue1": "",<br>  "rd-ue2": "",<br>  "uat-ue1": "",<br>  "uat-ue2": ""<br>}</pre> | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
