### TF Import:

- QA
   + us-east-1
    ```
    terraform import aws_route53_record.redis Z09252773C268RBRMRFM5_sd-qa-ec-redis-01.qa.us-east-1.sandata.com_CNAME
    terraform import aws_route53_record.mysql_smc01 Z09252773C268RBRMRFM5_sd-qa-rds-mysql-smc-01.qa.us-east-1.sandata.com_CNAME
    ```
  + us-east-2
    ```
    terraform import aws_route53_record.redis Z09247692VCPNXOK6F40B_sd-qa-ec-redis-01.qa.us-east-2.sandata.com_CNAME
    terraform import aws_route53_record.mysql_smc01 Z09247692VCPNXOK6F40B_sd-qa-rds-mysql-smc-01.qa.us-east-2.sandata.com_CNAME
    ```

- PROD2
  + us-east-1
    ```
    terraform import aws_route53_record.redis Z08705443VKPJM2VC28CK_sd-prod2-ec-redis-01.prod2.us-east-1.sandata.com_CNAME
    terraform import aws_route53_record.mysql_smc01 Z08705443VKPJM2VC28CK_sd-prod2-rds-mysql-smc-01.prod2.us-east-1.sandata.com_CNAME
    terraform import "aws_route53_record.mysql_smc02[0]" Z08705443VKPJM2VC28CK_sd-prod2-rds-mysql-smc-02.prod2.us-east-1.sandata.com_CNAME
    ```
  + us-east-2
    ```
    terraform import aws_route53_record.redis Z08747962FAS0NZ150ES8_sd-prod2-ec-redis-01.prod2.us-east-2.sandata.com_CNAME
    terraform import aws_route53_record.mysql_smc01 Z08747962FAS0NZ150ES8_sd-prod2-rds-mysql-smc-01.prod2.us-east-2.sandata.com_CNAME
    terraform import "aws_route53_record.mysql_smc02[0]" Z08747962FAS0NZ150ES8_sd-prod2-rds-mysql-smc-02.prod2.us-east-2.sandata.com_CNAME
    ```