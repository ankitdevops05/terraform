# s3-visit-capture-replication

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws.oh"></a> [aws.oh](#provider\_aws.oh) | n/a |
| <a name="provider_aws.va"></a> [aws.va](#provider\_aws.va) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_com_sandata_oh_visit_capture_replicate_to_va"></a> [com\_sandata\_oh\_visit\_capture\_replicate\_to\_va](#module\_com\_sandata\_oh\_visit\_capture\_replicate\_to\_va) | git@github.com:sandatech/terraform-aws-module-s3-replication-roles-policies.git | v0.0.5 |
| <a name="module_com_sandata_va_visit_capture_replicate_to_oh"></a> [com\_sandata\_va\_visit\_capture\_replicate\_to\_oh](#module\_com\_sandata\_va\_visit\_capture\_replicate\_to\_oh) | git@github.com:sandatech/terraform-aws-module-s3-replication-roles-policies.git | v0.0.5 |

## Resources

| Name | Type |
|------|------|
| [aws_s3_bucket_replication_configuration.oh_to_va](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_replication_configuration) | resource |
| [aws_s3_bucket_replication_configuration.va_to_oh](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_replication_configuration) | resource |
| [terraform_remote_state.s3_vc_oh](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |
| [terraform_remote_state.s3_vc_va](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_replication_status"></a> [replication\_status](#input\_replication\_status) | n/a | `map` | <pre>{<br>  "prod2-ue1": "Enabled",<br>  "qa-ue1": "Disabled",<br>  "rd-ue1": "Disabled",<br>  "uat-ue1": "Disabled"<br>}</pre> | no |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
