# vpc-vpn

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_module-vpc-vpn-01"></a> [module-vpc-vpn-01](#module\_module-vpc-vpn-01) | app.terraform.io/sandata-tech/module-vpc-vpn-01/aws | 0.0.1 |
| <a name="module_module-vpc-vpn-02"></a> [module-vpc-vpn-02](#module\_module-vpc-vpn-02) | app.terraform.io/sandata-tech/module-vpc-vpn-01/aws | 0.0.1 |

## Resources

| Name | Type |
|------|------|
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_aws_to_dr"></a> [aws\_to\_dr](#input\_aws\_to\_dr) | n/a | `string` | `"24.157.51.243"` | no |
| <a name="input_aws_to_hq"></a> [aws\_to\_hq](#input\_aws\_to\_hq) | n/a | `string` | `"208.64.40.23"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_tunnel1_address"></a> [tunnel1\_address](#output\_tunnel1\_address) | n/a |
| <a name="output_tunnel1_cgw_inside_address"></a> [tunnel1\_cgw\_inside\_address](#output\_tunnel1\_cgw\_inside\_address) | n/a |
| <a name="output_tunnel1_preshared_key"></a> [tunnel1\_preshared\_key](#output\_tunnel1\_preshared\_key) | n/a |
| <a name="output_tunnel1_vgw_inside_address"></a> [tunnel1\_vgw\_inside\_address](#output\_tunnel1\_vgw\_inside\_address) | n/a |
| <a name="output_tunnel2_address"></a> [tunnel2\_address](#output\_tunnel2\_address) | n/a |
| <a name="output_tunnel2_cgw_inside_address"></a> [tunnel2\_cgw\_inside\_address](#output\_tunnel2\_cgw\_inside\_address) | n/a |
| <a name="output_tunnel2_preshared_key"></a> [tunnel2\_preshared\_key](#output\_tunnel2\_preshared\_key) | n/a |
| <a name="output_tunnel2_vgw_inside_address"></a> [tunnel2\_vgw\_inside\_address](#output\_tunnel2\_vgw\_inside\_address) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
