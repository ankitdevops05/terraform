# rxdb-01

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_auth-to-samify"></a> [auth-to-samify](#module\_auth-to-samify) | ./Modules/lambda | n/a |
| <a name="module_employees-to-samify"></a> [employees-to-samify](#module\_employees-to-samify) | ./Modules/lambda | n/a |
| <a name="module_iam_user"></a> [iam\_user](#module\_iam\_user) | ./Modules/iam | n/a |
| <a name="module_members-to-samify"></a> [members-to-samify](#module\_members-to-samify) | ./Modules/lambda | n/a |
| <a name="module_process-authorization"></a> [process-authorization](#module\_process-authorization) | ./Modules/lambda | n/a |
| <a name="module_process-member"></a> [process-member](#module\_process-member) | ./Modules/lambda | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_dynamodb_table.employee-table](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dynamodb_table) | resource |
| [aws_dynamodb_table.provider-table](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dynamodb_table) | resource |
| [aws_dynamodb_table.samifyAuth-table](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dynamodb_table) | resource |
| [aws_dynamodb_table.samifyMember-table](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/dynamodb_table) | resource |
| [aws_iam_access_key.dynamo](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_access_key) | resource |
| [aws_iam_user.dynamo_user](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_user) | resource |
| [aws_iam_user_policy.dynamo_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_user_policy) | resource |
| [aws_s3_bucket.lambda-s3-bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_bucket_acl.lambda-s3-bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_acl) | resource |
| [aws_s3_bucket_server_side_encryption_configuration.lambda-s3-bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_server_side_encryption_configuration) | resource |
| [aws_s3_bucket_versioning.lambda-s3-bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_versioning) | resource |
| [terraform_remote_state.eks-cluster-01](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |
| [terraform_remote_state.vpc](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_TFC_WORKSPACE_NAME"></a> [TFC\_WORKSPACE\_NAME](#input\_TFC\_WORKSPACE\_NAME) | Leave this blank | `string` | `""` | no |
| <a name="input_access_key"></a> [access\_key](#input\_access\_key) | n/a | `any` | n/a | yes |
| <a name="input_dynamo_user"></a> [dynamo\_user](#input\_dynamo\_user) | Description: This is the token to access vault | `map(string)` | <pre>{<br>  "prod2-ue1": "dynamo_user_rxdb",<br>  "qa-ue1": "dynamo_user_rxdb",<br>  "rd-ue1": "dynamo_user_rxdb",<br>  "rd-ue2": "dynamo_user_rxdb_oh",<br>  "uat-ue1": "dynamo_user_rxdb"<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | All of our managed AWS accounts mapped | `map(string)` | <pre>{<br>  "admin-ue1": "admin",<br>  "admin-ue2": "admin",<br>  "prod-ue1": "prod",<br>  "prod-ue2": "prod",<br>  "prod2-ue1": "prod2",<br>  "prod2-ue2": "prod2",<br>  "qa-ue1": "qa",<br>  "qa-ue2": "qa",<br>  "qa2-ue1": "qa2",<br>  "qa2-ue2": "qa2",<br>  "rd-ue1": "rd",<br>  "rd-ue2": "rd",<br>  "sb-ue1": "sb",<br>  "sb-ue2": "sb",<br>  "ss-ue1": "ss",<br>  "ss-ue2": "ss",<br>  "stg-ue1": "stg",<br>  "stg-ue2": "stg",<br>  "uat-ue1": "uat",<br>  "uat-ue2": "uat"<br>}</pre> | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_secret_key"></a> [secret\_key](#input\_secret\_key) | n/a | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Description: These are the tags to be added to each resource | `map(string)` | <pre>{<br>  "Application": "rxdb",<br>  "Backup": "",<br>  "OS": "",<br>  "Owner": "Infrastructure",<br>  "Patch_Cycle": "",<br>  "Provisioned_by": "Terraform",<br>  "Purpose": "Supporting services for AMP",<br>  "Security": "",<br>  "Service": "rxdb",<br>  "Version": "0.0.1"<br>}</pre> | no |
| <a name="input_tags_all"></a> [tags\_all](#input\_tags\_all) | Description: These are the tags to be added to each resource | `map(string)` | <pre>{<br>  "Application": "rxdb",<br>  "Backup": "",<br>  "Environment": "rd",<br>  "OS": "",<br>  "Owner": "Infrastructure",<br>  "Patch_Cycle": "",<br>  "Provisioned_by": "Terraform",<br>  "Purpose": "Supporting services for AMP",<br>  "Security": "",<br>  "Service": "rxdb",<br>  "Version": "0.0.1"<br>}</pre> | no |
| <a name="input_vault_token"></a> [vault\_token](#input\_vault\_token) | Description: This is the token to access vault | `string` | `""` | no |
| <a name="input_vault_url"></a> [vault\_url](#input\_vault\_url) | Description: This is the token to access vault | `map(string)` | <pre>{<br>  "prod2-ue1": "https://vault.prod2.us-east-1.sandata.com",<br>  "qa-ue1": "https://vault.qa.us-east-1.sandata.com",<br>  "rd-ue1": "https://vault.rd.us-east-1.sandata.com",<br>  "rd-ue2": "https://vault.rd.us-east-2.sandata.com",<br>  "uat-ue1": "https://vault.uat.us-east-1.sandata.com"<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_access_key"></a> [access\_key](#output\_access\_key) | n/a |
| <a name="output_secret"></a> [secret](#output\_secret) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
