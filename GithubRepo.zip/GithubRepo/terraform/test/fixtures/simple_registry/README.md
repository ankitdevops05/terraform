# simple_registry

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.15 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 4.3 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 4.3 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_secure_baseline"></a> [secure\_baseline](#module\_secure\_baseline) | nozaq/secure-baseline/aws | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_iam_user.admin](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_user) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_audit_s3_bucket_name"></a> [audit\_s3\_bucket\_name](#input\_audit\_s3\_bucket\_name) | The name of the S3 bucket to store various audit logs. | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | The AWS region in which global resources are set up. | `string` | `"us-east-1"` | no |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
