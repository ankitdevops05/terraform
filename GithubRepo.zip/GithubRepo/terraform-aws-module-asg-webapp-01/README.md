# terraform

## IGNORE THIS COMMENT, This is to test documents template
  - Starting from v1.0, this module requires [Terraform Provider for AWS](https://github.com/terraform-providers/terraform-provider-aws) v4.0 or later. [Version 1.0 Upgrade Guide](./docs/upgrade-1.0.md) described the recommended procedure after the upgrade.

## License

See LICENSE for full details.

## Pre-commit hooks

1. Install dependencies
pre-commit
terraform-docs required for terraform_docs hooks. GNU awk is required if using terraform-docs older than 0.8.0 with Terraform 0.12.
TFLint required for terraform_tflint hook.
TFSec required for terraform_tfsec hook.
coreutils required for terraform_validate hook on macOS (due to use of realpath).
checkov required for checkov hook.
terrascan required for terrascan hook.
or build and use the Docker image locally as mentioned below in the Run section.


### Install dependencies

* [`pre-commit`](https://pre-commit.com/#install)
* [`terraform-docs`](https://github.com/segmentio/terraform-docs) required for `terraform_docs` hooks.
* [`TFLint`](https://github.com/terraform-linters/tflint) required for `terraform_tflint` hook.

#### MacOS

```bash
brew install pre-commit gawk terraform-docs tflint tfsec coreutils checkov terrascan
brew tap git-chglog/git-chglog
brew install git-chglog

```
#### Once you have the above install you need to initialize pre-commit locally.

```bash
pre-commit install

```<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.3.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 4.66.1 |
| <a name="requirement_local"></a> [local](#requirement\_local) | >= 2.1.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 4.66.1 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_application_load_balancer"></a> [application\_load\_balancer](#module\_application\_load\_balancer) | ./modules/application-load-balancer | n/a |
| <a name="module_auto_scalling_instance"></a> [auto\_scalling\_instance](#module\_auto\_scalling\_instance) | ./modules/auto-scalling-instance | n/a |
| <a name="module_network_load_balancer"></a> [network\_load\_balancer](#module\_network\_load\_balancer) | ./modules/network-load-balancer | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_alb_forwarding_config"></a> [alb\_forwarding\_config](#input\_alb\_forwarding\_config) | A map of target group names and their configurations for the ALB. | <pre>map(object({<br>    port                 = number<br>    protocol             = string<br>    listener_port        = optional(number)<br>    deregistration_delay = optional(string)<br>    preserve_client_ip   = optional(bool)<br>    health_check = optional(object({<br>      enabled             = bool<br>      healthy_threshold   = number<br>      unhealthy_threshold = number<br>      timeout             = number<br>      path                = string<br>      port                = number<br>      protocol            = string<br>      interval            = number<br>      matcher             = string<br>    }))<br>    stickiness = optional(object({<br>      enabled         = bool<br>      cookie_duration = number<br>      cookie_name     = string<br>      type            = string<br>    }))<br>  }))</pre> | `{}` | no |
| <a name="input_alb_idle_timeout"></a> [alb\_idle\_timeout](#input\_alb\_idle\_timeout) | The idle timeout value, in seconds, for the ALB. | `number` | `60` | no |
| <a name="input_alb_sg_ids"></a> [alb\_sg\_ids](#input\_alb\_sg\_ids) | Security group IDs for the ALB used for HTTPS redirection | `list(string)` | `[]` | no |
| <a name="input_alb_subdomain"></a> [alb\_subdomain](#input\_alb\_subdomain) | The subdomain for the ALB. | `list(string)` | `[]` | no |
| <a name="input_alb_subnet_ids"></a> [alb\_subnet\_ids](#input\_alb\_subnet\_ids) | A list of subnet IDs for assigning to the Application Load Balancer. | `list(string)` | n/a | yes |
| <a name="input_asg_enabled"></a> [asg\_enabled](#input\_asg\_enabled) | Should created instances be publicly accessible (if the SG allows) | `bool` | `true` | no |
| <a name="input_asg_name"></a> [asg\_name](#input\_asg\_name) | The name of the Autoscaling Group | `string` | n/a | yes |
| <a name="input_bamboo_user_arn"></a> [bamboo\_user\_arn](#input\_bamboo\_user\_arn) | Arn of User that Bamboo from Shared Account uses to Assume role in current account | `string` | `""` | no |
| <a name="input_block_device_mappings"></a> [block\_device\_mappings](#input\_block\_device\_mappings) | n/a | `list(any)` | `[]` | no |
| <a name="input_bucket_name"></a> [bucket\_name](#input\_bucket\_name) | Bucket Name for Instance profile | `string` | n/a | yes |
| <a name="input_business_domain"></a> [business\_domain](#input\_business\_domain) | The business domain for the load balancer | `string` | n/a | yes |
| <a name="input_capacity_rebalance"></a> [capacity\_rebalance](#input\_capacity\_rebalance) | n/a | `bool` | `false` | no |
| <a name="input_codedeploy_deployment_config_name"></a> [codedeploy\_deployment\_config\_name](#input\_codedeploy\_deployment\_config\_name) | The name of the group's deployment config | `string` | `"CodeDeployDefault.OneAtATime"` | no |
| <a name="input_codedeploy_tg_name"></a> [codedeploy\_tg\_name](#input\_codedeploy\_tg\_name) | ALB ARN for codeploy managing traffic | `any` | `""` | no |
| <a name="input_create_separate_vault_role"></a> [create\_separate\_vault\_role](#input\_create\_separate\_vault\_role) | Specifies whether to create a separate vault role for ec2 to assume | `bool` | `false` | no |
| <a name="input_credit_specification"></a> [credit\_specification](#input\_credit\_specification) | n/a | `any` | `null` | no |
| <a name="input_desired_capacity"></a> [desired\_capacity](#input\_desired\_capacity) | n/a | `string` | `"2"` | no |
| <a name="input_ec2_s3_bucket_access"></a> [ec2\_s3\_bucket\_access](#input\_ec2\_s3\_bucket\_access) | Add policy to allow access to an s3 bucket, you must specify the bucket name | `bool` | `false` | no |
| <a name="input_elastic_gpu_specifications"></a> [elastic\_gpu\_specifications](#input\_elastic\_gpu\_specifications) | n/a | `any` | `null` | no |
| <a name="input_enable_alb"></a> [enable\_alb](#input\_enable\_alb) | Whether to enable the Application Load Balancer (ALB). | `bool` | `true` | no |
| <a name="input_enable_alb_https_redirect"></a> [enable\_alb\_https\_redirect](#input\_enable\_alb\_https\_redirect) | Whether to enable HTTPS redirection on the ALB. | `bool` | `false` | no |
| <a name="input_enable_cz_lb"></a> [enable\_cz\_lb](#input\_enable\_cz\_lb) | Whether to enable cross-zone load balancing. | `bool` | `false` | no |
| <a name="input_enable_http2"></a> [enable\_http2](#input\_enable\_http2) | Whether to enable HTTP/2 support on the ALB. | `bool` | `false` | no |
| <a name="input_enable_nlb"></a> [enable\_nlb](#input\_enable\_nlb) | Enable the Network Load Balancer (NLB) | `bool` | `false` | no |
| <a name="input_enable_traffic_control"></a> [enable\_traffic\_control](#input\_enable\_traffic\_control) | Enables ALB traffic control | `bool` | `false` | no |
| <a name="input_enabled_metrics"></a> [enabled\_metrics](#input\_enabled\_metrics) | n/a | `list(string)` | `[]` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment short name (e.g., dev, prod). | `string` | n/a | yes |
| <a name="input_iam_instance_profile_name"></a> [iam\_instance\_profile\_name](#input\_iam\_instance\_profile\_name) | n/a | `string` | `""` | no |
| <a name="input_image_id"></a> [image\_id](#input\_image\_id) | n/a | `string` | `""` | no |
| <a name="input_instance_key_name"></a> [instance\_key\_name](#input\_instance\_key\_name) | n/a | `string` | `""` | no |
| <a name="input_instance_market_options"></a> [instance\_market\_options](#input\_instance\_market\_options) | n/a | `any` | `null` | no |
| <a name="input_instance_refresh"></a> [instance\_refresh](#input\_instance\_refresh) | n/a | `any` | `null` | no |
| <a name="input_instance_reuse_policy"></a> [instance\_reuse\_policy](#input\_instance\_reuse\_policy) | n/a | `any` | `null` | no |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | n/a | `string` | `""` | no |
| <a name="input_internal"></a> [internal](#input\_internal) | Whether to create an internal or external load balancer. | `bool` | `true` | no |
| <a name="input_launch_template_version"></a> [launch\_template\_version](#input\_launch\_template\_version) | ------------------------------------------------ Launch Template configurations related variables ------------------------------------------------ | `string` | `""` | no |
| <a name="input_lb_cert"></a> [lb\_cert](#input\_lb\_cert) | The Amazon Resource Name (ARN) of the SSL certificate to associate with the HTTPS listener. | `string` | `""` | no |
| <a name="input_lb_ssl_policy"></a> [lb\_ssl\_policy](#input\_lb\_ssl\_policy) | The SSL policy for the load balancer | `string` | `"ELBSecurityPolicy-2016-08"` | no |
| <a name="input_load_balancers"></a> [load\_balancers](#input\_load\_balancers) | n/a | `list(any)` | `[]` | no |
| <a name="input_lt_sg_ids"></a> [lt\_sg\_ids](#input\_lt\_sg\_ids) | ------------------------------------------------ AWS and ASG resources related variables ------------------------------------------------ | `string` | `""` | no |
| <a name="input_max_instance_lifetime"></a> [max\_instance\_lifetime](#input\_max\_instance\_lifetime) | n/a | `number` | `0` | no |
| <a name="input_max_size"></a> [max\_size](#input\_max\_size) | ------------------------------------------------ Autoscaling Group settings related variables ------------------------------------------------ | `string` | `"4"` | no |
| <a name="input_metadata_http_endpoint_enabled"></a> [metadata\_http\_endpoint\_enabled](#input\_metadata\_http\_endpoint\_enabled) | Set false to disable the Instance Metadata Service. | `bool` | `true` | no |
| <a name="input_metadata_http_protocol_ipv6_enabled"></a> [metadata\_http\_protocol\_ipv6\_enabled](#input\_metadata\_http\_protocol\_ipv6\_enabled) | Set true to enable IPv6 in the launch template. | `bool` | `false` | no |
| <a name="input_metadata_http_put_response_hop_limit"></a> [metadata\_http\_put\_response\_hop\_limit](#input\_metadata\_http\_put\_response\_hop\_limit) | The desired HTTP PUT response hop limit (between 1 and 64) for Instance Metadata Service requests.<br>The default is `2` to support containerized workloads. | `number` | `2` | no |
| <a name="input_metadata_http_tokens_required"></a> [metadata\_http\_tokens\_required](#input\_metadata\_http\_tokens\_required) | Set true to require IMDS session tokens, disabling Instance Metadata Service Version 1. | `bool` | `true` | no |
| <a name="input_metadata_instance_metadata_tags_enabled"></a> [metadata\_instance\_metadata\_tags\_enabled](#input\_metadata\_instance\_metadata\_tags\_enabled) | Set true to enable IPv6 in the launch template. | `bool` | `false` | no |
| <a name="input_metrics_granularity"></a> [metrics\_granularity](#input\_metrics\_granularity) | n/a | `string` | `"1Minute"` | no |
| <a name="input_min_size"></a> [min\_size](#input\_min\_size) | n/a | `string` | `"1"` | no |
| <a name="input_mixed_instances_policy"></a> [mixed\_instances\_policy](#input\_mixed\_instances\_policy) | n/a | `any` | `null` | no |
| <a name="input_nlb_forwarding_config"></a> [nlb\_forwarding\_config](#input\_nlb\_forwarding\_config) | A map of forwarding configurations for the Network Load Balancer target groups | <pre>map(object({<br>    port                 = number<br>    protocol             = string<br>    listener_port        = optional(number)<br>    deregistration_delay = optional(number)<br>    preserve_client_ip   = optional(string)<br>    health_check = optional(object({<br>      enabled             = bool<br>      healthy_threshold   = number<br>      unhealthy_threshold = number<br>      timeout             = number<br>      port                = string<br>      protocol            = string<br>      interval            = number<br>    }))<br>    stickiness = optional(object({<br>      enabled         = bool<br>      cookie_duration = number<br>      cookie_name     = string<br>      type            = string<br>    }))<br>  }))</pre> | `{}` | no |
| <a name="input_nlb_subdomain"></a> [nlb\_subdomain](#input\_nlb\_subdomain) | The subdomain for the ALB. | `list(string)` | `[]` | no |
| <a name="input_nlb_subnet_ids"></a> [nlb\_subnet\_ids](#input\_nlb\_subnet\_ids) | Subnet IDs for the Network Load Balancer | `list(string)` | `[]` | no |
| <a name="input_oidc_config"></a> [oidc\_config](#input\_oidc\_config) | OIDC configuration for the ALB listener. | <pre>object({<br>    enabled                             = bool<br>    authorization_endpoint              = string<br>    client_id                           = string<br>    client_secret                       = string<br>    issuer                              = string<br>    token_endpoint                      = string<br>    user_info_endpoint                  = string<br>    authentication_request_extra_params = map(string)<br>    on_unauthenticated_request          = string<br>    scope                               = string<br>    session_cookie_name                 = string<br>    session_timeout                     = number<br>  })</pre> | <pre>{<br>  "authentication_request_extra_params": {},<br>  "authorization_endpoint": "",<br>  "client_id": "",<br>  "client_secret": "",<br>  "enabled": false,<br>  "issuer": "",<br>  "on_unauthenticated_request": "deny",<br>  "scope": "openid",<br>  "session_cookie_name": "AWSELBAuthSessionCookie",<br>  "session_timeout": 604800,<br>  "token_endpoint": "",<br>  "user_info_endpoint": ""<br>}</pre> | no |
| <a name="input_placement"></a> [placement](#input\_placement) | n/a | `any` | `null` | no |
| <a name="input_placement_group"></a> [placement\_group](#input\_placement\_group) | n/a | `string` | `""` | no |
| <a name="input_private_zone_domain"></a> [private\_zone\_domain](#input\_private\_zone\_domain) | The private Route53 Zone domain for the ALB/NLB. | `string` | n/a | yes |
| <a name="input_random_number"></a> [random\_number](#input\_random\_number) | ------------------------------------------------ General variables ------------------------------------------------ | `string` | `""` | no |
| <a name="input_region"></a> [region](#input\_region) | The region for the resources | `string` | n/a | yes |
| <a name="input_scaling_schedule"></a> [scaling\_schedule](#input\_scaling\_schedule) | ------------------------------------------------ Autoscaling Schedule settings related variables ------------------------------------------------ | <pre>object({<br>    enable_schedule_scaling        = bool<br>    schedule_min_size_up           = number<br>    schedule_max_size_up           = number<br>    schedule_desired_capacity_up   = number<br>    scaling_schedule_start_up      = string<br>    scaling_schedule_end_up        = string<br>    schedule_recurrence_up         = string<br>    schedule_min_size_down         = number<br>    schedule_max_size_down         = number<br>    schedule_desired_capacity_down = number<br>    scaling_schedule_start_down    = string<br>    scaling_schedule_end_down      = string<br>    schedule_recurrence_down       = string<br>  })</pre> | <pre>{<br>  "enable_schedule_scaling": false,<br>  "scaling_schedule_end_down": "23:59",<br>  "scaling_schedule_end_up": "23:59",<br>  "scaling_schedule_start_down": "00:00",<br>  "scaling_schedule_start_up": "00:00",<br>  "schedule_desired_capacity_down": 0,<br>  "schedule_desired_capacity_up": 1,<br>  "schedule_max_size_down": 0,<br>  "schedule_max_size_up": 1,<br>  "schedule_min_size_down": 0,<br>  "schedule_min_size_up": 1,<br>  "schedule_recurrence_down": "0 0 * * *",<br>  "schedule_recurrence_up": "0 0 * * *"<br>}</pre> | no |
| <a name="input_security_group_ids"></a> [security\_group\_ids](#input\_security\_group\_ids) | n/a | `list(string)` | `[]` | no |
| <a name="input_service_linked_role_arn"></a> [service\_linked\_role\_arn](#input\_service\_linked\_role\_arn) | n/a | `string` | `""` | no |
| <a name="input_shared_account_artifacts_bucket_name"></a> [shared\_account\_artifacts\_bucket\_name](#input\_shared\_account\_artifacts\_bucket\_name) | Name of the Bucket in Shared account that stores artifacts built by Bamboo | `string` | n/a | yes |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | n/a | `list(string)` | `[]` | no |
| <a name="input_suspended_processes"></a> [suspended\_processes](#input\_suspended\_processes) | n/a | `list(string)` | `[]` | no |
| <a name="input_tag_specifications_resource_types"></a> [tag\_specifications\_resource\_types](#input\_tag\_specifications\_resource\_types) | List of tag specification resource types to tag. Valid values are instance, volume, elastic-gpu and spot-instances-request. | `set(string)` | `[]` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to assign to resources. | `map(string)` | `{}` | no |
| <a name="input_target_group_arns"></a> [target\_group\_arns](#input\_target\_group\_arns) | n/a | `list(string)` | `[]` | no |
| <a name="input_termination_policies"></a> [termination\_policies](#input\_termination\_policies) | n/a | `list(string)` | `[]` | no |
| <a name="input_user_data"></a> [user\_data](#input\_user\_data) | n/a | `string` | `""` | no |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | The VPC ID for the target group of the load balancer. | `string` | n/a | yes |
| <a name="input_warm_pool"></a> [warm\_pool](#input\_warm\_pool) | n/a | `any` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_alb_https_redirect"></a> [alb\_https\_redirect](#output\_alb\_https\_redirect) | The target group for the ALB HTTPS redirect |
| <a name="output_appname"></a> [appname](#output\_appname) | n/a |
| <a name="output_asg_default_values"></a> [asg\_default\_values](#output\_asg\_default\_values) | n/a |
| <a name="output_asg_tags"></a> [asg\_tags](#output\_asg\_tags) | n/a |
| <a name="output_autoscaling_group_name"></a> [autoscaling\_group\_name](#output\_autoscaling\_group\_name) | n/a |
| <a name="output_aws_autoscaling_group_asg"></a> [aws\_autoscaling\_group\_asg](#output\_aws\_autoscaling\_group\_asg) | n/a |
| <a name="output_aws_autoscaling_schedule__webapp_up"></a> [aws\_autoscaling\_schedule\_\_webapp\_up](#output\_aws\_autoscaling\_schedule\_\_webapp\_up) | n/a |
| <a name="output_aws_autoscaling_schedule_webapp_down"></a> [aws\_autoscaling\_schedule\_webapp\_down](#output\_aws\_autoscaling\_schedule\_webapp\_down) | n/a |
| <a name="output_aws_launch_template_default"></a> [aws\_launch\_template\_default](#output\_aws\_launch\_template\_default) | n/a |
| <a name="output_bamboo_deployer_artifacts_s3_access"></a> [bamboo\_deployer\_artifacts\_s3\_access](#output\_bamboo\_deployer\_artifacts\_s3\_access) | n/a |
| <a name="output_bamboo_deployer_role"></a> [bamboo\_deployer\_role](#output\_bamboo\_deployer\_role) | n/a |
| <a name="output_codedeploy_app_name"></a> [codedeploy\_app\_name](#output\_codedeploy\_app\_name) | n/a |
| <a name="output_codedeploy_deployment_group_name"></a> [codedeploy\_deployment\_group\_name](#output\_codedeploy\_deployment\_group\_name) | n/a |
| <a name="output_codedeploy_deployment_option"></a> [codedeploy\_deployment\_option](#output\_codedeploy\_deployment\_option) | n/a |
| <a name="output_codedeploy_policy"></a> [codedeploy\_policy](#output\_codedeploy\_policy) | n/a |
| <a name="output_codedeploy_role"></a> [codedeploy\_role](#output\_codedeploy\_role) | n/a |
| <a name="output_codedeploy_service_role_arn"></a> [codedeploy\_service\_role\_arn](#output\_codedeploy\_service\_role\_arn) | n/a |
| <a name="output_codedeploy_target_group_name"></a> [codedeploy\_target\_group\_name](#output\_codedeploy\_target\_group\_name) | n/a |
| <a name="output_ds_ec2_policy"></a> [ds\_ec2\_policy](#output\_ds\_ec2\_policy) | n/a |
| <a name="output_ec2_iam_role"></a> [ec2\_iam\_role](#output\_ec2\_iam\_role) | n/a |
| <a name="output_ec2_instance_profile"></a> [ec2\_instance\_profile](#output\_ec2\_instance\_profile) | n/a |
| <a name="output_ec2readonly_policy"></a> [ec2readonly\_policy](#output\_ec2readonly\_policy) | n/a |
| <a name="output_front_end_https_redirect"></a> [front\_end\_https\_redirect](#output\_front\_end\_https\_redirect) | The front-end ALB listener for HTTPS redirect |
| <a name="output_front_end_listener_arn"></a> [front\_end\_listener\_arn](#output\_front\_end\_listener\_arn) | ARN of the Front End Listener created for the Application Load Balancer |
| <a name="output_groupname"></a> [groupname](#output\_groupname) | n/a |
| <a name="output_https_redirect_attachment"></a> [https\_redirect\_attachment](#output\_https\_redirect\_attachment) | The target group attachment for the HTTPS redirect |
| <a name="output_launch_template"></a> [launch\_template](#output\_launch\_template) | n/a |
| <a name="output_launch_template_block"></a> [launch\_template\_block](#output\_launch\_template\_block) | n/a |
| <a name="output_listener_80"></a> [listener\_80](#output\_listener\_80) | The NLB listener for port 80 |
| <a name="output_lt_default_values"></a> [lt\_default\_values](#output\_lt\_default\_values) | n/a |
| <a name="output_mixed_instances_policy"></a> [mixed\_instances\_policy](#output\_mixed\_instances\_policy) | n/a |
| <a name="output_nlb_webapp_target_group_arns"></a> [nlb\_webapp\_target\_group\_arns](#output\_nlb\_webapp\_target\_group\_arns) | ARNs of the Target Groups created for the Application Load Balancer |
| <a name="output_nlb_webapp_target_group_names"></a> [nlb\_webapp\_target\_group\_names](#output\_nlb\_webapp\_target\_group\_names) | IDs of the Target Groups created for the Application Load Balancer |
| <a name="output_route53_alb_record_fqdns"></a> [route53\_alb\_record\_fqdns](#output\_route53\_alb\_record\_fqdns) | Fully qualified domain names of the Route53 records created for the Application Load Balancer |
| <a name="output_route53_alb_record_ids"></a> [route53\_alb\_record\_ids](#output\_route53\_alb\_record\_ids) | IDs of the Route53 records created for the Application Load Balancer |
| <a name="output_ssm_ec2_policy"></a> [ssm\_ec2\_policy](#output\_ssm\_ec2\_policy) | n/a |
| <a name="output_vault_access_policy"></a> [vault\_access\_policy](#output\_vault\_access\_policy) | n/a |
| <a name="output_vault_iam_role"></a> [vault\_iam\_role](#output\_vault\_iam\_role) | n/a |
| <a name="output_webapp_alb_arn"></a> [webapp\_alb\_arn](#output\_webapp\_alb\_arn) | ARN of the Application Load Balancer |
| <a name="output_webapp_alb_dns_name"></a> [webapp\_alb\_dns\_name](#output\_webapp\_alb\_dns\_name) | DNS name of the Application Load Balancer |
| <a name="output_webapp_alb_https_redirect"></a> [webapp\_alb\_https\_redirect](#output\_webapp\_alb\_https\_redirect) | The Application Load Balancer for HTTPS redirect |
| <a name="output_webapp_alb_https_redirect_arn"></a> [webapp\_alb\_https\_redirect\_arn](#output\_webapp\_alb\_https\_redirect\_arn) | The ARN of the Application Load Balancer for HTTPS redirect |
| <a name="output_webapp_alb_https_redirect_dns_name"></a> [webapp\_alb\_https\_redirect\_dns\_name](#output\_webapp\_alb\_https\_redirect\_dns\_name) | The DNS name of the Application Load Balancer for HTTPS redirect |
| <a name="output_webapp_alb_https_redirect_zone_id"></a> [webapp\_alb\_https\_redirect\_zone\_id](#output\_webapp\_alb\_https\_redirect\_zone\_id) | The zone ID of the Application Load Balancer for HTTPS redirect |
| <a name="output_webapp_alb_name"></a> [webapp\_alb\_name](#output\_webapp\_alb\_name) | ARN of the Application Load Balancer |
| <a name="output_webapp_alb_zone_id"></a> [webapp\_alb\_zone\_id](#output\_webapp\_alb\_zone\_id) | Zone ID of the Application Load Balancer |
| <a name="output_webapp_listener"></a> [webapp\_listener](#output\_webapp\_listener) | The listeners for the Network Load Balancer |
| <a name="output_webapp_listener_arns"></a> [webapp\_listener\_arns](#output\_webapp\_listener\_arns) | ARNs of the Listeners created for the Application Load Balancer |
| <a name="output_webapp_nlb"></a> [webapp\_nlb](#output\_webapp\_nlb) | The Network Load Balancer |
| <a name="output_webapp_nlb_arn"></a> [webapp\_nlb\_arn](#output\_webapp\_nlb\_arn) | The ARN of the Network Load Balancer |
| <a name="output_webapp_nlb_dns_name"></a> [webapp\_nlb\_dns\_name](#output\_webapp\_nlb\_dns\_name) | The DNS name of the Network Load Balancer |
| <a name="output_webapp_nlb_zone_id"></a> [webapp\_nlb\_zone\_id](#output\_webapp\_nlb\_zone\_id) | The zone ID of the Network Load Balancer |
| <a name="output_webapp_target_group_arns"></a> [webapp\_target\_group\_arns](#output\_webapp\_target\_group\_arns) | ARNs of the Target Groups created for the Application Load Balancer |
| <a name="output_webapp_target_group_ids"></a> [webapp\_target\_group\_ids](#output\_webapp\_target\_group\_ids) | IDs of the Target Groups created for the Application Load Balancer |
| <a name="output_webapp_target_group_names"></a> [webapp\_target\_group\_names](#output\_webapp\_target\_group\_names) | Names of the Target Groups created for the Application Load Balancer |
| <a name="output_webapp_tg_nlb"></a> [webapp\_tg\_nlb](#output\_webapp\_tg\_nlb) | The target groups for the Network Load Balancer |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
