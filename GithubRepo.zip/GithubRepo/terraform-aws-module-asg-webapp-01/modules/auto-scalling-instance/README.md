# auto-scalling-instance

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 4.66.1 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_autoscaling_group.asg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/autoscaling_group) | resource |
| [aws_autoscaling_schedule.webapp_down](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/autoscaling_schedule) | resource |
| [aws_autoscaling_schedule.webapp_up](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/autoscaling_schedule) | resource |
| [aws_codedeploy_app.app](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codedeploy_app) | resource |
| [aws_codedeploy_deployment_group.deploy_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/codedeploy_deployment_group) | resource |
| [aws_iam_instance_profile.ec2_instance_profile](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_instance_profile) | resource |
| [aws_iam_role.alert_es_iam_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.bamboo_deployer](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.codedeploy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.ec2_iam_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.vault_iam_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role_policy.bamboo_deployer_artifacts_s3_access](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.ec2_s3_sftp_iam_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.es_sns_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.shared_s3_artifacts_readonly](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.vault_access_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy_attachment.bamboo_deployer_codedeploy_access](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_iam_role_policy_attachment.codedeploy_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_iam_role_policy_attachment.ds_ec2_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_iam_role_policy_attachment.ec2readonly_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_iam_role_policy_attachment.ssm_ec2_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_launch_template.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/launch_template) | resource |
| [aws_sns_topic.alert_topic](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sns_topic) | resource |
| [aws_sns_topic_policy.alert_topic_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sns_topic_policy) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_iam_policy_document.alert_topic_policy_doc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_asg_enabled"></a> [asg\_enabled](#input\_asg\_enabled) | Should created instances be publicly accessible (if the SG allows) | `bool` | `true` | no |
| <a name="input_asg_name"></a> [asg\_name](#input\_asg\_name) | The name of the Autoscaling Group | `string` | n/a | yes |
| <a name="input_bamboo_user_arn"></a> [bamboo\_user\_arn](#input\_bamboo\_user\_arn) | Arn of User that Bamboo from Shared Account uses to Assume role in current account | `string` | `""` | no |
| <a name="input_block_device_mappings"></a> [block\_device\_mappings](#input\_block\_device\_mappings) | n/a | `list(any)` | `[]` | no |
| <a name="input_bucket_name"></a> [bucket\_name](#input\_bucket\_name) | Bucket Name for Instance profile | `string` | n/a | yes |
| <a name="input_business_domain"></a> [business\_domain](#input\_business\_domain) | n/a | `string` | `""` | no |
| <a name="input_capacity_rebalance"></a> [capacity\_rebalance](#input\_capacity\_rebalance) | n/a | `bool` | `false` | no |
| <a name="input_codedeploy_deployment_config_name"></a> [codedeploy\_deployment\_config\_name](#input\_codedeploy\_deployment\_config\_name) | The name of the group's deployment config | `string` | `"CodeDeployDefault.OneAtATime"` | no |
| <a name="input_codedeploy_tg_name"></a> [codedeploy\_tg\_name](#input\_codedeploy\_tg\_name) | ALB ARN for codeploy managing traffic | `any` | `""` | no |
| <a name="input_create_separate_vault_role"></a> [create\_separate\_vault\_role](#input\_create\_separate\_vault\_role) | Specifies whether to create a separate vault role for ec2 to assume | `bool` | `false` | no |
| <a name="input_credit_specification"></a> [credit\_specification](#input\_credit\_specification) | n/a | `any` | `null` | no |
| <a name="input_desired_capacity"></a> [desired\_capacity](#input\_desired\_capacity) | n/a | `string` | `"2"` | no |
| <a name="input_ec2_s3_bucket_access"></a> [ec2\_s3\_bucket\_access](#input\_ec2\_s3\_bucket\_access) | Add policy to allow access to an s3 bucket, you must specify the bucket name | `bool` | `false` | no |
| <a name="input_elastic_gpu_specifications"></a> [elastic\_gpu\_specifications](#input\_elastic\_gpu\_specifications) | n/a | `any` | `null` | no |
| <a name="input_enable_traffic_control"></a> [enable\_traffic\_control](#input\_enable\_traffic\_control) | Enables ALB traffic control | `bool` | `false` | no |
| <a name="input_enabled_metrics"></a> [enabled\_metrics](#input\_enabled\_metrics) | n/a | `list(string)` | `[]` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | n/a | `string` | `""` | no |
| <a name="input_iam_instance_profile_name"></a> [iam\_instance\_profile\_name](#input\_iam\_instance\_profile\_name) | n/a | `string` | `""` | no |
| <a name="input_image_id"></a> [image\_id](#input\_image\_id) | n/a | `string` | `""` | no |
| <a name="input_instance_key_name"></a> [instance\_key\_name](#input\_instance\_key\_name) | n/a | `string` | `""` | no |
| <a name="input_instance_market_options"></a> [instance\_market\_options](#input\_instance\_market\_options) | n/a | `any` | `null` | no |
| <a name="input_instance_refresh"></a> [instance\_refresh](#input\_instance\_refresh) | n/a | `any` | `null` | no |
| <a name="input_instance_reuse_policy"></a> [instance\_reuse\_policy](#input\_instance\_reuse\_policy) | n/a | `any` | `null` | no |
| <a name="input_instance_type"></a> [instance\_type](#input\_instance\_type) | n/a | `string` | `""` | no |
| <a name="input_launch_template_version"></a> [launch\_template\_version](#input\_launch\_template\_version) | ------------------------------------------------ Launch Template configurations related variables ------------------------------------------------ | `string` | `""` | no |
| <a name="input_load_balancers"></a> [load\_balancers](#input\_load\_balancers) | n/a | `list(any)` | `[]` | no |
| <a name="input_lt_sg_ids"></a> [lt\_sg\_ids](#input\_lt\_sg\_ids) | ------------------------------------------------ AWS and ASG resources related variables ------------------------------------------------ | `string` | `""` | no |
| <a name="input_max_instance_lifetime"></a> [max\_instance\_lifetime](#input\_max\_instance\_lifetime) | n/a | `number` | `0` | no |
| <a name="input_max_size"></a> [max\_size](#input\_max\_size) | ------------------------------------------------ Autoscaling Group settings related variables ------------------------------------------------ | `string` | `"4"` | no |
| <a name="input_metadata_http_endpoint_enabled"></a> [metadata\_http\_endpoint\_enabled](#input\_metadata\_http\_endpoint\_enabled) | Set false to disable the Instance Metadata Service. | `bool` | `true` | no |
| <a name="input_metadata_http_protocol_ipv6_enabled"></a> [metadata\_http\_protocol\_ipv6\_enabled](#input\_metadata\_http\_protocol\_ipv6\_enabled) | Set true to enable IPv6 in the launch template. | `bool` | `false` | no |
| <a name="input_metadata_http_put_response_hop_limit"></a> [metadata\_http\_put\_response\_hop\_limit](#input\_metadata\_http\_put\_response\_hop\_limit) | The desired HTTP PUT response hop limit (between 1 and 64) for Instance Metadata Service requests.<br>The default is `2` to support containerized workloads. | `number` | `2` | no |
| <a name="input_metadata_http_tokens_required"></a> [metadata\_http\_tokens\_required](#input\_metadata\_http\_tokens\_required) | Set true to require IMDS session tokens, disabling Instance Metadata Service Version 1. | `bool` | `true` | no |
| <a name="input_metadata_instance_metadata_tags_enabled"></a> [metadata\_instance\_metadata\_tags\_enabled](#input\_metadata\_instance\_metadata\_tags\_enabled) | Set true to enable IPv6 in the launch template. | `bool` | `false` | no |
| <a name="input_metrics_granularity"></a> [metrics\_granularity](#input\_metrics\_granularity) | n/a | `string` | `"1Minute"` | no |
| <a name="input_min_size"></a> [min\_size](#input\_min\_size) | n/a | `string` | `"1"` | no |
| <a name="input_mixed_instances_policy"></a> [mixed\_instances\_policy](#input\_mixed\_instances\_policy) | n/a | `any` | `null` | no |
| <a name="input_placement"></a> [placement](#input\_placement) | n/a | `any` | `null` | no |
| <a name="input_placement_group"></a> [placement\_group](#input\_placement\_group) | n/a | `string` | `""` | no |
| <a name="input_random_number"></a> [random\_number](#input\_random\_number) | ------------------------------------------------ General variables ------------------------------------------------ | `string` | `""` | no |
| <a name="input_region"></a> [region](#input\_region) | n/a | `string` | `""` | no |
| <a name="input_scaling_schedule"></a> [scaling\_schedule](#input\_scaling\_schedule) | ------------------------------------------------ Autoscaling Schedule settings related variables ------------------------------------------------ | <pre>object({<br>    enable_schedule_scaling        = bool<br>    schedule_min_size_up           = number<br>    schedule_max_size_up           = number<br>    schedule_desired_capacity_up   = number<br>    scaling_schedule_start_up      = string<br>    scaling_schedule_end_up        = string<br>    schedule_recurrence_up         = string<br>    schedule_min_size_down         = number<br>    schedule_max_size_down         = number<br>    schedule_desired_capacity_down = number<br>    scaling_schedule_start_down    = string<br>    scaling_schedule_end_down      = string<br>    schedule_recurrence_down       = string<br>  })</pre> | <pre>{<br>  "enable_schedule_scaling": false,<br>  "scaling_schedule_end_down": "23:59",<br>  "scaling_schedule_end_up": "23:59",<br>  "scaling_schedule_start_down": "00:00",<br>  "scaling_schedule_start_up": "00:00",<br>  "schedule_desired_capacity_down": 0,<br>  "schedule_desired_capacity_up": 1,<br>  "schedule_max_size_down": 0,<br>  "schedule_max_size_up": 1,<br>  "schedule_min_size_down": 0,<br>  "schedule_min_size_up": 1,<br>  "schedule_recurrence_down": "0 0 * * *",<br>  "schedule_recurrence_up": "0 0 * * *"<br>}</pre> | no |
| <a name="input_security_group_ids"></a> [security\_group\_ids](#input\_security\_group\_ids) | n/a | `list(string)` | `[]` | no |
| <a name="input_service_linked_role_arn"></a> [service\_linked\_role\_arn](#input\_service\_linked\_role\_arn) | n/a | `string` | `""` | no |
| <a name="input_shared_account_artifacts_bucket_name"></a> [shared\_account\_artifacts\_bucket\_name](#input\_shared\_account\_artifacts\_bucket\_name) | Name of the Bucket in Shared account that stores artifacts built by Bamboo | `string` | n/a | yes |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | n/a | `list(string)` | `[]` | no |
| <a name="input_suspended_processes"></a> [suspended\_processes](#input\_suspended\_processes) | n/a | `list(string)` | `[]` | no |
| <a name="input_tag_specifications_resource_types"></a> [tag\_specifications\_resource\_types](#input\_tag\_specifications\_resource\_types) | List of tag specification resource types to tag. Valid values are instance, volume, elastic-gpu and spot-instances-request. | `set(string)` | `[]` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | n/a | `map(string)` | `{}` | no |
| <a name="input_target_group_arns"></a> [target\_group\_arns](#input\_target\_group\_arns) | n/a | `list(string)` | `[]` | no |
| <a name="input_termination_policies"></a> [termination\_policies](#input\_termination\_policies) | n/a | `list(string)` | `[]` | no |
| <a name="input_user_data"></a> [user\_data](#input\_user\_data) | n/a | `string` | `""` | no |
| <a name="input_warm_pool"></a> [warm\_pool](#input\_warm\_pool) | n/a | `any` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_appname"></a> [appname](#output\_appname) | The application name generated by locals. |
| <a name="output_asg_default_values"></a> [asg\_default\_values](#output\_asg\_default\_values) | n/a |
| <a name="output_asg_tags"></a> [asg\_tags](#output\_asg\_tags) | n/a |
| <a name="output_autoscaling_group_name"></a> [autoscaling\_group\_name](#output\_autoscaling\_group\_name) | The name of the associated autoscaling group. |
| <a name="output_aws_autoscaling_group_asg"></a> [aws\_autoscaling\_group\_asg](#output\_aws\_autoscaling\_group\_asg) | n/a |
| <a name="output_aws_autoscaling_schedule__webapp_up"></a> [aws\_autoscaling\_schedule\_\_webapp\_up](#output\_aws\_autoscaling\_schedule\_\_webapp\_up) | n/a |
| <a name="output_aws_autoscaling_schedule_webapp_down"></a> [aws\_autoscaling\_schedule\_webapp\_down](#output\_aws\_autoscaling\_schedule\_webapp\_down) | n/a |
| <a name="output_aws_launch_template_default"></a> [aws\_launch\_template\_default](#output\_aws\_launch\_template\_default) | n/a |
| <a name="output_bamboo_deployer_artifacts_s3_access"></a> [bamboo\_deployer\_artifacts\_s3\_access](#output\_bamboo\_deployer\_artifacts\_s3\_access) | n/a |
| <a name="output_bamboo_deployer_role"></a> [bamboo\_deployer\_role](#output\_bamboo\_deployer\_role) | n/a |
| <a name="output_codedeploy_app_name"></a> [codedeploy\_app\_name](#output\_codedeploy\_app\_name) | The name of the created CodeDeploy application. |
| <a name="output_codedeploy_deployment_group_name"></a> [codedeploy\_deployment\_group\_name](#output\_codedeploy\_deployment\_group\_name) | The name of the created CodeDeploy deployment group. |
| <a name="output_codedeploy_deployment_option"></a> [codedeploy\_deployment\_option](#output\_codedeploy\_deployment\_option) | The deployment option for the CodeDeploy deployment group (if traffic control is enabled). |
| <a name="output_codedeploy_policy"></a> [codedeploy\_policy](#output\_codedeploy\_policy) | n/a |
| <a name="output_codedeploy_role"></a> [codedeploy\_role](#output\_codedeploy\_role) | n/a |
| <a name="output_codedeploy_service_role_arn"></a> [codedeploy\_service\_role\_arn](#output\_codedeploy\_service\_role\_arn) | The service role ARN associated with the CodeDeploy deployment group. |
| <a name="output_codedeploy_target_group_name"></a> [codedeploy\_target\_group\_name](#output\_codedeploy\_target\_group\_name) | The name of the target group associated with the CodeDeploy deployment group (if traffic control is enabled). |
| <a name="output_ds_ec2_policy"></a> [ds\_ec2\_policy](#output\_ds\_ec2\_policy) | n/a |
| <a name="output_ec2_iam_role"></a> [ec2\_iam\_role](#output\_ec2\_iam\_role) | n/a |
| <a name="output_ec2_instance_profile"></a> [ec2\_instance\_profile](#output\_ec2\_instance\_profile) | ---------------- IAM ---------------- |
| <a name="output_ec2readonly_policy"></a> [ec2readonly\_policy](#output\_ec2readonly\_policy) | n/a |
| <a name="output_groupname"></a> [groupname](#output\_groupname) | The deployment group name generated by locals. |
| <a name="output_launch_template"></a> [launch\_template](#output\_launch\_template) | n/a |
| <a name="output_launch_template_block"></a> [launch\_template\_block](#output\_launch\_template\_block) | n/a |
| <a name="output_lt_default_values"></a> [lt\_default\_values](#output\_lt\_default\_values) | n/a |
| <a name="output_mixed_instances_policy"></a> [mixed\_instances\_policy](#output\_mixed\_instances\_policy) | n/a |
| <a name="output_ssm_ec2_policy"></a> [ssm\_ec2\_policy](#output\_ssm\_ec2\_policy) | n/a |
| <a name="output_vault_access_policy"></a> [vault\_access\_policy](#output\_vault\_access\_policy) | n/a |
| <a name="output_vault_iam_role"></a> [vault\_iam\_role](#output\_vault\_iam\_role) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
