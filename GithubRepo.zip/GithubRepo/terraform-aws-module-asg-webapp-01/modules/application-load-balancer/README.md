# application-load-balancer

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_alb_listener.front_end](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/alb_listener) | resource |
| [aws_lb.webapp_alb](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb) | resource |
| [aws_lb_listener.webapp_listener](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_listener) | resource |
| [aws_lb_target_group.webapp_tg_alb](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group) | resource |
| [aws_route53_record.alb](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_zone.private](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_alb_forwarding_config"></a> [alb\_forwarding\_config](#input\_alb\_forwarding\_config) | A map of target group names and their configurations for the ALB. | <pre>map(object({<br>    port                 = number<br>    protocol             = string<br>    listener_port        = optional(number)<br>    deregistration_delay = optional(string)<br>    preserve_client_ip   = optional(bool)<br>    health_check = optional(object({<br>      enabled             = bool<br>      healthy_threshold   = number<br>      unhealthy_threshold = number<br>      timeout             = number<br>      path                = string<br>      port                = number<br>      protocol            = string<br>      interval            = number<br>      matcher             = string<br>    }))<br>    stickiness = optional(object({<br>      enabled         = bool<br>      cookie_duration = number<br>      cookie_name     = string<br>      type            = string<br>    }))<br>  }))</pre> | `{}` | no |
| <a name="input_alb_idle_timeout"></a> [alb\_idle\_timeout](#input\_alb\_idle\_timeout) | The idle timeout value, in seconds, for the ALB. | `number` | `60` | no |
| <a name="input_alb_sg_ids"></a> [alb\_sg\_ids](#input\_alb\_sg\_ids) | A list of security group IDs for assigning to the Application Load Balancer. | `list(string)` | n/a | yes |
| <a name="input_alb_subdomain"></a> [alb\_subdomain](#input\_alb\_subdomain) | The subdomain for the ALB. | `list(string)` | `[]` | no |
| <a name="input_alb_subnet_ids"></a> [alb\_subnet\_ids](#input\_alb\_subnet\_ids) | A list of subnet IDs for assigning to the Application Load Balancer. | `list(string)` | n/a | yes |
| <a name="input_business_domain"></a> [business\_domain](#input\_business\_domain) | The business domain name. | `string` | n/a | yes |
| <a name="input_enable_alb"></a> [enable\_alb](#input\_enable\_alb) | Whether to enable the Application Load Balancer (ALB). | `bool` | `true` | no |
| <a name="input_enable_alb_https_redirect"></a> [enable\_alb\_https\_redirect](#input\_enable\_alb\_https\_redirect) | Whether to enable HTTPS redirection on the ALB. | `bool` | `false` | no |
| <a name="input_enable_cz_lb"></a> [enable\_cz\_lb](#input\_enable\_cz\_lb) | Whether to enable cross-zone load balancing. | `bool` | `false` | no |
| <a name="input_enable_http2"></a> [enable\_http2](#input\_enable\_http2) | Whether to enable HTTP/2 support on the ALB. | `bool` | `false` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment short name (e.g., dev, prod). | `string` | n/a | yes |
| <a name="input_internal"></a> [internal](#input\_internal) | Whether to create an internal or external load balancer. | `bool` | `true` | no |
| <a name="input_lb_cert"></a> [lb\_cert](#input\_lb\_cert) | The Amazon Resource Name (ARN) of the SSL certificate to associate with the HTTPS listener. | `string` | `""` | no |
| <a name="input_lb_ssl_policy"></a> [lb\_ssl\_policy](#input\_lb\_ssl\_policy) | The Amazon Resource Name (ARN) of the SSL policy to associate with the HTTPS listener. | `string` | `""` | no |
| <a name="input_oidc_config"></a> [oidc\_config](#input\_oidc\_config) | OIDC configuration for the ALB listener. | <pre>object({<br>    enabled                             = bool<br>    authorization_endpoint              = string<br>    client_id                           = string<br>    client_secret                       = string<br>    issuer                              = string<br>    token_endpoint                      = string<br>    user_info_endpoint                  = string<br>    authentication_request_extra_params = map(string)<br>    on_unauthenticated_request          = string<br>    scope                               = string<br>    session_cookie_name                 = string<br>    session_timeout                     = number<br>  })</pre> | <pre>{<br>  "authentication_request_extra_params": {},<br>  "authorization_endpoint": "",<br>  "client_id": "",<br>  "client_secret": "",<br>  "enabled": false,<br>  "issuer": "",<br>  "on_unauthenticated_request": "deny",<br>  "scope": "openid",<br>  "session_cookie_name": "AWSELBAuthSessionCookie",<br>  "session_timeout": 604800,<br>  "token_endpoint": "",<br>  "user_info_endpoint": ""<br>}</pre> | no |
| <a name="input_private_zone_domain"></a> [private\_zone\_domain](#input\_private\_zone\_domain) | The private Route53 Zone domain for the ALB/NLB. | `string` | n/a | yes |
| <a name="input_random_number"></a> [random\_number](#input\_random\_number) | A random number to be appended to resource names. | `string` | `"01"` | no |
| <a name="input_region"></a> [region](#input\_region) | The AWS region where resources will be created. | `string` | `"us-east-1"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to assign to resources. | `map(string)` | `{}` | no |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | The VPC ID for the target group of the load balancer. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_front_end_listener_arn"></a> [front\_end\_listener\_arn](#output\_front\_end\_listener\_arn) | ARN of the Front End Listener created for the Application Load Balancer |
| <a name="output_route53_alb_record_fqdns"></a> [route53\_alb\_record\_fqdns](#output\_route53\_alb\_record\_fqdns) | Fully qualified domain names of the Route53 records created for the Application Load Balancer |
| <a name="output_route53_alb_record_ids"></a> [route53\_alb\_record\_ids](#output\_route53\_alb\_record\_ids) | IDs of the Route53 records created for the Application Load Balancer |
| <a name="output_webapp_alb_arn"></a> [webapp\_alb\_arn](#output\_webapp\_alb\_arn) | ARN of the Application Load Balancer |
| <a name="output_webapp_alb_dns_name"></a> [webapp\_alb\_dns\_name](#output\_webapp\_alb\_dns\_name) | DNS name of the Application Load Balancer |
| <a name="output_webapp_alb_name"></a> [webapp\_alb\_name](#output\_webapp\_alb\_name) | ARN of the Application Load Balancer |
| <a name="output_webapp_alb_zone_id"></a> [webapp\_alb\_zone\_id](#output\_webapp\_alb\_zone\_id) | Zone ID of the Application Load Balancer |
| <a name="output_webapp_listener_arns"></a> [webapp\_listener\_arns](#output\_webapp\_listener\_arns) | ARNs of the Listeners created for the Application Load Balancer |
| <a name="output_webapp_target_group_arns"></a> [webapp\_target\_group\_arns](#output\_webapp\_target\_group\_arns) | ARNs of the Target Groups created for the Application Load Balancer |
| <a name="output_webapp_target_group_ids"></a> [webapp\_target\_group\_ids](#output\_webapp\_target\_group\_ids) | IDs of the Target Groups created for the Application Load Balancer |
| <a name="output_webapp_target_group_names"></a> [webapp\_target\_group\_names](#output\_webapp\_target\_group\_names) | IDs of the Target Groups created for the Application Load Balancer |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
