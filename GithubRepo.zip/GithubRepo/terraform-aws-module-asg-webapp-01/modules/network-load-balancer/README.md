# network-load-balancer

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 4.66.1 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_alb_listener.front_end_https_redirect](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/alb_listener) | resource |
| [aws_lb.webapp_alb_https_redirect](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb) | resource |
| [aws_lb.webapp_nlb](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb) | resource |
| [aws_lb_listener.listener-80](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_listener) | resource |
| [aws_lb_listener.webapp_listener](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_listener) | resource |
| [aws_lb_target_group.alb_https_redirect](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group) | resource |
| [aws_lb_target_group.webapp_tg_nlb](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group) | resource |
| [aws_lb_target_group_attachment.https_redirect_attachment](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group_attachment) | resource |
| [aws_route53_record.nlb](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_zone.private](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_alb_sg_ids"></a> [alb\_sg\_ids](#input\_alb\_sg\_ids) | Security group IDs for the ALB used for HTTPS redirection | `list(string)` | `[]` | no |
| <a name="input_business_domain"></a> [business\_domain](#input\_business\_domain) | The business domain for the load balancer | `string` | n/a | yes |
| <a name="input_enable_alb_https_redirect"></a> [enable\_alb\_https\_redirect](#input\_enable\_alb\_https\_redirect) | Enable the ALB for HTTPS redirection on the NLB | `bool` | `false` | no |
| <a name="input_enable_cz_lb"></a> [enable\_cz\_lb](#input\_enable\_cz\_lb) | Enable cross-zone load balancing | `bool` | `false` | no |
| <a name="input_enable_nlb"></a> [enable\_nlb](#input\_enable\_nlb) | Enable the Network Load Balancer (NLB) | `bool` | `false` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment for the resources | `string` | n/a | yes |
| <a name="input_internal"></a> [internal](#input\_internal) | Set the load balancer as internal or external | `bool` | `false` | no |
| <a name="input_lb_cert"></a> [lb\_cert](#input\_lb\_cert) | The ARN of the certificate for the load balancer | `string` | n/a | yes |
| <a name="input_lb_ssl_policy"></a> [lb\_ssl\_policy](#input\_lb\_ssl\_policy) | The SSL policy for the load balancer | `string` | `"ELBSecurityPolicy-2016-08"` | no |
| <a name="input_nlb_forwarding_config"></a> [nlb\_forwarding\_config](#input\_nlb\_forwarding\_config) | A map of forwarding configurations for the Network Load Balancer target groups | <pre>map(object({<br>    port                 = number<br>    protocol             = string<br>    listener_port        = optional(number)<br>    deregistration_delay = optional(number)<br>    preserve_client_ip   = optional(string)<br>    health_check = optional(object({<br>      enabled             = bool<br>      healthy_threshold   = number<br>      unhealthy_threshold = number<br>      timeout             = number<br>      port                = string<br>      protocol            = string<br>      interval            = number<br>    }))<br>    stickiness = optional(object({<br>      enabled         = bool<br>      cookie_duration = number<br>      cookie_name     = string<br>      type            = string<br>    }))<br>  }))</pre> | `{}` | no |
| <a name="input_nlb_subdomain"></a> [nlb\_subdomain](#input\_nlb\_subdomain) | The subdomain for the ALB. | `list(string)` | `[]` | no |
| <a name="input_nlb_subnet_ids"></a> [nlb\_subnet\_ids](#input\_nlb\_subnet\_ids) | Subnet IDs for the Network Load Balancer | `list(string)` | `[]` | no |
| <a name="input_oidc_config"></a> [oidc\_config](#input\_oidc\_config) | OIDC configuration for the ALB listener. | <pre>object({<br>    enabled                             = bool<br>    authorization_endpoint              = string<br>    client_id                           = string<br>    client_secret                       = string<br>    issuer                              = string<br>    token_endpoint                      = string<br>    user_info_endpoint                  = string<br>    authentication_request_extra_params = map(string)<br>    on_unauthenticated_request          = string<br>    scope                               = string<br>    session_cookie_name                 = string<br>    session_timeout                     = number<br>  })</pre> | <pre>{<br>  "authentication_request_extra_params": {},<br>  "authorization_endpoint": "",<br>  "client_id": "",<br>  "client_secret": "",<br>  "enabled": false,<br>  "issuer": "",<br>  "on_unauthenticated_request": "deny",<br>  "scope": "openid",<br>  "session_cookie_name": "AWSELBAuthSessionCookie",<br>  "session_timeout": 604800,<br>  "token_endpoint": "",<br>  "user_info_endpoint": ""<br>}</pre> | no |
| <a name="input_private_zone_domain"></a> [private\_zone\_domain](#input\_private\_zone\_domain) | The private Route53 Zone domain for the ALB/NLB. | `string` | n/a | yes |
| <a name="input_random_number"></a> [random\_number](#input\_random\_number) | Random number to append to the name of the resources | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | The region for the resources | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags to attach to resources | `map(string)` | `{}` | no |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | The VPC ID for the load balancer and target groups | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_alb_https_redirect"></a> [alb\_https\_redirect](#output\_alb\_https\_redirect) | The target group for the ALB HTTPS redirect |
| <a name="output_front_end_https_redirect"></a> [front\_end\_https\_redirect](#output\_front\_end\_https\_redirect) | The front-end ALB listener for HTTPS redirect |
| <a name="output_https_redirect_attachment"></a> [https\_redirect\_attachment](#output\_https\_redirect\_attachment) | The target group attachment for the HTTPS redirect |
| <a name="output_listener_80"></a> [listener\_80](#output\_listener\_80) | The NLB listener for port 80 |
| <a name="output_webapp_alb_https_redirect"></a> [webapp\_alb\_https\_redirect](#output\_webapp\_alb\_https\_redirect) | The Application Load Balancer for HTTPS redirect |
| <a name="output_webapp_alb_https_redirect_arn"></a> [webapp\_alb\_https\_redirect\_arn](#output\_webapp\_alb\_https\_redirect\_arn) | The ARN of the Application Load Balancer for HTTPS redirect |
| <a name="output_webapp_alb_https_redirect_dns_name"></a> [webapp\_alb\_https\_redirect\_dns\_name](#output\_webapp\_alb\_https\_redirect\_dns\_name) | The DNS name of the Application Load Balancer for HTTPS redirect |
| <a name="output_webapp_alb_https_redirect_zone_id"></a> [webapp\_alb\_https\_redirect\_zone\_id](#output\_webapp\_alb\_https\_redirect\_zone\_id) | The zone ID of the Application Load Balancer for HTTPS redirect |
| <a name="output_webapp_listener"></a> [webapp\_listener](#output\_webapp\_listener) | The listeners for the Network Load Balancer |
| <a name="output_webapp_nlb"></a> [webapp\_nlb](#output\_webapp\_nlb) | The Network Load Balancer |
| <a name="output_webapp_nlb_arn"></a> [webapp\_nlb\_arn](#output\_webapp\_nlb\_arn) | The ARN of the Network Load Balancer |
| <a name="output_webapp_nlb_dns_name"></a> [webapp\_nlb\_dns\_name](#output\_webapp\_nlb\_dns\_name) | The DNS name of the Network Load Balancer |
| <a name="output_webapp_nlb_zone_id"></a> [webapp\_nlb\_zone\_id](#output\_webapp\_nlb\_zone\_id) | The zone ID of the Network Load Balancer |
| <a name="output_webapp_target_group_arns"></a> [webapp\_target\_group\_arns](#output\_webapp\_target\_group\_arns) | ARNs of the Target Groups created for the Application Load Balancer |
| <a name="output_webapp_target_group_names"></a> [webapp\_target\_group\_names](#output\_webapp\_target\_group\_names) | IDs of the Target Groups created for the Application Load Balancer |
| <a name="output_webapp_tg_nlb"></a> [webapp\_tg\_nlb](#output\_webapp\_tg\_nlb) | The target groups for the Network Load Balancer |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
